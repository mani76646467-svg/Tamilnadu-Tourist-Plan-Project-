import { DestinationCategory } from "../data/types";

export interface DailyWeatherForecast {
  date: string;
  dayLabel: string;
  maxTemp: number;
  minTemp: number;
  rainChance: number;
  weatherCode: number;
  conditionEn: string;
  conditionTa: string;
  conditionHi: string;
  icon: string;
}

export interface PackingTip {
  icon: string;
  en: string;
  ta: string;
  hi: string;
}

export interface DestinationWeatherData {
  destinationName: string;
  fetchedAt: string;
  currentTemp: number;
  feelsLike: number;
  humidity: number;
  windSpeed: number;
  weatherCode: number;
  conditionEn: string;
  conditionTa: string;
  conditionHi: string;
  icon: string;
  daily: DailyWeatherForecast[];
  packingTips: PackingTip[];
}

const DESTINATION_COORDS: Record<string, { lat: number; lon: number }> = {
  Madurai: { lat: 9.9252, lon: 78.1198 },
  Ooty: { lat: 11.4102, lon: 76.695 },
  Rameswaram: { lat: 9.2876, lon: 79.3129 },
  Kanyakumari: { lat: 8.0883, lon: 77.5385 },
  Mahabalipuram: { lat: 12.6208, lon: 80.1945 },
  Kodaikanal: { lat: 10.2381, lon: 77.4892 },
  Thanjavur: { lat: 10.787, lon: 79.1378 },
  "Chennai Marina": { lat: 13.05, lon: 80.2824 },
  Yercaud: { lat: 11.7753, lon: 78.2093 },
  "Hogenakkal Falls": { lat: 12.1182, lon: 77.7777 },
  Kanchipuram: { lat: 12.8342, lon: 79.7036 },
  "Chidambaram & Pichavaram": { lat: 11.3992, lon: 79.6935 },
  Tiruvannamalai: { lat: 12.2253, lon: 79.0747 },
  "Srirangam & Tiruchirappalli": { lat: 10.8624, lon: 78.6901 },
  "Kumbakonam & Darasuram": { lat: 10.9602, lon: 79.3845 },
  "Courtallam (Kutralam)": { lat: 8.9341, lon: 77.2778 },
  "Chettinad (Karaikudi)": { lat: 10.0735, lon: 78.7732 },
  Coonoor: { lat: 11.353, lon: 76.7959 },
  Valparai: { lat: 10.3269, lon: 76.9554 },
  "Gingee Fort (Senji)": { lat: 12.2569, lon: 79.4008 },
  "Gangaikonda Cholapuram": { lat: 11.2063, lon: 79.4488 },
  "Yelagiri Hills": { lat: 12.5794, lon: 78.6396 },
  "Kolli Hills (Kolli Malai)": { lat: 11.2485, lon: 78.3387 },
  "Meghamalai (High Wavy Mountains)": { lat: 9.6989, lon: 77.3996 },
  "Mudumalai National Park": { lat: 11.5623, lon: 76.5345 },
  Dhanushkodi: { lat: 9.1794, lon: 79.4183 },
  "Vellore Golden Temple & Fort": { lat: 12.9165, lon: 79.1325 },
  "Tharangambadi (Tranquebar)": { lat: 11.029, lon: 79.8558 },
  "Velankanni & Nagapattinam": { lat: 10.6819, lon: 79.8437 },
  Palani: { lat: 10.45, lon: 77.5161 },
  Tiruchendur: { lat: 8.4963, lon: 78.125 },
  Poompuhar: { lat: 11.1445, lon: 79.8569 },
  "Kovalam (Covelong) Beach": { lat: 12.7897, lon: 80.2504 },
  "Pollachi & Topslip (Anamalai)": { lat: 10.4706, lon: 76.8424 },
  "Coimbatore & Isha Yoga Center": { lat: 10.976, lon: 76.7351 },
  Kotagiri: { lat: 11.4218, lon: 76.8617 },
  "Thoothukudi (Tuticorin) & Pearl Coast": { lat: 8.7642, lon: 78.1348 },
  "Pudukkottai & Sittanavasal": { lat: 10.4573, lon: 78.7263 },
  "Kalakkad Mundanthurai & Manjolai": { lat: 8.6869, lon: 77.3679 },
  "Namakkal & Fort Rock": { lat: 11.2194, lon: 78.1678 },
  Srivilliputhur: { lat: 9.5094, lon: 77.6322 },
  Swamimalai: { lat: 10.9577, lon: 79.3264 },
  Thiruthani: { lat: 13.1755, lon: 79.6104 },
  "Pazhamudircholai & Alagar Koyil": { lat: 10.0747, lon: 78.2131 },
  Thiruparankundram: { lat: 9.8821, lon: 78.0715 },
  "Mayiladuthurai & Vaitheeswaran Koil": { lat: 11.1932, lon: 79.7114 },
  "Sirkazhi & Tiruvenkadu": { lat: 11.2391, lon: 79.7361 },
  "Samayapuram & Thiruvanaikaval": { lat: 10.9355, lon: 78.7406 },
  "Pillayarpatti & Kundrakudi": { lat: 10.1197, lon: 78.6683 },
  "Pamban Island & Sea Bridge": { lat: 9.2825, lon: 79.2087 },
  "Ramanathapuram Palace & Devipattinam": { lat: 9.3716, lon: 78.8308 },
  "Dindigul Rock Fort": { lat: 10.3624, lon: 77.9695 },
  "Sirumalai Hills": { lat: 10.1942, lon: 77.9967 },
  "Javadi Hills (Jawadhu Malai)": { lat: 12.5833, lon: 78.8333 },
  "Pachaimalai Hills": { lat: 11.3183, lon: 78.6305 },
  "Kalrayan Hills": { lat: 11.8384, lon: 78.6632 },
  "Sathuragiri & Pilavakkal": { lat: 9.6711, lon: 77.6194 },
  "Bodi Mettu & Kurangani Hills": { lat: 10.0144, lon: 77.2692 },
  "Cumbum Valley & Suruli Falls": { lat: 9.6606, lon: 77.3045 },
  "Gudalur & Needle Rock (Nilgiris)": { lat: 11.503, lon: 76.4917 },
  "Avalanche & Emerald Lake": { lat: 11.3022, lon: 76.5928 },
  "Pykara & Mukurthi (Nilgiris)": { lat: 11.4586, lon: 76.6025 },
  "Masinagudi & Moyar Canyon": { lat: 11.5732, lon: 76.6431 },
  "Point Calimere (Kodiyakarai) & Vedaranyam": { lat: 10.2952, lon: 79.8492 },
  "Pichavaram Mangrove Forest": { lat: 11.4319, lon: 79.781 },
  "Silver Beach & Fort St. David (Cuddalore)": { lat: 11.7384, lon: 79.7858 },
  "Pulicat Lake (Pazhaverkadu)": { lat: 13.4191, lon: 80.3176 },
  "Vedanthangal & Karikili Bird Sanctuary": { lat: 12.5455, lon: 79.8547 },
  "Sadras Dutch Fort & Thirukazhukundram": { lat: 12.5255, lon: 80.1613 },
  "DakshinaChitra & Muttukadu (ECR)": { lat: 12.8239, lon: 80.2421 },
  "Mylapore & San Thome (Chennai)": { lat: 13.0339, lon: 80.27 },
  "Fort St. George & Egmore Museum": { lat: 13.0797, lon: 80.2874 },
  "Besant Nagar Elliot's Beach & Guindy Park": { lat: 13.0002, lon: 80.2737 },
  "Vandalur Zoo (Arignar Anna Zoological Park)": { lat: 12.8792, lon: 80.0816 },
  "Thiruparappu Falls & Mathur Aqueduct": { lat: 8.3917, lon: 77.2608 },
  "Padmanabhapuram Palace & Udayagiri Fort": { lat: 8.2507, lon: 77.3267 },
  "Vattakottai Fort & Muttom Beach": { lat: 8.1257, lon: 77.5653 },
  "Suchindram & Nagercoil Temples": { lat: 8.1558, lon: 77.4651 },
  "Papanasam & Agasthiyar Falls": { lat: 8.7042, lon: 77.3622 },
  "Manapad Beach & Nava Tirupati": { lat: 8.3752, lon: 78.0609 },
  "Kazhugumalai (Vettuvan Koil)": { lat: 9.1492, lon: 77.7061 },
  "Panchalankurichi & Ettayapuram": { lat: 8.9325, lon: 78.0439 },
  "Sankarankovil (Sankaranayinarkoil)": { lat: 9.1726, lon: 77.5356 },
  "Tenkasi Kasi Viswanathar & Old Courtallam": { lat: 8.9594, lon: 77.3161 },
  "Thirumayam Fort & Avudaiyarkoil": { lat: 10.2458, lon: 78.7525 },
  "Viralimalai Peacock Sanctuary & Kodumbalur": { lat: 10.6022, lon: 78.5447 },
  "Bhavanisagar Dam & Kodiveri Falls": { lat: 11.4728, lon: 77.1158 },
  "Sathyamangalam Tiger Reserve & Dhimbam": { lat: 11.5594, lon: 77.1431 },
  "Chennimalai & Vellode Bird Sanctuary": { lat: 11.1678, lon: 77.6042 },
  "Mettur Dam & Taramangalam (Salem)": { lat: 11.7972, lon: 77.8017 },
  "Tiruchengode Ardhanareeswarar Hill": { lat: 11.3789, lon: 77.8944 },
  "Bhavani Kooduthurai & Uratchikottai": { lat: 11.4375, lon: 77.6836 },
  "Sathanur Dam & Tirukoilur": { lat: 12.1856, lon: 78.8506 },
  "Amirthi Zoo & Jalagamparai Falls": { lat: 12.7311, lon: 79.0569 },
  "Krishnagiri Dam & Rayakottai Fort": { lat: 12.4872, lon: 78.1744 },
  "Keeladi Heritage Museum & Thirupuvanam": { lat: 9.8542, lon: 78.1967 },
  "Sikkal, Nagore & Ettukudi": { lat: 10.8153, lon: 79.8392 },
  "Mannargudi, Tiruvarur & Vaduvur": { lat: 10.6667, lon: 79.45 },
  "Thirunageswaram, Uppiliappan & Alangudi": { lat: 10.9639, lon: 79.4286 },
  "Amaravathi Dam & Thirumoorthy Hills": { lat: 10.4272, lon: 77.2656 },
};

function decodeWmoCode(code: number): {
  icon: string;
  en: string;
  ta: string;
  hi: string;
} {
  if (code === 0) {
    return {
      icon: "☀️",
      en: "Clear Sunny Sky",
      ta: "தெளிவான வெயில் வானிலை",
      hi: "साफ़ धूप वाला आकाश",
    };
  }
  if (code === 1 || code === 2) {
    return {
      icon: "⛅",
      en: "Partly Cloudy & Pleasant",
      ta: "மிதமான மேகமூட்டம் & இதமான காற்று",
      hi: "आंशिक बादल और सुहावना मौसम",
    };
  }
  if (code === 3) {
    return {
      icon: "☁️",
      en: "Overcast Clouds",
      ta: "மேகமூட்டமான வானிலை",
      hi: "घने बादल छाए रहेंगे",
    };
  }
  if (code === 45 || code === 48) {
    return {
      icon: "🌫️",
      en: "Misty & Foggy",
      ta: "பனிமூட்டமான வானிலை",
      hi: "कोहरा और धुंध",
    };
  }
  if (code >= 51 && code <= 57) {
    return {
      icon: "🌦️",
      en: "Light Drizzle",
      ta: "லேசான சாரல் மழை",
      hi: "हल्की बूंदाबांदी",
    };
  }
  if (code >= 61 && code <= 67) {
    return {
      icon: "🌧️",
      en: "Moderate Rain Showers",
      ta: "மிதமான மழை",
      hi: "मध्यम बारिश",
    };
  }
  if (code >= 80 && code <= 82) {
    return {
      icon: "🌦️",
      en: "Passing Rain Showers",
      ta: "அவ்வப்போது மழைத் தூறல்",
      hi: "रुक-रुक कर बारिश की बौछारें",
    };
  }
  if (code >= 95) {
    return {
      icon: "⛈️",
      en: "Thunderstorm & Rain",
      ta: "இடி மின்னலுடன் மழை",
      hi: "गरज के साथ बारिश",
    };
  }
  return {
    icon: "🌤️",
    en: "Pleasant Weather",
    ta: "இதமான வானிலை",
    hi: "सुहावना मौसम",
  };
}

function buildPackingTips(
  currentTemp: number,
  maxRainChance: number,
  category: DestinationCategory
): PackingTip[] {
  const tips: PackingTip[] = [];

  if (currentTemp <= 22 || category === "Hill Station") {
    tips.push({
      icon: "🧥",
      en: "Pack light woollen sweaters, a windcheater jacket & warm socks for cool morning/evening hill breezes.",
      ta: "மலைப் பகுதியில் காலை/இரவு குளிருக்கு ஸ்வெட்டர், ஜாக்கெட் மற்றும் சாக்ஸ் எடுத்துச் செல்லவும்.",
      hi: "सुबह और शाम की ठंडी पहाड़ी हवा के लिए हल्के ऊनी स्वेटर, जैकेट और मोज़े साथ रखें।",
    });
  } else if (currentTemp >= 31) {
    tips.push({
      icon: "👕",
      en: "Pack breathable light-colored cotton clothes, sunglasses, cap & SPF 50+ sunscreen for warm daytime sightseeing.",
      ta: "பகல் வெயிலுக்கு ஏற்ற பருத்தி ஆடைகள் (Cotton), குளிர் கண்ணாடி, தொப்பி மற்றும் சன்ஸ்கிரீன் எடுத்துச் செல்லவும்.",
      hi: "दोपहर की धूप के लिए हल्के सूती कपड़े, धूप का चश्मा, टोपी और सनस्क्रीन साथ रखें।",
    });
  } else {
    tips.push({
      icon: "👔",
      en: "Pack comfortable cotton/linen outfits and a light stole or shawl for pleasant daytime and evening travel.",
      ta: "பயணத்திற்கு ஏற்ற சாதாரண பருத்தி ஆடைகள் மற்றும் மெல்லிய சால்வை எடுத்துச் செல்லவும்.",
      hi: "आरामदायक सूती कपड़े और शाम की हल्की हवा के लिए एक शॉल साथ रखें।",
    });
  }

  if (maxRainChance >= 35) {
    tips.push({
      icon: "☔",
      en: `Rain chance is up to ${maxRainChance}% — carry a foldable umbrella, waterproof phone pouch & quick-dry footwear.`,
      ta: `மழை வாய்ப்பு ${maxRainChance}% உள்ளதால் குடை, ரெயின்கோட் மற்றும் வாட்டர்ப்ரூஃப் பை அவசியம் எடுத்துச் செல்லவும்.`,
      hi: `बारिश की संभावना ${maxRainChance}% है — छाता, रेनकोट और वाटरप्रूफ फोन पाउच अवश्य रखें।`,
    });
  } else {
    tips.push({
      icon: "💧",
      en: "Keep reusable water bottles, ORS/electrolytes & wet wipes handy during outdoor sightseeing.",
      ta: "சுற்றுலா இடங்களைச் சுற்றிப் பார்க்கும்போது குடிநீர் பாட்டில் மற்றும் எலக்ட்ரோலைட் பானம் வைத்திருக்கவும்.",
      hi: "दर्शनीय स्थलों की यात्रा के दौरान पानी की बोतल और इलेक्ट्रोलाइट्स साथ रखें।",
    });
  }

  if (category === "Temple") {
    tips.push({
      icon: "🛕",
      en: "Temple Dress Code: Pack traditional attire (Dhoti/Kurta or Saree/Salwar with dupatta) & slip-on sandals.",
      ta: "கோவில் தரிசனத்திற்குப் பாரம்பரிய உடைகள் (வேட்டி/சட்டை அல்லது புடவை/சுடிதார்) மற்றும் எளிதில் கழற்றக்கூடிய காலணிகள் அணியவும்.",
      hi: "मंदिर दर्शन के लिए पारंपरिक वस्त्र (धोती/कुर्ता या साड़ी/सलवार) और आसानी से खुलने वाले जूते-चप्पल रखें।",
    });
  } else if (category === "Beach") {
    tips.push({
      icon: "🏖️",
      en: "Beach Essentials: Carry flip-flops, extra pair of clothes, microfiber towel & UV sunglasses.",
      ta: "கடற்கரை உலாவிற்கு மாற்று உடைகள், டவல் மற்றும் கடல் காற்றுக்கு ஏற்ற காலணிகள் எடுத்துச் செல்லவும்.",
      hi: "समुद्र तट के लिए अतिरिक्त कपड़े, तौलिया, चप्पल और धूप का चश्मा साथ रखें।",
    });
  } else if (category === "Nature & Waterfalls") {
    tips.push({
      icon: "🥾",
      en: "Waterfall & Nature Gear: Pack non-slip grip sandals, extra dry clothes, towel & insect repellent.",
      ta: "அருவியில் குளிக்க மாற்று உடைகள், டவல் மற்றும் வழுக்காத காலணிகள் (Grip Sandals) எடுத்துச் செல்லவும்.",
      hi: "झरने में स्नान के लिए अतिरिक्त सूखे कपड़े, तौलिया और नॉन-स्लिप सैंडल साथ रखें।",
    });
  } else {
    tips.push({
      icon: "👟",
      en: "Footwear & Power: Wear cushioned walking shoes for fort/palace exploration and carry a power bank.",
      ta: "கோட்டை மற்றும் சுற்றுலா இடங்களில் நடக்க வசதியான ஷூ மற்றும் பவர் பேங்க் (Power Bank) எடுத்துச் செல்லவும்.",
      hi: "किले और स्मारकों में चलने के लिए आरामदायक जूते और पावर बैंक साथ रखें।",
    });
  }

  return tips;
}

export async function fetchDestinationWeather(
  destinationName: string,
  category: DestinationCategory
): Promise<DestinationWeatherData> {
  const coords = DESTINATION_COORDS[destinationName] || {
    lat: 10.7905,
    lon: 78.7047,
  };

  const url = `https://api.open-meteo.com/v1/forecast?latitude=${coords.lat}&longitude=${coords.lon}&current=temperature_2m,relative_humidity_2m,apparent_temperature,weather_code,wind_speed_10m&daily=weather_code,temperature_2m_max,temperature_2m_min,precipitation_probability_max&timezone=Asia%2FKolkata&forecast_days=5`;

  const response = await fetch(url);
  if (!response.ok) {
    throw new Error("Unable to fetch live weather data right now.");
  }

  const data = await response.json();
  const current = data.current || {};
  const dailyData = data.daily || {};

  const currentCode = Number(current.weather_code ?? 1);
  const decodedCurrent = decodeWmoCode(currentCode);

  const daily: DailyWeatherForecast[] = [];
  const dates: string[] = dailyData.time || [];
  const maxTemps: number[] = dailyData.temperature_2m_max || [];
  const minTemps: number[] = dailyData.temperature_2m_min || [];
  const rainChances: number[] = dailyData.precipitation_probability_max || [];
  const codes: number[] = dailyData.weather_code || [];

  for (let i = 0; i < Math.min(5, dates.length); i++) {
    const code = Number(codes[i] ?? 1);
    const decoded = decodeWmoCode(code);
    const parsedDate = new Date(`${dates[i]}T00:00:00`);
    const dayLabel = parsedDate.toLocaleDateString("en-IN", {
      weekday: "short",
      month: "short",
      day: "numeric",
    });

    daily.push({
      date: dates[i],
      dayLabel,
      maxTemp: Math.round(maxTemps[i] ?? 30),
      minTemp: Math.round(minTemps[i] ?? 22),
      rainChance: Math.round(rainChances[i] ?? 10),
      weatherCode: code,
      conditionEn: decoded.en,
      conditionTa: decoded.ta,
      conditionHi: decoded.hi,
      icon: decoded.icon,
    });
  }

  const currentTemp = Math.round(current.temperature_2m ?? 28);
  const maxRainChance =
    daily.length > 0
      ? Math.max(...daily.map((d) => d.rainChance))
      : 15;

  const packingTips = buildPackingTips(currentTemp, maxRainChance, category);

  return {
    destinationName,
    fetchedAt: new Date().toLocaleTimeString("en-IN", {
      hour: "2-digit",
      minute: "2-digit",
    }),
    currentTemp,
    feelsLike: Math.round(current.apparent_temperature ?? currentTemp),
    humidity: Math.round(current.relative_humidity_2m ?? 65),
    windSpeed: Math.round(current.wind_speed_10m ?? 12),
    weatherCode: currentCode,
    conditionEn: decodedCurrent.en,
    conditionTa: decodedCurrent.ta,
    conditionHi: decodedCurrent.hi,
    icon: decodedCurrent.icon,
    daily,
    packingTips,
  };
}

import { jsPDF } from "jspdf";
import { Destination } from "../data/destinations";
import { AppLanguage } from "../data/i18n";

export type SlotCategoryType = "spot" | "food" | "travel" | "stay";

export interface PdfScheduleSlot {
  order: number;
  slotType?: SlotCategoryType;
  time: string;
  timeTa: string;
  timeHi: string;
  place: string;
  placeTa: string;
  placeHi: string;
  activity: string;
  activityTa: string;
  activityHi: string;
  costBreakdownNote: string;
  costPerPerson: number;
  totalSlotCost: number;
}

export interface PdfDayPlan {
  day: number;
  dayTitle: string;
  dayTitleTa: string;
  dayTitleHi: string;
  dayTotalCost: number;
  dayPerPersonCost: number;
  slots: PdfScheduleSlot[];
}

export interface UniqueSpotSummary {
  spotIndex: number;
  dayNumber: number;
  spotName: string;
  spotNameTa: string;
  spotNameHi: string;
  timeSlot: string;
  timeSlotTa: string;
  timeSlotHi: string;
  activity: string;
  activityTa: string;
  activityHi: string;
  perPersonCost: number;
  totalCost: number;
}

export interface PdfPlanData {
  startCity: string;
  startCityTa: string;
  startCityHi: string;
  destination: Destination;
  destNameTa: string;
  destNameHi: string;
  districtTa: string;
  districtHi: string;
  summaryTa: string;
  summaryHi: string;
  categoryTa: string;
  categoryHi: string;
  days: number;
  people: number;
  userBudgetPerPerson: number;
  userTotalBudget: number;
  travelPerPerson: number;
  stayPerPerson: number;
  foodPerPerson: number;
  sightseeingPerPerson: number;
  estimatedPerPersonCost: number;
  travelTotal: number;
  stayTotal: number;
  foodTotal: number;
  sightseeingTotal: number;
  estimatedTotalCost: number;
  uniqueSpotsVisited: UniqueSpotSummary[];
  itinerary: PdfDayPlan[];
}

export interface PdfThemeColors {
  primary: string;
  primaryDark: string;
  tagBg: string;
  footerBg: string;
}

const PAGE_W = 1600;
const PAGE_H = 2262;
const MARGIN_X = 60;
const MARGIN_TOP = 54;
const MARGIN_BOTTOM = 88;
const CONTENT_W = PAGE_W - MARGIN_X * 2;
const FONT_FAMILY =
  'Arial, "Noto Sans Tamil", "Noto Sans Devanagari", "Latha", "Mangal", sans-serif';

function wrapLines(
  ctx: CanvasRenderingContext2D,
  text: string,
  maxWidth: number
): string[] {
  if (!text) return [""];
  const words = text.split(/\s+/);
  const lines: string[] = [];
  let current = "";

  for (const word of words) {
    const test = current ? `${current} ${word}` : word;
    if (ctx.measureText(test).width <= maxWidth) {
      current = test;
    } else {
      if (current) lines.push(current);
      if (ctx.measureText(word).width > maxWidth) {
        let chunk = "";
        for (const ch of word) {
          if (ctx.measureText(chunk + ch).width <= maxWidth) {
            chunk += ch;
          } else {
            lines.push(chunk);
            chunk = ch;
          }
        }
        current = chunk;
      } else {
        current = word;
      }
    }
  }
  if (current) lines.push(current);
  return lines.length > 0 ? lines : [""];
}

function drawRoundedRect(
  ctx: CanvasRenderingContext2D,
  x: number,
  y: number,
  w: number,
  h: number,
  r: number,
  fill?: string,
  stroke?: string,
  lineWidth = 2
) {
  ctx.beginPath();
  ctx.moveTo(x + r, y);
  ctx.lineTo(x + w - r, y);
  ctx.quadraticCurveTo(x + w, y, x + w, y + r);
  ctx.lineTo(x + w, y + h - r);
  ctx.quadraticCurveTo(x + w, y + h, x + w - r, y + h);
  ctx.lineTo(x + r, y + h);
  ctx.quadraticCurveTo(x, y + h, x, y + h - r);
  ctx.lineTo(x, y + r);
  ctx.quadraticCurveTo(x, y, x + r, y);
  ctx.closePath();
  if (fill) {
    ctx.fillStyle = fill;
    ctx.fill();
  }
  if (stroke) {
    ctx.strokeStyle = stroke;
    ctx.lineWidth = lineWidth;
    ctx.stroke();
  }
}

export async function generateBilingualTripPdf(
  plan: PdfPlanData,
  theme: PdfThemeColors,
  lang: AppLanguage = "ta"
): Promise<void> {
  const pdf = new jsPDF({
    orientation: "portrait",
    unit: "mm",
    format: "a4",
  });

  const canvas = document.createElement("canvas");
  canvas.width = PAGE_W;
  canvas.height = PAGE_H;
  const ctx = canvas.getContext("2d")!;

  let pageNumber = 1;
  let y = MARGIN_TOP;

  const estPerPersonTotal = plan.estimatedPerPersonCost;

  const startFreshCanvas = (isContinuationPage: boolean) => {
    ctx.fillStyle = "#ffffff";
    ctx.fillRect(0, 0, PAGE_W, PAGE_H);
    ctx.textBaseline = "top";
    y = MARGIN_TOP;

    if (isContinuationPage) {
      drawRoundedRect(ctx, MARGIN_X, y, CONTENT_W, 74, 14, theme.primary);
      ctx.fillStyle = "#fde68a";
      ctx.font = `bold 19px ${FONT_FAMILY}`;
      ctx.fillText(
        `TN Smart Tourist Planner • ${plan.startCity} (${plan.startCityTa}) → ${plan.destination.name} (${plan.destNameTa} / ${plan.destNameHi})`,
        MARGIN_X + 24,
        y + 24
      );
      ctx.textAlign = "right";
      ctx.fillStyle = "#ffffff";
      ctx.font = `bold 18.5px ${FONT_FAMILY}`;
      ctx.fillText(
        `நபர் 1-க்கு: ₹${estPerPersonTotal.toLocaleString("en-IN")} | மொத்தம்: ₹${plan.estimatedTotalCost.toLocaleString("en-IN")}`,
        MARGIN_X + CONTENT_W - 24,
        y + 24
      );
      ctx.textAlign = "left";
      y += 92;
    }
  };

  const flushPageToPdf = (isLastPage: boolean) => {
    const footerY = PAGE_H - 68;
    drawRoundedRect(ctx, MARGIN_X, footerY, CONTENT_W, 48, 12, theme.footerBg);
    ctx.fillStyle = "#ffffff";
    ctx.font = `bold 17px ${FONT_FAMILY}`;
    ctx.fillText(
      `TN Smart Tourist Planner • ${plan.uniqueSpotsVisited.length} சுற்றுலா இடங்கள் (Unique Tourist Places) • இனிய பயணம் / शुभ यात्रा!`,
      MARGIN_X + 22,
      footerY + 14
    );
    ctx.fillStyle = "#fde68a";
    ctx.textAlign = "right";
    ctx.fillText(
      `பக்கம் ${pageNumber} / Page ${pageNumber}`,
      MARGIN_X + CONTENT_W - 22,
      footerY + 14
    );
    ctx.textAlign = "left";

    const imgData = canvas.toDataURL("image/jpeg", 0.95);
    pdf.addImage(imgData, "JPEG", 0, 0, 210, 297);

    if (!isLastPage) {
      pdf.addPage();
      pageNumber++;
      startFreshCanvas(true);
    }
  };

  const ensureSpace = (requiredHeight: number) => {
    if (y + requiredHeight > PAGE_H - MARGIN_BOTTOM) {
      flushPageToPdf(false);
      return true;
    }
    return false;
  };

  // Initialize Page 1
  startFreshCanvas(false);

  // =========================================================================
  // 1. ATTRACTIVE TRILINGUAL HERO BANNER WITH EXACT PER-PERSON & TOTAL BOX
  // =========================================================================
  const bannerH = 200;
  drawRoundedRect(ctx, MARGIN_X, y, CONTENT_W, bannerH, 22, theme.primary);

  ctx.fillStyle = "#fde68a";
  ctx.font = `bold 19px ${FONT_FAMILY}`;
  ctx.fillText(
    "✨ தமிழ்நாடு சுற்றுலா பயணத் திட்டம் • TAMIL NADU TOURIST PLAN • तमिलनाडु यात्रा योजना ✨",
    MARGIN_X + 30,
    y + 22
  );

  ctx.fillStyle = "#ffffff";
  ctx.font = `bold 33px ${FONT_FAMILY}`;
  const routeTitle = `${plan.startCity} (${plan.startCityTa})  →  ${plan.destination.name} (${plan.destNameTa})`;
  const routeLines = wrapLines(ctx, routeTitle, CONTENT_W - 360);
  ctx.fillText(routeLines[0], MARGIN_X + 30, y + 58);

  ctx.fillStyle = "#e0f2fe";
  ctx.font = `bold 21px ${FONT_FAMILY}`;
  ctx.fillText(
    `हिन्दी: ${plan.startCityHi}  →  ${plan.destNameHi} (${plan.districtHi})`,
    MARGIN_X + 30,
    y + 104
  );

  ctx.fillStyle = "#fef3c7";
  ctx.font = `bold 20px ${FONT_FAMILY}`;
  ctx.fillText(
    `📍 ${plan.districtTa} (${plan.destination.district})  •  ${plan.categoryTa}  •  ${plan.uniqueSpotsVisited.length} உண்மையான சுற்றுலா இடங்கள் (Accurate Places)`,
    MARGIN_X + 30,
    y + 144
  );

  // Right-side Per-Person & Grand Total Highlight Box
  const priceBoxW = 310;
  const priceBoxX = MARGIN_X + CONTENT_W - priceBoxW - 26;
  drawRoundedRect(
    ctx,
    priceBoxX,
    y + 22,
    priceBoxW,
    156,
    18,
    "#ffffff",
    "#fbbf24",
    4
  );
  ctx.textAlign = "center";
  ctx.fillStyle = "#b45309";
  ctx.font = `bold 16px ${FONT_FAMILY}`;
  ctx.fillText(
    "நபர் 1-க்கு / PER PERSON / प्रति व्यक्ति",
    priceBoxX + priceBoxW / 2,
    y + 38
  );
  ctx.fillStyle = theme.primaryDark;
  ctx.font = `bold 36px ${FONT_FAMILY}`;
  ctx.fillText(
    `₹${estPerPersonTotal.toLocaleString("en-IN")}`,
    priceBoxX + priceBoxW / 2,
    y + 66
  );
  drawRoundedRect(
    ctx,
    priceBoxX + 16,
    y + 116,
    priceBoxW - 32,
    44,
    10,
    "#047857"
  );
  ctx.fillStyle = "#ffffff";
  ctx.font = `bold 18.5px ${FONT_FAMILY}`;
  ctx.fillText(
    `மொத்தம் (${plan.people} நபர்): ₹${plan.estimatedTotalCost.toLocaleString("en-IN")}`,
    priceBoxX + priceBoxW / 2,
    y + 128
  );
  ctx.textAlign = "left";

  y += bannerH + 20;

  // =========================================================================
  // 2. SUMMARY STATS BAR (4 ATTRACTIVE CARDS)
  // =========================================================================
  const summaryCards = [
    {
      label: "🗓️ நாட்கள் / Days / दिन",
      value: `${plan.days} நாட்கள் (${plan.days} Days)`,
      sub: `${plan.uniqueSpotsVisited.length} Unique Places in ${plan.destination.name}`,
      accent: "#ede9fe",
    },
    {
      label: "👥 நபர்கள் / People / यात्री",
      value: `${plan.people} நபர்கள் (${plan.people} People)`,
      sub: `${plan.people} × ₹${estPerPersonTotal.toLocaleString("en-IN")} = ₹${plan.estimatedTotalCost.toLocaleString("en-IN")}`,
      accent: "#e0f2fe",
    },
    {
      label: "👤 நபர் 1-க்கு / Per Person",
      value: `₹${estPerPersonTotal.toLocaleString("en-IN")} / நபர்`,
      sub: `Your Budget: ₹${plan.userBudgetPerPerson.toLocaleString("en-IN")}/நபர்`,
      accent: "#dcfce7",
    },
    {
      label: "💰 மொத்த செலவு / Grand Total",
      value: `₹${plan.estimatedTotalCost.toLocaleString("en-IN")}`,
      sub: `Total Budget: ₹${plan.userTotalBudget.toLocaleString("en-IN")}`,
      accent: "#fef3c7",
    },
  ];

  const cardGap = 16;
  const cardW = (CONTENT_W - cardGap * 3) / 4;
  const cardH = 120;

  summaryCards.forEach((c, idx) => {
    const cx = MARGIN_X + idx * (cardW + cardGap);
    drawRoundedRect(ctx, cx, y, cardW, cardH, 16, "#ffffff", "#cbd5e1", 2);
    drawRoundedRect(ctx, cx + 10, y + 10, cardW - 20, 34, 8, c.accent);
    ctx.fillStyle = "#1e293b";
    ctx.font = `bold 16px ${FONT_FAMILY}`;
    ctx.fillText(c.label, cx + 16, y + 18);

    ctx.fillStyle = "#0f172a";
    ctx.font = `bold 24px ${FONT_FAMILY}`;
    ctx.fillText(c.value, cx + 16, y + 52);

    ctx.fillStyle = "#475569";
    ctx.font = `bold 15px ${FONT_FAMILY}`;
    ctx.fillText(c.sub, cx + 16, y + 88);
  });

  y += cardH + 20;

  // =========================================================================
  // 3. ITEMIZED ACCURATE BUDGET BREAKDOWN + EXACT FORMULA VERIFICATION BAR
  // =========================================================================
  ctx.fillStyle = theme.primaryDark;
  ctx.font = `bold 22px ${FONT_FAMILY}`;
  ctx.fillText(
    "1. துல்லியமான பட்ஜெட் விவரம் (நபர் 1-க்கு & மொத்தம்) / Accurate Itemized Budget Breakdown",
    MARGIN_X,
    y
  );
  y += 32;

  const nightsCount = Math.max(0, plan.days - 1);
  const budgetBoxes = [
    {
      title: "🚌 1. போக்குவரத்து / Travel",
      total: plan.travelTotal,
      pp: plan.travelPerPerson,
      sub: `போய் வர: ₹${plan.destination.avgTravelCostPerPerson} × 2 = ₹${plan.travelPerPerson}/நபர்`,
    },
    {
      title: "🏨 2. தங்குமிடம் / Hotel Stay",
      total: plan.stayTotal,
      pp: plan.stayPerPerson,
      sub:
        nightsCount > 0
          ? `${nightsCount} இரவு × ₹${plan.destination.avgHotelPerPerson} = ₹${plan.stayPerPerson}/நபர்`
          : "1 நாள் பயணம் (₹0 இரவு தங்கல்)",
    },
    {
      title: "🍽️ 3. உணவு / Food & Dining",
      total: plan.foodTotal,
      pp: plan.foodPerPerson,
      sub: `${plan.days} நாள் × ₹${plan.destination.avgFoodPerDay}/நாள் = ₹${plan.foodPerPerson}/நபர்`,
    },
    {
      title: "🏛️ 4. சுற்றுலா இடங்கள் / Spots",
      total: plan.sightseeingTotal,
      pp: plan.sightseeingPerPerson,
      sub: `${plan.uniqueSpotsVisited.length} இடங்கள் நுழைவு & ஆட்டோ = ₹${plan.sightseeingPerPerson}/நபர்`,
    },
  ];

  const bBoxH = 136;
  budgetBoxes.forEach((b, idx) => {
    const bx = MARGIN_X + idx * (cardW + cardGap);
    drawRoundedRect(ctx, bx, y, cardW, bBoxH, 16, "#faf8ff", "#c4b5fd", 2);
    ctx.fillStyle = "#1e293b";
    ctx.font = `bold 17px ${FONT_FAMILY}`;
    ctx.fillText(b.title, bx + 14, y + 14);

    // Per Person Pill
    drawRoundedRect(ctx, bx + 14, y + 42, cardW - 28, 34, 8, "#047857");
    ctx.fillStyle = "#ffffff";
    ctx.font = `bold 17.5px ${FONT_FAMILY}`;
    ctx.fillText(
      `👤 நபர் 1-க்கு: ₹${b.pp.toLocaleString("en-IN")}`,
      bx + 24,
      y + 50
    );

    ctx.fillStyle = theme.primaryDark;
    ctx.font = `bold 20px ${FONT_FAMILY}`;
    ctx.fillText(
      `👥 மொத்தம் (${plan.people} நபர்): ₹${b.total.toLocaleString("en-IN")}`,
      bx + 14,
      y + 84
    );

    ctx.fillStyle = "#475569";
    ctx.font = `bold 14.5px ${FONT_FAMILY}`;
    ctx.fillText(b.sub, bx + 14, y + 111);
  });

  y += bBoxH + 14;

  // Exact Mathematical Formula Bar
  drawRoundedRect(ctx, MARGIN_X, y, CONTENT_W, 50, 12, "#ecfdf5", "#10b981", 2);
  ctx.fillStyle = "#065f46";
  ctx.font = `bold 17px ${FONT_FAMILY}`;
  ctx.fillText(
    `✓ துல்லியமான கணக்கு (Exact Sum): போக்குவரத்து (₹${plan.travelPerPerson}) + விடுதி (₹${plan.stayPerPerson}) + உணவு (₹${plan.foodPerPerson}) + ${plan.uniqueSpotsVisited.length} சுற்றுலா இடங்கள் (₹${plan.sightseeingPerPerson}) = ₹${estPerPersonTotal.toLocaleString("en-IN")}/நபர் × ${plan.people} = ₹${plan.estimatedTotalCost.toLocaleString("en-IN")}`,
    MARGIN_X + 18,
    y + 15
  );

  y += 68;

  // =========================================================================
  // 4. ALL UNIQUE TOURIST PLACES DIRECTORY (வெவ்வேறு சுற்றுலாத் தலங்களின் பட்டியல்)
  // =========================================================================
  ensureSpace(240);
  ctx.fillStyle = theme.primaryDark;
  ctx.font = `bold 23px ${FONT_FAMILY}`;
  ctx.fillText(
    `2. ${plan.destNameTa} (${plan.destination.name}) – செல்லும் ${plan.uniqueSpotsVisited.length} வெவ்வேறு சுற்றுலாத் தலங்கள் (All Unique Tourist Places, Time & Exact Cost)`,
    MARGIN_X,
    y
  );
  y += 36;

  const spotCardGap = 18;
  const spotCardW = (CONTENT_W - spotCardGap) / 2;
  const spotCardH = 178;

  for (let i = 0; i < plan.uniqueSpotsVisited.length; i += 2) {
    ensureSpace(spotCardH + 16);

    const pair = plan.uniqueSpotsVisited.slice(i, i + 2);
    pair.forEach((spot, colIdx) => {
      const sx = MARGIN_X + colIdx * (spotCardW + spotCardGap);
      drawRoundedRect(
        ctx,
        sx,
        y,
        spotCardW,
        spotCardH,
        16,
        "#ffffff",
        "#cbd5e1",
        2
      );

      // Left vertical accent stripe
      drawRoundedRect(ctx, sx, y, 10, spotCardH, 5, theme.primary);

      // Top Row Badges — dynamically measured so they NEVER overlap!
      const b1Text = `📍 இடம் #${spot.spotIndex} • Day ${spot.dayNumber}`;
      ctx.font = `bold 15.5px ${FONT_FAMILY}`;
      const b1W = Math.ceil(ctx.measureText(b1Text).width) + 24;
      drawRoundedRect(ctx, sx + 22, y + 12, b1W, 32, 8, theme.primary);
      ctx.fillStyle = "#ffffff";
      ctx.fillText(b1Text, sx + 34, y + 20);

      const b2Text = `🕒 ${spot.timeSlot}`;
      ctx.font = `bold 15.5px ${FONT_FAMILY}`;
      const b2W = Math.ceil(ctx.measureText(b2Text).width) + 24;
      const b2X = sx + 22 + b1W + 10;
      drawRoundedRect(
        ctx,
        b2X,
        y + 12,
        b2W,
        32,
        8,
        "#fef3c7",
        "#f59e0b",
        1.5
      );
      ctx.fillStyle = "#92400e";
      ctx.fillText(b2Text, b2X + 12, y + 20);

      // Per-Person Price Badge (Right aligned)
      const b3Text = `👤 ₹${spot.perPersonCost}/நபர்`;
      ctx.font = `bold 16px ${FONT_FAMILY}`;
      const b3W = Math.ceil(ctx.measureText(b3Text).width) + 24;
      const b3X = sx + spotCardW - b3W - 14;
      drawRoundedRect(
        ctx,
        b3X,
        y + 12,
        b3W,
        32,
        8,
        "#dcfce7",
        "#10b981",
        1.5
      );
      ctx.fillStyle = "#065f46";
      ctx.fillText(b3Text, b3X + 12, y + 20);

      // Spot Name (English)
      ctx.fillStyle = "#0f172a";
      ctx.font = `bold 19.5px ${FONT_FAMILY}`;
      const enSpotLine = wrapLines(ctx, spot.spotName, spotCardW - 38)[0];
      ctx.fillText(enSpotLine, sx + 22, y + 52);

      // Spot Name (Tamil / Hindi)
      ctx.fillStyle = theme.primaryDark;
      ctx.font = `bold 17.5px ${FONT_FAMILY}`;
      const secondaryPlaceText =
        lang === "hi"
          ? `${spot.spotNameTa} • ${spot.spotNameHi}`
          : spot.spotNameTa;
      const taSpotLine = wrapLines(ctx, secondaryPlaceText, spotCardW - 38)[0];
      ctx.fillText(taSpotLine, sx + 22, y + 80);

      // Activity line
      ctx.fillStyle = "#475569";
      ctx.font = `16px ${FONT_FAMILY}`;
      const actLine = wrapLines(ctx, spot.activity, spotCardW - 38)[0];
      ctx.fillText(actLine, sx + 22, y + 108);

      // Bottom accurate amount bar inside card
      drawRoundedRect(
        ctx,
        sx + 20,
        y + 136,
        spotCardW - 34,
        30,
        7,
        "#f8fafc",
        "#e2e8f0",
        1
      );
      ctx.fillStyle = "#0f172a";
      ctx.font = `bold 15px ${FONT_FAMILY}`;
      ctx.fillText(
        `🎫 நுழைவு & ஆட்டோ (Entry + Local): ₹${spot.perPersonCost}/நபர்  ×  ${plan.people} நபர்  =  மொத்தம் ₹${spot.totalCost.toLocaleString("en-IN")}`,
        sx + 30,
        y + 143
      );
    });

    y += spotCardH + 14;
  }

  y += 14;

  // =========================================================================
  // 5. DAY-BY-DAY SEQUENTIAL TIMELINE TABLE (நாள் வாரியான வரிசைப் பயணத் திட்டம்)
  // =========================================================================
  ensureSpace(240);
  ctx.fillStyle = theme.primaryDark;
  ctx.font = `bold 23px ${FONT_FAMILY}`;
  ctx.fillText(
    "3. நாள் வாரியான வரிசைப் பயணத் திட்டம் / Day-Wise Sequential Schedule (Time, Accurate Place & Exact Amount)",
    MARGIN_X,
    y
  );
  y += 36;

  const colW = [
    Math.round(CONTENT_W * 0.23), // Order & Time
    Math.round(CONTENT_W * 0.27), // Tourist Place
    Math.round(CONTENT_W * 0.31), // Activity & Breakdown
    CONTENT_W -
      Math.round(CONTENT_W * 0.23) -
      Math.round(CONTENT_W * 0.27) -
      Math.round(CONTENT_W * 0.31), // Cost (19%)
  ];
  const colX = [
    MARGIN_X,
    MARGIN_X + colW[0],
    MARGIN_X + colW[0] + colW[1],
    MARGIN_X + colW[0] + colW[1] + colW[2],
  ];

  const drawDayAndTableHeader = (dayItem: PdfDayPlan, isContinued: boolean) => {
    const dayHeaderH = 84;
    drawRoundedRect(
      ctx,
      MARGIN_X,
      y,
      CONTENT_W,
      dayHeaderH,
      14,
      theme.tagBg,
      theme.primary,
      2
    );

    ctx.fillStyle = theme.primaryDark;
    ctx.font = `bold 21px ${FONT_FAMILY}`;
    const dayEnTitle = wrapLines(
      ctx,
      `🗓️ Day ${dayItem.day}: ${dayItem.dayTitle}${isContinued ? " (Contd.)" : ""}`,
      CONTENT_W - 530
    )[0];
    ctx.fillText(dayEnTitle, MARGIN_X + 20, y + 14);

    ctx.fillStyle = "#334155";
    ctx.font = `bold 18px ${FONT_FAMILY}`;
    const dayTaTitle = wrapLines(
      ctx,
      `நாள் ${dayItem.day}: ${dayItem.dayTitleTa} • दिन ${dayItem.day}: ${dayItem.dayTitleHi}`,
      CONTENT_W - 530
    )[0];
    ctx.fillText(dayTaTitle, MARGIN_X + 20, y + 46);

    const pillText = `👤 ₹${dayItem.dayPerPersonCost.toLocaleString("en-IN")}/நபர்  |  👥 மொத்தம்: ₹${dayItem.dayTotalCost.toLocaleString("en-IN")}`;
    ctx.font = `bold 18px ${FONT_FAMILY}`;
    const pillW = ctx.measureText(pillText).width + 34;
    const pillX = MARGIN_X + CONTENT_W - pillW - 16;
    drawRoundedRect(ctx, pillX, y + 20, pillW, 44, 10, theme.primary);
    ctx.fillStyle = "#ffffff";
    ctx.fillText(pillText, pillX + 17, y + 32);

    y += dayHeaderH;

    const thH = 48;
    ctx.fillStyle = "#1e293b";
    ctx.fillRect(MARGIN_X, y, CONTENT_W, thH);

    const headers = [
      "🕒 வரிசை & நேரம் / Time Slot",
      "📍 செல்லும் இடம் / Tourist Place",
      "✨ செயல்பாடு & விவரம் / Activity",
      "💰 நபர் 1-க்கு & மொத்த செலவு",
    ];
    ctx.fillStyle = "#ffffff";
    ctx.font = `bold 17px ${FONT_FAMILY}`;
    headers.forEach((hText, i) => {
      ctx.fillText(hText, colX[i] + 14, y + 15);
    });

    y += thH;
  };

  for (const dayItem of plan.itinerary) {
    ensureSpace(84 + 48 + 165);
    drawDayAndTableHeader(dayItem, false);

    for (let sIdx = 0; sIdx < dayItem.slots.length; sIdx++) {
      const slot = dayItem.slots[sIdx];
      const padX = 14;
      const padY = 14;
      const lineH = 25;

      const isSpot = slot.slotType === "spot";

      ctx.font = `bold 18.5px ${FONT_FAMILY}`;
      const placeEnLines = wrapLines(ctx, slot.place, colW[1] - padX * 2);
      ctx.font = `bold 17.5px ${FONT_FAMILY}`;
      const placeSubText =
        lang === "hi" ? `${slot.placeTa} (${slot.placeHi})` : slot.placeTa;
      const placeTaLines = wrapLines(ctx, placeSubText, colW[1] - padX * 2);

      ctx.font = `17.5px ${FONT_FAMILY}`;
      const actEnLines = wrapLines(ctx, slot.activity, colW[2] - padX * 2);
      ctx.font = `16.5px ${FONT_FAMILY}`;
      const actSubText =
        lang === "hi" ? slot.activityHi : slot.activityTa;
      const actTaLines = wrapLines(ctx, actSubText, colW[2] - padX * 2);
      ctx.font = `bold 15.5px ${FONT_FAMILY}`;
      const noteLines = wrapLines(
        ctx,
        `💳 ${slot.costBreakdownNote}`,
        colW[2] - padX * 2
      );

      const col2Lines = placeEnLines.length + placeTaLines.length + 1;
      const col3Lines = actEnLines.length + actTaLines.length + noteLines.length;
      const maxLines = Math.max(col2Lines, col3Lines, 4);

      const rowH = Math.max(138, padY * 2 + maxLines * lineH + 12);

      if (y + rowH > PAGE_H - MARGIN_BOTTOM) {
        flushPageToPdf(false);
        drawDayAndTableHeader(dayItem, true);
      }

      ctx.fillStyle = isSpot ? "#fffdf5" : "#ffffff";
      ctx.fillRect(MARGIN_X, y, CONTENT_W, rowH);
      ctx.strokeStyle = "#cbd5e1";
      ctx.lineWidth = 1.5;
      ctx.strokeRect(MARGIN_X, y, CONTENT_W, rowH);

      for (let c = 1; c < 4; c++) {
        ctx.beginPath();
        ctx.moveTo(colX[c], y);
        ctx.lineTo(colX[c], y + rowH);
        ctx.stroke();
      }

      // Column 1: Order Badge + Time Pill + Tamil/Hindi Time
      let curY = y + padY;
      const badgeLabel =
        slot.slotType === "spot"
          ? `#${slot.order} • சுற்றுலாத் தலம் (SPOT)`
          : slot.slotType === "food"
          ? `#${slot.order} • உணவு (FOOD)`
          : slot.slotType === "travel"
          ? `#${slot.order} • பயணம் (TRAVEL)`
          : `#${slot.order} • தங்குமிடம் (STAY)`;
      const badgeBg =
        slot.slotType === "spot"
          ? theme.primary
          : slot.slotType === "food"
          ? "#d97706"
          : slot.slotType === "travel"
          ? "#0284c7"
          : "#4f46e5";

      drawRoundedRect(
        ctx,
        colX[0] + padX,
        curY,
        colW[0] - padX * 2,
        30,
        7,
        badgeBg
      );
      ctx.fillStyle = "#ffffff";
      ctx.font = `bold 15px ${FONT_FAMILY}`;
      ctx.fillText(badgeLabel, colX[0] + padX + 10, curY + 7);
      curY += 36;

      drawRoundedRect(
        ctx,
        colX[0] + padX,
        curY,
        colW[0] - padX * 2,
        32,
        7,
        "#fef3c7",
        "#f59e0b",
        1.5
      );
      ctx.fillStyle = "#92400e";
      ctx.font = `bold 16px ${FONT_FAMILY}`;
      ctx.fillText(`🕒 ${slot.time}`, colX[0] + padX + 10, curY + 8);
      curY += 38;

      ctx.fillStyle = theme.primaryDark;
      ctx.font = `bold 16px ${FONT_FAMILY}`;
      ctx.fillText(
        lang === "hi" ? `${slot.timeTa} • ${slot.timeHi}` : slot.timeTa,
        colX[0] + padX + 4,
        curY
      );

      // Column 2: Place (English + Tamil/Hindi)
      curY = y + padY;
      ctx.fillStyle = "#0f172a";
      ctx.font = `bold 18.5px ${FONT_FAMILY}`;
      placeEnLines.forEach((l) => {
        ctx.fillText(l, colX[1] + padX, curY);
        curY += lineH;
      });
      ctx.fillStyle = theme.primaryDark;
      ctx.font = `bold 17.5px ${FONT_FAMILY}`;
      placeTaLines.forEach((l) => {
        ctx.fillText(l, colX[1] + padX, curY + 2);
        curY += lineH;
      });

      // Column 3: Activity + Exact Cost Breakdown Note
      curY = y + padY;
      ctx.fillStyle = "#334155";
      ctx.font = `17px ${FONT_FAMILY}`;
      actEnLines.forEach((l) => {
        ctx.fillText(l, colX[2] + padX, curY);
        curY += lineH;
      });
      ctx.fillStyle = theme.primaryDark;
      ctx.font = `16.5px ${FONT_FAMILY}`;
      actTaLines.forEach((l) => {
        ctx.fillText(l, colX[2] + padX, curY + 2);
        curY += lineH;
      });
      ctx.fillStyle = "#047857";
      ctx.font = `bold 15.5px ${FONT_FAMILY}`;
      noteLines.forEach((l) => {
        ctx.fillText(l, colX[2] + padX, curY + 4);
        curY += lineH;
      });

      // Column 4: Per-Person Cost Pill + Group Total Pill
      curY = y + padY;
      const costBoxW = colW[3] - padX * 2;

      drawRoundedRect(
        ctx,
        colX[3] + padX,
        curY,
        costBoxW,
        44,
        9,
        "#ecfdf5",
        "#10b981",
        2
      );
      ctx.fillStyle = "#065f46";
      ctx.font = `bold 14.5px ${FONT_FAMILY}`;
      ctx.fillText("👤 நபர் 1-க்கு / Per Person", colX[3] + padX + 10, curY + 5);
      ctx.fillStyle = "#047857";
      ctx.font = `bold 19px ${FONT_FAMILY}`;
      ctx.fillText(
        `₹${slot.costPerPerson.toLocaleString("en-IN")}`,
        colX[3] + padX + 10,
        curY + 22
      );

      curY += 52;

      drawRoundedRect(
        ctx,
        colX[3] + padX,
        curY,
        costBoxW,
        44,
        9,
        "#f8fafc",
        "#94a3b8",
        1.5
      );
      ctx.fillStyle = "#475569";
      ctx.font = `bold 14px ${FONT_FAMILY}`;
      ctx.fillText(
        `👥 மொத்தம் (${plan.people} நபர்)`,
        colX[3] + padX + 10,
        curY + 5
      );
      ctx.fillStyle = "#0f172a";
      ctx.font = `bold 19px ${FONT_FAMILY}`;
      ctx.fillText(
        `₹${slot.totalSlotCost.toLocaleString("en-IN")}`,
        colX[3] + padX + 10,
        curY + 22
      );

      y += rowH;
    }

    y += 22;
  }

  flushPageToPdf(true);

  const sanitizedDestination = plan.destination.name
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, "-");
  pdf.save(`tn-travel-plan-${sanitizedDestination}.pdf`);
}

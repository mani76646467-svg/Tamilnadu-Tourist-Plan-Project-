import React, { useState, useEffect, useRef } from "react";
import {
  APIProvider,
  Map,
  AdvancedMarker,
  InfoWindow,
  useMap,
  useMapsLibrary,
} from "@vis.gl/react-google-maps";
import { UniqueSpotSummary } from "../utils/pdfGenerator";
import { AppLanguage } from "../data/i18n";

interface LatLngPoint {
  lat: number;
  lng: number;
}

interface MapPolylineInstance {
  setMap: (map: unknown) => void;
  setOptions: (opts: Record<string, unknown>) => void;
}

interface ResolvedItineraryStop {
  spot: UniqueSpotSummary;
  position: LatLngPoint;
  formattedAddress: string;
  googleMapsUri: string;
}

interface RouteMetrics {
  distanceMeters: number;
  durationMillis: number;
}

interface ItineraryRouteMapProps {
  destinationName: string;
  destDisplayName: string;
  district: string;
  days: number;
  uniqueSpots: UniqueSpotSummary[];
  lang: AppLanguage;
  primaryColor: string;
}

type MapTravelMode = "DRIVING" | "WALKING" | "TWO_WHEELER";

const MAP_UI_STRINGS: Record<
  AppLanguage,
  {
    kicker: string;
    title: (dest: string, days: number) => string;
    subtitle: string;
    allDaysTab: (count: number) => string;
    dayTab: (day: number) => string;
    modeDriving: string;
    modeWalking: string;
    modeTwoWheeler: string;
    totalDistanceLabel: string;
    estDriveTimeLabel: string;
    stopsCountLabel: string;
    resolvingLocations: string;
    computingRoute: string;
    pathSequenceTitle: string;
    perPersonLabel: string;
    openInGoogleMaps: string;
    dayBadge: (d: number) => string;
  }
> = {
  ta: {
    kicker:
      "🗺️ கூகுள் மேப்ஸ் சுற்றுலா வழித்தட வரைபடம் (GOOGLE MAPS VISUAL ITINERARY)",
    title: (dest, days) =>
      `${dest} — ${days} நாள் சுற்றுலாத் தலங்களின் வழித்தட வரைபடம்`,
    subtitle:
      "தேர்ந்தெடுக்கப்பட்ட நாட்களில் நீங்கள் செல்லும் ஒவ்வொரு சுற்றுலாத் தலத்தையும் இணைக்கும் துல்லியமான வழித்தடம் (Route Path), தூரம் மற்றும் பயண நேரம்.",
    allDaysTab: (count) => `அனைத்து நாட்கள் (${count} இடங்கள்)`,
    dayTab: (day) => `நாள் ${day} (Day ${day})`,
    modeDriving: "🚗 கார் / பேருந்து",
    modeWalking: "🚶 நடைப்பயணம்",
    modeTwoWheeler: "🛵 இருசக்கர வாகனம்",
    totalDistanceLabel: "மொத்த வழித்தட தூரம்",
    estDriveTimeLabel: "பயண நேரம் (தோராயமாக)",
    stopsCountLabel: "சுற்றுலா நிறுத்தங்கள்",
    resolvingLocations:
      "📍 கூகுள் மேப்ஸில் சுற்றுலாத் தலங்களின் இடங்கள் கண்டறியப்படுகின்றன...",
    computingRoute:
      "🛣️ சுற்றுலாத் தலங்களுக்கு இடையிலான வழித்தடம் கணக்கிடப்படுகிறது...",
    pathSequenceTitle:
      "🧭 வரிசைப்படி சுற்றுலா வழித்தடம் (மார்க்கரை அல்லது எண்ணை அழுத்தி விவரம் பார்க்க):",
    perPersonLabel: "நபர் 1-க்கு",
    openInGoogleMaps: "Google Maps-இல் திறக்க ↗",
    dayBadge: (d) => `நாள் ${d}`,
  },
  en: {
    kicker: "🗺️ INTERACTIVE GOOGLE MAPS ITINERARY & ROUTE PATH",
    title: (dest, days) => `${dest} — ${days}-Day Visual Itinerary Route Map`,
    subtitle:
      "Interactive map showing the connected travel path between your selected tourist spots across each day of your trip.",
    allDaysTab: (count) => `All Days (${count} Spots)`,
    dayTab: (day) => `Day ${day}`,
    modeDriving: "🚗 Driving",
    modeWalking: "🚶 Walking",
    modeTwoWheeler: "🛵 Two-Wheeler",
    totalDistanceLabel: "Total Route Distance",
    estDriveTimeLabel: "Est. Travel Time",
    stopsCountLabel: "Tourist Stops",
    resolvingLocations: "📍 Locating tourist spots on Google Maps...",
    computingRoute: "🛣️ Computing route path between tourist spots...",
    pathSequenceTitle:
      "🧭 Step-by-Step Tourist Spot Path (Click any stop to focus on map):",
    perPersonLabel: "Per Person",
    openInGoogleMaps: "Open in Google Maps ↗",
    dayBadge: (d) => `Day ${d}`,
  },
  hi: {
    kicker: "🗺️ गूगल मैप्स यात्रा मार्ग और दर्शनीय स्थल मानचित्र",
    title: (dest, days) =>
      `${dest} — ${days}-दिवसीय पर्यटन मार्ग मानचित्र (Visual Itinerary Map)`,
    subtitle:
      "चयनित दिनों के लिए सभी पर्यटन स्थलों के बीच का मार्ग (Route Path), दूरी और यात्रा समय दिखाने वाला इंटरैक्टिव मानचित्र।",
    allDaysTab: (count) => `सभी दिन (${count} स्थल)`,
    dayTab: (day) => `दिन ${day}`,
    modeDriving: "🚗 ड्राइविंग",
    modeWalking: "🚶 पैदल",
    modeTwoWheeler: "🛵 दोपहिया",
    totalDistanceLabel: "कुल मार्ग दूरी",
    estDriveTimeLabel: "अनुमानित यात्रा समय",
    stopsCountLabel: "पर्यटन स्थल",
    resolvingLocations: "📍 गूगल मैप्स पर पर्यटन स्थलों का स्थान खोजा जा रहा है...",
    computingRoute: "🛣️ पर्यटन स्थलों के बीच का मार्ग गणना की जा रही है...",
    pathSequenceTitle:
      "🧭 क्रमबद्ध पर्यटन मार्ग (मानचित्र पर देखने के लिए किसी भी स्थल पर क्लिक करें):",
    perPersonLabel: "प्रति व्यक्ति",
    openInGoogleMaps: "Google Maps में खोलें ↗",
    dayBadge: (d) => `दिन ${d}`,
  },
};

function checkAndDispatchQuotaError(err: unknown) {
  const msg = err instanceof Error ? err.message : String(err);
  if (
    msg.includes("OVER_QUERY_LIMIT") ||
    msg.includes("RESOURCE_EXHAUSTED") ||
    msg.includes("429") ||
    msg.includes("QuotaExceeded") ||
    msg.includes("OverQuotaMapError")
  ) {
    window.dispatchEvent(new CustomEvent("gmp-quota-exceeded"));
  }
}

function formatDuration(durationMillis: number): string {
  const totalMinutes = Math.max(1, Math.round(durationMillis / 60000));
  if (totalMinutes < 60) {
    return `${totalMinutes} mins`;
  }
  const hrs = Math.floor(totalMinutes / 60);
  const mins = totalMinutes % 60;
  return mins > 0 ? `${hrs} hr ${mins} mins` : `${hrs} hr`;
}

interface ItineraryMapInnerProps {
  destinationName: string;
  district: string;
  uniqueSpots: UniqueSpotSummary[];
  resolvedStops: ResolvedItineraryStop[];
  selectedDay: "all" | number;
  travelMode: MapTravelMode;
  lang: AppLanguage;
  primaryColor: string;
  activeStopNumber: number | null;
  onSelectStop: (spotNumber: number | null) => void;
  onResolvedStopsChange: (stops: ResolvedItineraryStop[]) => void;
  onRouteMetricsChange: (metrics: RouteMetrics | null) => void;
  onStatusChange: (status: { resolving: boolean; routing: boolean }) => void;
}

const ItineraryMapInner: React.FC<ItineraryMapInnerProps> = ({
  destinationName,
  district,
  uniqueSpots,
  resolvedStops,
  selectedDay,
  travelMode,
  lang,
  primaryColor,
  activeStopNumber,
  onSelectStop,
  onResolvedStopsChange,
  onRouteMetricsChange,
  onStatusChange,
}) => {
  const map = useMap();
  const coreLib = useMapsLibrary("core");
  const mapsLib = useMapsLibrary("maps");
  const placesLib = useMapsLibrary("places");
  const routesLib = useMapsLibrary("routes");

  const polylinesRef = useRef<MapPolylineInstance[]>([]);
  const placeCacheRef = useRef<
    Record<
      string,
      {
        position: LatLngPoint;
        formattedAddress: string;
      }
    >
  >({});
  const lastResolvedKeyRef = useRef<string>("");
  const lastRouteKeyRef = useRef<string>("");

  // 1. Resolve tourist spot coordinates dynamically using Google Maps Places API (New) `Place.searchByText`
  useEffect(() => {
    if (!placesLib || uniqueSpots.length === 0) return;

    const spotsKey = `${destinationName}::${district}::${uniqueSpots
      .map((s) => s.spotIndex)
      .join(",")}`;

    if (lastResolvedKeyRef.current === spotsKey) {
      return;
    }

    let cancelled = false;
    onStatusChange({ resolving: true, routing: false });

    async function resolveAllSpots() {
      const results: ResolvedItineraryStop[] = [];

      // First resolve destination city center as a fallback anchor if needed
      let cityCenter: LatLngPoint | null = null;
      const cityKey = `city::${destinationName}::${district}`;
      if (placeCacheRef.current[cityKey]) {
        cityCenter = placeCacheRef.current[cityKey].position;
      } else {
        try {
          // eslint-disable-next-line @typescript-eslint/no-explicit-any
          const cityRes = await (placesLib!.Place as any).searchByText({
            textQuery: `${destinationName}, ${district} District, Tamil Nadu, India`,
            fields: ["id", "displayName", "location", "formattedAddress"],
            maxResultCount: 1,
          });
          const firstCity = cityRes?.places?.[0];
          if (firstCity?.location) {
            const lat =
              typeof firstCity.location.lat === "function"
                ? firstCity.location.lat()
                : firstCity.location.lat;
            const lng =
              typeof firstCity.location.lng === "function"
                ? firstCity.location.lng()
                : firstCity.location.lng;
            cityCenter = { lat, lng };
            placeCacheRef.current[cityKey] = {
              position: cityCenter,
              formattedAddress:
                firstCity.formattedAddress ||
                `${destinationName}, Tamil Nadu, India`,
            };
          }
        } catch (err) {
          checkAndDispatchQuotaError(err);
        }
      }

      for (let i = 0; i < uniqueSpots.length; i++) {
        if (cancelled) return;
        const spot = uniqueSpots[i];
        const cacheKey = `${destinationName}::${spot.spotName}`;

        if (placeCacheRef.current[cacheKey]) {
          const cached = placeCacheRef.current[cacheKey];
          results.push({
            spot,
            position: cached.position,
            formattedAddress: cached.formattedAddress,
            googleMapsUri: `https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(
              `${spot.spotName}, ${destinationName}, Tamil Nadu`
            )}`,
          });
          continue;
        }

        try {
          // eslint-disable-next-line @typescript-eslint/no-explicit-any
          const searchRes = await (placesLib!.Place as any).searchByText({
            textQuery: `${spot.spotName}, ${destinationName}, Tamil Nadu, India`,
            fields: ["id", "displayName", "location", "formattedAddress"],
            maxResultCount: 1,
          });

          const placeObj = searchRes?.places?.[0];
          if (placeObj?.location) {
            const lat =
              typeof placeObj.location.lat === "function"
                ? placeObj.location.lat()
                : placeObj.location.lat;
            const lng =
              typeof placeObj.location.lng === "function"
                ? placeObj.location.lng()
                : placeObj.location.lng;

            const pos = { lat, lng };
            const addr =
              placeObj.formattedAddress ||
              `${spot.spotName}, ${destinationName}, Tamil Nadu`;

            placeCacheRef.current[cacheKey] = {
              position: pos,
              formattedAddress: addr,
            };

            results.push({
              spot,
              position: pos,
              formattedAddress: addr,
              googleMapsUri: `https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(
                `${spot.spotName}, ${destinationName}, Tamil Nadu`
              )}`,
            });
          } else if (cityCenter) {
            const angle = (i * 2 * Math.PI) / Math.max(1, uniqueSpots.length);
            const pos = {
              lat: cityCenter.lat + 0.012 * Math.cos(angle),
              lng: cityCenter.lng + 0.012 * Math.sin(angle),
            };
            results.push({
              spot,
              position: pos,
              formattedAddress: `${spot.spotName}, ${destinationName}, ${district} District, Tamil Nadu`,
              googleMapsUri: `https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(
                `${spot.spotName}, ${destinationName}, Tamil Nadu`
              )}`,
            });
          }
        } catch (err) {
          checkAndDispatchQuotaError(err);
          if (cityCenter) {
            const angle = (i * 2 * Math.PI) / Math.max(1, uniqueSpots.length);
            const pos = {
              lat: cityCenter.lat + 0.012 * Math.cos(angle),
              lng: cityCenter.lng + 0.012 * Math.sin(angle),
            };
            results.push({
              spot,
              position: pos,
              formattedAddress: `${spot.spotName}, ${destinationName}, Tamil Nadu`,
              googleMapsUri: `https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(
                `${spot.spotName}, ${destinationName}, Tamil Nadu`
              )}`,
            });
          }
        }
      }

      if (!cancelled) {
        lastResolvedKeyRef.current = spotsKey;
        onResolvedStopsChange(results);
        onStatusChange({ resolving: false, routing: false });
      }
    }

    resolveAllSpots();

    return () => {
      cancelled = true;
    };
  }, [
    placesLib,
    destinationName,
    district,
    uniqueSpots,
    onResolvedStopsChange,
    onStatusChange,
  ]);

  // Memoize visibleStops so reference is stable and does not cause infinite re-renders
  const visibleStops = React.useMemo(() => {
    return selectedDay === "all"
      ? resolvedStops
      : resolvedStops.filter((s) => s.spot.dayNumber === selectedDay);
  }, [resolvedStops, selectedDay]);

  // 2. Compute and render the route path between visible tourist spots using modern Routes API (`Route.computeRoutes`)
  useEffect(() => {
    if (!map || !routesLib) return;

    if (visibleStops.length === 0) {
      if (lastRouteKeyRef.current !== "empty") {
        lastRouteKeyRef.current = "empty";
        onRouteMetricsChange(null);
        onStatusChange({ resolving: false, routing: false });
      }
      polylinesRef.current.forEach((p) => p.setMap(null));
      polylinesRef.current = [];
      return;
    }

    const routeKey = `${selectedDay}::${travelMode}::${primaryColor}::${visibleStops
      .map((s) => `${s.position.lat.toFixed(4)},${s.position.lng.toFixed(4)}`)
      .join(";")}`;

    if (lastRouteKeyRef.current === routeKey) {
      return;
    }

    // Clean up previous polylines
    polylinesRef.current.forEach((p) => p.setMap(null));
    polylinesRef.current = [];

    if (visibleStops.length === 1) {
      lastRouteKeyRef.current = routeKey;
      map.panTo(visibleStops[0].position);
      map.setZoom(14);
      onRouteMetricsChange({ distanceMeters: 0, durationMillis: 0 });
      onStatusChange({ resolving: false, routing: false });
      return;
    }

    let cancelled = false;
    onStatusChange({ resolving: false, routing: true });

    const originPos = visibleStops[0].position;
    const destinationPos = visibleStops[visibleStops.length - 1].position;
    const intermediateStops = visibleStops
      .slice(1, -1)
      .map((s) => ({ location: s.position }));

    const drawDirectConnectorFallback = () => {
      if (cancelled || !map || !mapsLib || !coreLib) return;
      const pathCoords = visibleStops.map((s) => s.position);
      // eslint-disable-next-line @typescript-eslint/no-explicit-any
      const PolylineCtor = (mapsLib as any).Polyline;
      if (PolylineCtor) {
        const fallbackLine: MapPolylineInstance = new PolylineCtor({
          path: pathCoords,
          geodesic: true,
          strokeColor: primaryColor || "#0f766e",
          strokeOpacity: 0.9,
          strokeWeight: 5,
          map,
        });
        polylinesRef.current = [fallbackLine];
      }

      // eslint-disable-next-line @typescript-eslint/no-explicit-any
      const BoundsCtor = (coreLib as any).LatLngBounds;
      if (BoundsCtor) {
        const bounds = new BoundsCtor();
        pathCoords.forEach((pt) => bounds.extend(pt));
        map.fitBounds(bounds, 55);
      }
    };

    // Use modern Route.computeRoutes from @vis.gl/react-google-maps useMapsLibrary('routes')
    // Source: Google Maps Platform Code Assist
    const request: Record<string, unknown> = {
      origin: originPos,
      destination: destinationPos,
      travelMode: travelMode,
      fields: ["path", "distanceMeters", "durationMillis", "viewport", "legs"],
    };

    if (intermediateStops.length > 0) {
      request.intermediates = intermediateStops;
    }

    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    const RouteClass = (routesLib as any).Route;
    if (RouteClass && typeof RouteClass.computeRoutes === "function") {
      RouteClass.computeRoutes(request)
        // eslint-disable-next-line @typescript-eslint/no-explicit-any
        .then((res: { routes?: any[] }) => {
          if (cancelled) return;
          lastRouteKeyRef.current = routeKey;
          onStatusChange({ resolving: false, routing: false });

          const primaryRoute = res?.routes?.[0];
          if (!primaryRoute) {
            drawDirectConnectorFallback();
            return;
          }

          if (typeof primaryRoute.createPolylines === "function") {
            const newPolylines: MapPolylineInstance[] =
              primaryRoute.createPolylines();
            newPolylines.forEach((polyline) => {
              polyline.setOptions({
                strokeColor: primaryColor || "#0f766e",
                strokeWeight: 5,
                strokeOpacity: 0.92,
              });
              polyline.setMap(map);
            });
            polylinesRef.current = newPolylines;
          } else {
            drawDirectConnectorFallback();
          }

          if (primaryRoute.viewport) {
            map.fitBounds(primaryRoute.viewport);
          } else if (coreLib) {
            // eslint-disable-next-line @typescript-eslint/no-explicit-any
            const BoundsCtor = (coreLib as any).LatLngBounds;
            if (BoundsCtor) {
              const bounds = new BoundsCtor();
              visibleStops.forEach((s) => bounds.extend(s.position));
              map.fitBounds(bounds, 55);
            }
          }

          onRouteMetricsChange({
            distanceMeters: primaryRoute.distanceMeters ?? 0,
            durationMillis: primaryRoute.durationMillis ?? 0,
          });
        })
        .catch((err: unknown) => {
          if (cancelled) return;
          lastRouteKeyRef.current = routeKey;
          checkAndDispatchQuotaError(err);
          onStatusChange({ resolving: false, routing: false });
          drawDirectConnectorFallback();
        });
    } else {
      lastRouteKeyRef.current = routeKey;
      onStatusChange({ resolving: false, routing: false });
      drawDirectConnectorFallback();
    }

    return () => {
      cancelled = true;
      polylinesRef.current.forEach((p) => p.setMap(null));
      polylinesRef.current = [];
    };
  }, [
    map,
    coreLib,
    mapsLib,
    routesLib,
    visibleStops,
    selectedDay,
    travelMode,
    primaryColor,
    onRouteMetricsChange,
    onStatusChange,
  ]);

  // Pan to active stop when selected from the sequence bar
  useEffect(() => {
    if (!map || activeStopNumber === null) return;
    const found = visibleStops.find(
      (s) => s.spot.spotIndex === activeStopNumber
    );
    if (found) {
      map.panTo(found.position);
    }
  }, [map, activeStopNumber, visibleStops]);

  const activeStopObj =
    activeStopNumber !== null
      ? visibleStops.find((s) => s.spot.spotIndex === activeStopNumber) || null
      : null;

  const ui = MAP_UI_STRINGS[lang];

  const getLocalizedSpotName = (spot: UniqueSpotSummary) => {
    if (lang === "ta") return spot.spotNameTa;
    if (lang === "hi") return spot.spotNameHi;
    return spot.spotName;
  };

  const getLocalizedActivity = (spot: UniqueSpotSummary) => {
    if (lang === "ta") return spot.activityTa;
    if (lang === "hi") return spot.activityHi;
    return spot.activity;
  };

  return (
    <>
      {visibleStops.map((item, idx) => {
        const isFirst = idx === 0;
        const isLast = idx === visibleStops.length - 1;
        const isSelected = activeStopNumber === item.spot.spotIndex;

        return (
          <AdvancedMarker
            key={`stop-marker-${item.spot.spotIndex}`}
            position={item.position}
            title={`#${item.spot.spotIndex} ${item.spot.spotName}`}
            onClick={() => onSelectStop(item.spot.spotIndex)}
          >
            <div
              className={`itinerary-map-pin ${
                isSelected
                  ? "pin-selected"
                  : isFirst
                  ? "pin-start"
                  : isLast
                  ? "pin-end"
                  : ""
              }`}
            >
              <span className="pin-num">{item.spot.spotIndex}</span>
              <span className="pin-day">D{item.spot.dayNumber}</span>
            </div>
          </AdvancedMarker>
        );
      })}

      {activeStopObj && (
        <InfoWindow
          position={activeStopObj.position}
          maxWidth={290}
          onCloseClick={() => onSelectStop(null)}
        >
          <div className="map-infowindow-card">
            <div className="map-infowindow-top">
              <span className="map-infowindow-badge">
                #{activeStopObj.spot.spotIndex} •{" "}
                {ui.dayBadge(activeStopObj.spot.dayNumber)}
              </span>
              <span className="map-infowindow-time">
                🕒 {activeStopObj.spot.timeSlot}
              </span>
            </div>
            <strong className="map-infowindow-title">
              {getLocalizedSpotName(activeStopObj.spot)}
            </strong>
            {lang !== "en" && (
              <span className="map-infowindow-sub">
                {activeStopObj.spot.spotName}
              </span>
            )}
            <p className="map-infowindow-activity">
              {getLocalizedActivity(activeStopObj.spot)}
            </p>
            <p className="map-infowindow-address">
              📍 {activeStopObj.formattedAddress}
            </p>
            <div className="map-infowindow-footer">
              <span className="map-infowindow-cost">
                {ui.perPersonLabel}: ₹{activeStopObj.spot.perPersonCost}
              </span>
              <a
                href={activeStopObj.googleMapsUri}
                target="_blank"
                rel="noopener noreferrer"
                className="map-infowindow-link"
              >
                {ui.openInGoogleMaps}
              </a>
            </div>
          </div>
        </InfoWindow>
      )}
    </>
  );
};

export const ItineraryRouteMap: React.FC<ItineraryRouteMapProps> = ({
  destinationName,
  destDisplayName,
  district,
  days,
  uniqueSpots,
  lang,
  primaryColor,
}) => {
  const apiKey = import.meta.env.VITE_GOOGLE_MAPS_API_KEY || "";
  const ui = MAP_UI_STRINGS[lang];

  const [selectedDay, setSelectedDay] = useState<"all" | number>("all");
  const [travelMode, setTravelMode] = useState<MapTravelMode>("DRIVING");
  const [activeStopNumber, setActiveStopNumber] = useState<number | null>(1);
  const [resolvedStops, setResolvedStops] = useState<ResolvedItineraryStop[]>(
    []
  );
  const [routeMetrics, setRouteMetrics] = useState<RouteMetrics | null>(null);
  const [status, setStatus] = useState<{
    resolving: boolean;
    routing: boolean;
  }>({
    resolving: false,
    routing: false,
  });

  const handleStatusChange = React.useCallback(
    (next: { resolving: boolean; routing: boolean }) => {
      setStatus((prev) => {
        if (prev.resolving === next.resolving && prev.routing === next.routing) {
          return prev;
        }
        return next;
      });
    },
    []
  );

  const handleRouteMetricsChange = React.useCallback(
    (next: RouteMetrics | null) => {
      setRouteMetrics((prev) => {
        if (prev === null && next === null) return prev;
        if (
          prev &&
          next &&
          prev.distanceMeters === next.distanceMeters &&
          prev.durationMillis === next.durationMillis
        ) {
          return prev;
        }
        return next;
      });
    },
    []
  );

  const handleResolvedStopsChange = React.useCallback(
    (next: ResolvedItineraryStop[]) => {
      setResolvedStops((prev) => {
        if (
          prev.length === next.length &&
          prev.every(
            (p, idx) =>
              p.spot.spotIndex === next[idx]?.spot.spotIndex &&
              p.position.lat === next[idx]?.position.lat &&
              p.position.lng === next[idx]?.position.lng
          )
        ) {
          return prev;
        }
        return next;
      });
    },
    []
  );

  // Reset day tab when destination or days change
  useEffect(() => {
    setSelectedDay("all");
    setActiveStopNumber(uniqueSpots[0]?.spotIndex ?? null);
  }, [destinationName, days]);

  const dayNumbers = Array.from({ length: days }, (_, i) => i + 1);

  const visibleStops = React.useMemo(() => {
    return selectedDay === "all"
      ? resolvedStops
      : resolvedStops.filter((s) => s.spot.dayNumber === selectedDay);
  }, [resolvedStops, selectedDay]);

  const getLocalizedSpotName = (spot: UniqueSpotSummary) => {
    if (lang === "ta") return spot.spotNameTa;
    if (lang === "hi") return spot.spotNameHi;
    return spot.spotName;
  };

  if (!apiKey) {
    return null;
  }

  return (
    <div
      className="itinerary-map-panel"
      role="region"
      aria-label={ui.title(destDisplayName, days)}
    >
      <div className="itinerary-map-header">
        <div>
          <span className="itinerary-map-kicker">{ui.kicker}</span>
          <h4>{ui.title(destDisplayName, days)}</h4>
          <p className="itinerary-map-subtitle">{ui.subtitle}</p>
        </div>

        {/* Travel Mode Switcher */}
        <div className="itinerary-mode-switcher" role="group">
          <button
            type="button"
            className={`map-mode-btn ${
              travelMode === "DRIVING" ? "active" : ""
            }`}
            onClick={() => setTravelMode("DRIVING")}
          >
            {ui.modeDriving}
          </button>
          <button
            type="button"
            className={`map-mode-btn ${
              travelMode === "TWO_WHEELER" ? "active" : ""
            }`}
            onClick={() => setTravelMode("TWO_WHEELER")}
          >
            {ui.modeTwoWheeler}
          </button>
          <button
            type="button"
            className={`map-mode-btn ${
              travelMode === "WALKING" ? "active" : ""
            }`}
            onClick={() => setTravelMode("WALKING")}
          >
            {ui.modeWalking}
          </button>
        </div>
      </div>

      {/* Day Filter Tabs + Route Summary Metrics */}
      <div className="itinerary-map-toolbar">
        <div className="itinerary-day-tabs" role="tablist">
          <button
            type="button"
            role="tab"
            aria-selected={selectedDay === "all"}
            className={`map-day-tab ${selectedDay === "all" ? "active" : ""}`}
            onClick={() => {
              setSelectedDay("all");
              setActiveStopNumber(uniqueSpots[0]?.spotIndex ?? null);
            }}
          >
            {ui.allDaysTab(uniqueSpots.length)}
          </button>
          {dayNumbers.map((d) => (
            <button
              key={d}
              type="button"
              role="tab"
              aria-selected={selectedDay === d}
              className={`map-day-tab ${selectedDay === d ? "active" : ""}`}
              onClick={() => {
                setSelectedDay(d);
                const firstOfDay = uniqueSpots.find((s) => s.dayNumber === d);
                setActiveStopNumber(firstOfDay?.spotIndex ?? null);
              }}
            >
              {ui.dayTab(d)}
            </button>
          ))}
        </div>

        <div className="itinerary-route-metrics">
          {(status.resolving || status.routing) && (
            <span className="map-loading-pill">
              {status.resolving ? ui.resolvingLocations : ui.computingRoute}
            </span>
          )}
          {routeMetrics && routeMetrics.distanceMeters > 0 && (
            <>
              <div className="route-metric-chip">
                <small>{ui.totalDistanceLabel}:</small>
                <strong>
                  {(routeMetrics.distanceMeters / 1000).toFixed(1)} km
                </strong>
              </div>
              <div className="route-metric-chip">
                <small>{ui.estDriveTimeLabel}:</small>
                <strong>{formatDuration(routeMetrics.durationMillis)}</strong>
              </div>
            </>
          )}
          <div className="route-metric-chip">
            <small>{ui.stopsCountLabel}:</small>
            <strong>{visibleStops.length || uniqueSpots.length}</strong>
          </div>
        </div>
      </div>

      {/* Google Map Canvas (Explicit height per CF2, mapId="DEMO_MAP_ID" per CF9, attribution ID per Section 4) */}
      <div className="itinerary-map-canvas-wrap">
        <APIProvider
          apiKey={apiKey}
          libraries={["places", "routes", "marker"]}
          language={lang}
          region="IN"
        >
          <Map
            mapId="DEMO_MAP_ID"
            defaultCenter={{ lat: 10.7905, lng: 78.7047 }}
            defaultZoom={11}
            gestureHandling="greedy"
            internalUsageAttributionIds={["gmp_mcp_codeassist_v1_aistudio"]}
          >
            <ItineraryMapInner
              destinationName={destinationName}
              district={district}
              uniqueSpots={uniqueSpots}
              resolvedStops={resolvedStops}
              selectedDay={selectedDay}
              travelMode={travelMode}
              lang={lang}
              primaryColor={primaryColor}
              activeStopNumber={activeStopNumber}
              onSelectStop={setActiveStopNumber}
              onResolvedStopsChange={handleResolvedStopsChange}
              onRouteMetricsChange={handleRouteMetricsChange}
              onStatusChange={handleStatusChange}
            />
          </Map>
        </APIProvider>
      </div>

      {/* Interactive Sequence Path Strip */}
      <div className="itinerary-sequence-strip">
        <p className="sequence-strip-title">{ui.pathSequenceTitle}</p>
        <div className="sequence-stops-flow">
          {(visibleStops.length > 0
            ? visibleStops.map((r) => r.spot)
            : selectedDay === "all"
            ? uniqueSpots
            : uniqueSpots.filter((s) => s.dayNumber === selectedDay)
          ).map((spot, idx, arr) => (
            <React.Fragment key={spot.spotIndex}>
              <button
                type="button"
                className={`sequence-stop-btn ${
                  activeStopNumber === spot.spotIndex ? "active" : ""
                }`}
                onClick={() => setActiveStopNumber(spot.spotIndex)}
              >
                <span className="seq-stop-num">#{spot.spotIndex}</span>
                <span className="seq-stop-text">
                  <strong>{getLocalizedSpotName(spot)}</strong>
                  <small>
                    {ui.dayBadge(spot.dayNumber)} • {spot.timeSlot}
                  </small>
                </span>
              </button>
              {idx < arr.length - 1 && (
                <span className="seq-arrow" aria-hidden="true">
                  ➔
                </span>
              )}
            </React.Fragment>
          ))}
        </div>
      </div>
    </div>
  );
};

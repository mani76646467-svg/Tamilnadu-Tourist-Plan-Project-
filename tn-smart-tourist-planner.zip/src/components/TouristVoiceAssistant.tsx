import React, { useState, useEffect, useRef, useCallback } from "react";
import { AppLanguage } from "../data/i18n";

interface ChatTurn {
  id: string;
  role: "user" | "model";
  text: string;
  source: "voice" | "text";
  timestamp: string;
}

interface TouristVoiceAssistantProps {
  lang: AppLanguage;
}

function buildWavDataUrl(pcmOrWavBase64: string, sampleRate = 24000): string {
  if (pcmOrWavBase64.startsWith("data:audio")) {
    return pcmOrWavBase64;
  }
  const binaryStr = window.atob(pcmOrWavBase64);
  // If the payload is already a complete RIFF WAV container, return directly
  if (binaryStr.slice(0, 4) === "RIFF") {
    return `data:audio/wav;base64,${pcmOrWavBase64}`;
  }

  const pcmLength = binaryStr.length;
  const wavHeader = new ArrayBuffer(44);
  const view = new DataView(wavHeader);

  const writeStr = (offset: number, str: string) => {
    for (let i = 0; i < str.length; i++) {
      view.setUint8(offset + i, str.charCodeAt(i));
    }
  };

  writeStr(0, "RIFF");
  view.setUint32(4, 36 + pcmLength, true);
  writeStr(8, "WAVE");
  writeStr(12, "fmt ");
  view.setUint32(16, 16, true);
  view.setUint16(20, 1, true); // PCM
  view.setUint16(22, 1, true); // Mono
  view.setUint32(24, sampleRate, true);
  view.setUint32(28, sampleRate * 2, true);
  view.setUint16(32, 2, true);
  view.setUint16(34, 16, true);
  writeStr(36, "data");
  view.setUint32(40, pcmLength, true);

  const wavBytes = new Uint8Array(44 + pcmLength);
  wavBytes.set(new Uint8Array(wavHeader), 0);
  for (let i = 0; i < pcmLength; i++) {
    wavBytes[44 + i] = binaryStr.charCodeAt(i);
  }

  let binary = "";
  const chunkSize = 8192;
  for (let i = 0; i < wavBytes.length; i += chunkSize) {
    const sub = wavBytes.subarray(i, i + chunkSize);
    binary += String.fromCharCode(...sub);
  }
  return `data:audio/wav;base64,${window.btoa(binary)}`;
}

function arrayBufferToBase64(buffer: ArrayBuffer): string {
  const bytes = new Uint8Array(buffer);
  let binary = "";
  const chunkSize = 4096;
  for (let i = 0; i < bytes.byteLength; i += chunkSize) {
    const sub = bytes.subarray(i, i + chunkSize);
    binary += String.fromCharCode(...sub);
  }
  return window.btoa(binary);
}

const ASSISTANT_STRINGS: Record<
  AppLanguage,
  {
    kicker: string;
    title: string;
    subtitle: string;
    liveCardTitle: string;
    liveCardDesc: string;
    startVoiceBtn: string;
    connectingBtn: string;
    endVoiceBtn: string;
    muteMicBtn: string;
    unmuteMicBtn: string;
    statusIdle: string;
    statusConnecting: string;
    statusListening: string;
    statusSpeaking: string;
    statusMuted: string;
    askBoxTitle: string;
    inputPlaceholder: string;
    askBtn: string;
    askingBtn: string;
    dictateBtnTitle: string;
    listenBtn: string;
    stopAudioBtn: string;
    autoSpeakLabel: string;
    clearChatBtn: string;
    quickQuestionsLabel: string;
    quickQuestions: string[];
    welcomeMessage: string;
    liveTranscriptYou: string;
    liveTranscriptGuide: string;
  }
> = {
  ta: {
    kicker: "🎙️ நேரடி குரல் உரையாடல் & சுற்றுலா AI வழிகாட்டி (LIVE VOICE & TOURIST Q&A)",
    title: "சுற்றுலா மற்றும் சுற்றுலாத் தலங்கள் பற்றி எதைக் கேட்டாலும் உடனடி பதில்!",
    subtitle:
      "நேரடியாகக் குரலில் பேசலாம் (Live Voice Conversation) அல்லது டைப் செய்து கேட்கலாம் — தமிழ்நாடு, இந்தியா மற்றும் உலகின் எந்தச் சுற்றுலாத் தலம், கோவில் நேரம், கட்டணம், வழித்தடம், உணவு மற்றும் பட்ஜெட் பற்றியும் கேளுங்கள்.",
    liveCardTitle: "நேரடி குரல் உரையாடல் (Real-Time Voice Call)",
    liveCardDesc:
      "மைக் பட்டனை அழுத்தி தமிழ், ஆங்கிலம் அல்லது இந்தியில் நேரடியாகப் பேசுங்கள். சுற்றுலா வழிகாட்டி உடனுக்குடன் குரலில் பதிலளிக்கும்!",
    startVoiceBtn: "🎙️ குரல் உரையாடலைத் தொடங்கு (Start Live Voice)",
    connectingBtn: "⏳ இணைக்கப்படுகிறது (Connecting Live Voice)...",
    endVoiceBtn: "⏹️ உரையாடலை நிறுத்து (End Voice Call)",
    muteMicBtn: "🔇 மைக் மியூட் (Mute Mic)",
    unmuteMicBtn: "🎙️ மைக் ஆன் (Unmute Mic)",
    statusIdle: "குரல் உரையாடல் தயார் நிலையில் உள்ளது (Ready for Voice Call)",
    statusConnecting: "Gemini Live குரல் சேவையுடன் இணைக்கிறது...",
    statusListening: "🟢 கேட்டுக்கொண்டிருக்கிறது... இப்போது பேசுங்கள்!",
    statusSpeaking: "🔊 சுற்றுலா வழிகாட்டி குரலில் பதிலளிக்கிறது...",
    statusMuted: "🔇 மைக் மியூட் செய்யப்பட்டுள்ளது",
    askBoxTitle: "💬 சுற்றுலாத் தலங்கள் பற்றி எதை வேண்டுமானாலும் கேளுங்கள்",
    inputPlaceholder:
      "உதா: மதுரை மீனாட்சி அம்மன் கோவில் நேரம், ஊட்டி 3 நாள் செலவு, ராமேஸ்வரம் சுற்றுலா இடங்கள்...",
    askBtn: "பதில் கேள் (Ask Guide)",
    askingBtn: "பதில் தயாராகிறது...",
    dictateBtnTitle: "குரலில் டைப் செய்க (Voice Input)",
    listenBtn: "🔊 குரலில் கேள்",
    stopAudioBtn: "⏹️ நிறுத்து",
    autoSpeakLabel: "பதிலைத் தானாகக் குரலில் வாசிக்க",
    clearChatBtn: "உரையாடலை அழி",
    quickQuestionsLabel: "⚡ உடனடியாகக் கேட்க சில மாதிரி கேள்விகள்:",
    quickQuestions: [
      "மதுரை மீனாட்சி அம்மன் கோவில் தரிசன நேரம் & அருகில் பார்க்க வேண்டிய இடங்கள் என்ன?",
      "ஊட்டி மற்றும் கொடைக்கானல் - குடும்பத்துடன் 3 நாள் சுற்றுலா செல்ல எவ்வளவு செலவாகும்?",
      "ராமேஸ்வரம் மற்றும் தனுஷ்கோடி சுற்றுலா வழிகாட்டி & சிறந்த தங்கும் இடங்கள்",
      "குற்றாலம் அருவிகளுக்குச் செல்ல சிறந்த மாதம் மற்றும் பார்க்க வேண்டிய அருவிகள் எவை?",
      "கன்னியாகுமரி விவேகானந்தர் பாறை படகு நேரம் மற்றும் டிக்கெட் கட்டணம் எவ்வளவு?",
      "தமிழ்நாட்டில் ₹3000 பட்ஜெட்டில் 2 நாட்கள் செல்ல சிறந்த சுற்றுலாத் தலங்கள் எவை?",
    ],
    welcomeMessage:
      "வணக்கம்! 🙏 நான் உங்கள் தமிழ்நாடு ஸ்மார்ட் சுற்றுலா வழிகாட்டி (AI Tourist & Voice Guide). எந்தவொரு சுற்றுலாத் தலம், கோவில் தரிசன நேரம், நுழைவுக் கட்டணம், பேருந்து/ரயில் வழித்தடம், தங்கும் விடுதி செலவு அல்லது சுற்றுலா திட்டம் குறித்தும் என்னிடம் கேட்கலாம். மேலே உள்ள 'குரல் உரையாடலைத் தொடங்கு' பட்டனை அழுத்தி நேரடியாக என்னுடன் பேசலாம்!",
    liveTranscriptYou: "நீங்கள் பேசுவது",
    liveTranscriptGuide: "வழிகாட்டி பதில்",
  },
  en: {
    kicker: "🎙️ LIVE VOICE CONVERSATION & SMART TOURIST AI GUIDE",
    title: "Ask Anything About Tourists & Tourist Places — Voice & Chat!",
    subtitle:
      "Start a real-time 2-way voice conversation or type any question about tourist places, temple timings, entry fees, travel routes, weather seasons, local food, and accurate per-person budgets.",
    liveCardTitle: "Real-Time 2-Way Voice Conversation (Gemini Live)",
    liveCardDesc:
      "Click below to talk naturally in Tamil, English, or Hindi. Our AI Tourist Guide listens and speaks back in real time!",
    startVoiceBtn: "🎙️ Start Live Voice Conversation",
    connectingBtn: "⏳ Connecting Live Voice...",
    endVoiceBtn: "⏹️ End Voice Conversation",
    muteMicBtn: "🔇 Mute Microphone",
    unmuteMicBtn: "🎙️ Unmute Microphone",
    statusIdle: "Ready for real-time voice conversation",
    statusConnecting: "Connecting to Gemini Live Voice API...",
    statusListening: "🟢 Listening... Speak now in Tamil, English, or Hindi!",
    statusSpeaking: "🔊 AI Tourist Guide is speaking...",
    statusMuted: "🔇 Microphone is muted",
    askBoxTitle: "💬 Ask Anything About Any Tourist Place",
    inputPlaceholder:
      "Ask about any tourist spot, timings, routes, best season, hidden gems, or budget...",
    askBtn: "Ask Tourist Guide",
    askingBtn: "Thinking...",
    dictateBtnTitle: "Speak to type question",
    listenBtn: "🔊 Listen",
    stopAudioBtn: "⏹️ Stop Audio",
    autoSpeakLabel: "Auto-speak text replies",
    clearChatBtn: "Clear Chat",
    quickQuestionsLabel: "⚡ Popular Tourist Questions (Click to Ask):",
    quickQuestions: [
      "What are the darshan timings and top tourist spots to visit in Madurai?",
      "Ooty vs Kodaikanal: Which is better for a 3-day family trip and what is the per-person cost?",
      "Complete guide to Rameswaram temple corridor and Dhanushkodi beach timings",
      "Best season to visit Courtallam waterfalls and which falls are best for families?",
      "Kanyakumari sunrise time, Vivekananda Rock ferry ticket price, and nearby spots",
      "Suggest the best 2-day budget trip in Tamil Nadu under ₹3,000 per person",
    ],
    welcomeMessage:
      "Vanakkam & Welcome! 🙏 I am your AI Tourist Guide. Ask me anything about any tourist place in Tamil Nadu, India, or worldwide — including sightseeing spots, timings, ticket prices, how to reach, food specialties, and accurate budgets. Click 'Start Live Voice Conversation' to talk with me in real time!",
    liveTranscriptYou: "You (Live Voice)",
    liveTranscriptGuide: "Tourist Guide (Live Voice)",
  },
  hi: {
    kicker: "🎙️ लाइव वॉइस बातचीत और स्मार्ट पर्यटन AI गाइड",
    title: "पर्यटन और किसी भी पर्यटन स्थल के बारे में कुछ भी पूछें — आवाज़ या चैट से!",
    subtitle:
      "तमिलनाडु, भारत या दुनिया के किसी भी पर्यटन स्थल, मंदिर दर्शन समय, टिकट शुल्क, यात्रा मार्ग, मौसम और प्रति व्यक्ति बजट के बारे में रियल-टाइम वॉइस में बात करें या टाइप करके पूछें।",
    liveCardTitle: "रियल-टाइम वॉइस बातचीत (Live Voice Conversation)",
    liveCardDesc:
      "नीचे दिए गए बटन को दबाएं और हिंदी, तमिल या अंग्रेजी में सीधे बात करें। हमारा पर्यटन गाइड तुरंत आवाज़ में जवाब देगा!",
    startVoiceBtn: "🎙️ लाइव वॉइस बातचीत शुरू करें",
    connectingBtn: "⏳ लाइव वॉइस कनेक्ट हो रहा है...",
    endVoiceBtn: "⏹️ वॉइस बातचीत समाप्त करें",
    muteMicBtn: "🔇 माइक म्यूट करें",
    unmuteMicBtn: "🎙️ माइक अनम्यूट करें",
    statusIdle: "वॉइस बातचीत के लिए तैयार",
    statusConnecting: "Gemini Live वॉइस सेवा से जुड़ रहा है...",
    statusListening: "🟢 सुन रहा है... अब हिंदी, तमिल या अंग्रेजी में बोलें!",
    statusSpeaking: "🔊 पर्यटन गाइड बोल रहा है...",
    statusMuted: "🔇 माइक म्यूट है",
    askBoxTitle: "💬 किसी भी पर्यटन स्थल के बारे में कुछ भी पूछें",
    inputPlaceholder:
      "उदा: मदुरै मीनाक्षी मंदिर का समय, ऊटी 3 दिन का खर्च, रामेश्वरम दर्शनीय स्थल...",
    askBtn: "उत्तर पूछें",
    askingBtn: "उत्तर तैयार हो रहा है...",
    dictateBtnTitle: "बोलकर टाइप करें",
    listenBtn: "🔊 सुनें",
    stopAudioBtn: "⏹️ रोकें",
    autoSpeakLabel: "उत्तर अपने आप आवाज़ में सुनें",
    clearChatBtn: "चैट साफ़ करें",
    quickQuestionsLabel: "⚡ त्वरित पर्यटन प्रश्न (पूछने के लिए क्लिक करें):",
    quickQuestions: [
      "मदुरै मीनाक्षी अम्मन मंदिर दर्शन का समय और आसपास के प्रमुख पर्यटन स्थल कौन से हैं?",
      "ऊटी और कोडाइकनाल: 3 दिन की पारिवारिक यात्रा के लिए कौन सा बेहतर है और प्रति व्यक्ति खर्च कितना है?",
      "रामेश्वरम मंदिर और धनुषकोडी यात्रा की पूरी जानकारी और समय",
      "कन्याकुमारी सूर्योदय समय और विवेकानंद रॉक मेमोरियल फेरी टिकट की कीमत क्या है?",
      "महाबलीपुरम और कांचीपुरम के प्रमुख ऐतिहासिक स्थल और प्रवेश शुल्क",
      "₹3000 प्रति व्यक्ति बजट में तमिलनाडु की सबसे अच्छी 2-दिवसीय यात्रा कौन सी है?",
    ],
    welcomeMessage:
      "वणक्कम और नमस्ते! 🙏 मैं आपका स्मार्ट पर्यटन और वॉइस गाइड हूँ। आप मुझसे किसी भी पर्यटन स्थल, मंदिर के समय, यात्रा मार्ग, होटल खर्च या बजट के बारे में पूछ सकते हैं। मुझसे सीधे बात करने के लिए 'लाइव वॉइस बातचीत शुरू करें' पर क्लिक करें!",
    liveTranscriptYou: "आप (लाइव वॉइस)",
    liveTranscriptGuide: "पर्यटन गाइड (लाइव वॉइस)",
  },
};

export const TouristVoiceAssistant: React.FC<TouristVoiceAssistantProps> = ({
  lang,
}) => {
  const ui = ASSISTANT_STRINGS[lang];

  // Selected spoken language for voice (can be freely toggled between Tamil, English, and Hindi)
  const [spokenVoiceLang, setSpokenVoiceLang] = useState<AppLanguage>(lang);
  const [micHelpTab, setMicHelpTab] = useState<
    "chrome" | "edge" | "safari" | "mobile"
  >("chrome");

  // Keep spokenVoiceLang synced when main app lang changes, but user can override
  useEffect(() => {
    setSpokenVoiceLang(lang);
  }, [lang]);

  // Conversation history
  const [messages, setMessages] = useState<ChatTurn[]>([
    {
      id: "welcome-0",
      role: "model",
      text: ASSISTANT_STRINGS[lang].welcomeMessage,
      source: "text",
      timestamp: new Date().toLocaleTimeString([], {
        hour: "2-digit",
        minute: "2-digit",
      }),
    },
  ]);

  // Update welcome message language when user toggles language if it's the only message
  useEffect(() => {
    setMessages((prev) => {
      if (prev.length === 1 && prev[0].id === "welcome-0") {
        return [
          {
            ...prev[0],
            text: ASSISTANT_STRINGS[lang].welcomeMessage,
          },
        ];
      }
      return prev;
    });
  }, [lang]);

  // Text input & Q&A state
  const [inputText, setInputText] = useState("");
  const [isAskingText, setIsAskingText] = useState(false);
  const [autoSpeakReplies, setAutoSpeakReplies] = useState(true);
  const [playingMessageId, setPlayingMessageId] = useState<string | null>(null);
  const [isDictating, setIsDictating] = useState(false);
  const [dictationTranscript, setDictationTranscript] = useState("");

  // Live API (gemini-3.8-live) real-time voice state
  const [liveStatus, setLiveStatus] = useState<
    "idle" | "connecting" | "connected"
  >("idle");
  const [isMicMuted, setIsMicMuted] = useState(false);
  const [isModelSpeaking, setIsModelSpeaking] = useState(false);
  const [liveInputTranscript, setLiveInputTranscript] = useState("");
  const [liveOutputTranscript, setLiveOutputTranscript] = useState("");
  const [voiceError, setVoiceError] = useState<string | null>(null);
  const [micPermissionDenied, setMicPermissionDenied] = useState(false);

  // Refs for WebSocket & Web Audio API & SpeechRecognition
  const wsRef = useRef<WebSocket | null>(null);
  const micStreamRef = useRef<MediaStream | null>(null);
  const inputAudioCtxRef = useRef<AudioContext | null>(null);
  const processorRef = useRef<ScriptProcessorNode | null>(null);
  const playbackAudioCtxRef = useRef<AudioContext | null>(null);
  const nextPlayTimeRef = useRef<number>(0);
  const activeSourcesRef = useRef<AudioBufferSourceNode[]>([]);
  const isMicMutedRef = useRef<boolean>(false);
  const currentInputAccRef = useRef<string>("");
  const currentOutputAccRef = useRef<string>("");
  const ttsAudioRef = useRef<HTMLAudioElement | null>(null);
  const chatScrollRef = useRef<HTMLDivElement | null>(null);
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  const recognitionRef = useRef<any>(null);

  useEffect(() => {
    isMicMutedRef.current = isMicMuted;
  }, [isMicMuted]);

  // Scroll chat feed smoothly on new messages or live transcription
  useEffect(() => {
    if (chatScrollRef.current) {
      chatScrollRef.current.scrollTop = chatScrollRef.current.scrollHeight;
    }
  }, [messages, liveInputTranscript, liveOutputTranscript, isAskingText]);

  const stopQueuedPlayback = useCallback(() => {
    for (const src of activeSourcesRef.current) {
      try {
        src.stop();
        src.disconnect();
      } catch {
        // ignore already stopped source
      }
    }
    activeSourcesRef.current = [];
    if (playbackAudioCtxRef.current) {
      nextPlayTimeRef.current = playbackAudioCtxRef.current.currentTime;
    }
    setIsModelSpeaking(false);
  }, []);

  const playPcm24kChunk = useCallback((base64Pcm: string) => {
    try {
      if (!playbackAudioCtxRef.current) {
        const AudioCtx =
          window.AudioContext ||
          (window as unknown as { webkitAudioContext: typeof AudioContext })
            .webkitAudioContext;
        playbackAudioCtxRef.current = new AudioCtx({ sampleRate: 24000 });
      }
      const ctx = playbackAudioCtxRef.current;
      if (ctx.state === "suspended") {
        ctx.resume();
      }

      const binaryStr = window.atob(base64Pcm);
      const byteLength = binaryStr.length;
      const bytes = new Uint8Array(byteLength);
      for (let i = 0; i < byteLength; i++) {
        bytes[i] = binaryStr.charCodeAt(i);
      }

      const sampleCount = Math.floor(byteLength / 2);
      if (sampleCount === 0) return;

      const int16 = new Int16Array(bytes.buffer, 0, sampleCount);
      const float32 = new Float32Array(sampleCount);
      for (let i = 0; i < sampleCount; i++) {
        float32[i] = int16[i] / 32768.0;
      }

      const audioBuffer = ctx.createBuffer(1, sampleCount, 24000);
      audioBuffer.getChannelData(0).set(float32);

      const source = ctx.createBufferSource();
      source.buffer = audioBuffer;
      source.connect(ctx.destination);

      const now = ctx.currentTime;
      const startAt = Math.max(now + 0.02, nextPlayTimeRef.current);
      source.start(startAt);
      nextPlayTimeRef.current = startAt + audioBuffer.duration;

      activeSourcesRef.current.push(source);
      setIsModelSpeaking(true);

      source.onended = () => {
        activeSourcesRef.current = activeSourcesRef.current.filter(
          (s) => s !== source
        );
        if (activeSourcesRef.current.length === 0) {
          setIsModelSpeaking(false);
        }
      };
    } catch (err) {
      console.error("Failed to play PCM chunk:", err);
    }
  }, []);

  const stopLiveVoiceSession = useCallback(() => {
    stopQueuedPlayback();

    if (processorRef.current) {
      try {
        processorRef.current.disconnect();
      } catch {
        // ignore
      }
      processorRef.current = null;
    }

    if (inputAudioCtxRef.current) {
      try {
        inputAudioCtxRef.current.close();
      } catch {
        // ignore
      }
      inputAudioCtxRef.current = null;
    }

    if (micStreamRef.current) {
      micStreamRef.current.getTracks().forEach((track) => track.stop());
      micStreamRef.current = null;
    }

    if (wsRef.current) {
      try {
        wsRef.current.close();
      } catch {
        // ignore
      }
      wsRef.current = null;
    }

    setLiveStatus("idle");
    setIsMicMuted(false);
    setIsModelSpeaking(false);
    setLiveInputTranscript("");
    setLiveOutputTranscript("");
    currentInputAccRef.current = "";
    currentOutputAccRef.current = "";
  }, [stopQueuedPlayback]);

  // Clean up on unmount
  useEffect(() => {
    return () => {
      stopLiveVoiceSession();
      if (ttsAudioRef.current) {
        ttsAudioRef.current.pause();
      }
    };
  }, [stopLiveVoiceSession]);

  const startLiveVoiceSession = async () => {
    if (liveStatus !== "idle") {
      stopLiveVoiceSession();
      return;
    }

    setVoiceError(null);
    setLiveStatus("connecting");

    try {
      // Request microphone access first so browser permissions are granted
      const stream = await navigator.mediaDevices.getUserMedia({
        audio: {
          sampleRate: 16000,
          channelCount: 1,
          echoCancellation: true,
          noiseSuppression: true,
          autoGainControl: true,
        },
      });
      micStreamRef.current = stream;

      // Initialize playback AudioContext on user gesture
      if (!playbackAudioCtxRef.current) {
        const AudioCtx =
          window.AudioContext ||
          (window as unknown as { webkitAudioContext: typeof AudioContext })
            .webkitAudioContext;
        playbackAudioCtxRef.current = new AudioCtx({ sampleRate: 24000 });
      } else if (playbackAudioCtxRef.current.state === "suspended") {
        await playbackAudioCtxRef.current.resume();
      }
      nextPlayTimeRef.current = playbackAudioCtxRef.current.currentTime;

      const protocol = window.location.protocol === "https:" ? "wss:" : "ws:";
      const wsUrl = `${protocol}//${window.location.host}/live?lang=${encodeURIComponent(
        spokenVoiceLang
      )}`;
      const ws = new WebSocket(wsUrl);
      wsRef.current = ws;

      ws.onmessage = (event) => {
        try {
          const data = JSON.parse(event.data);

          if (data.type === "connected") {
            setLiveStatus("connected");

            // Start streaming 16kHz PCM audio from microphone
            const AudioCtx =
              window.AudioContext ||
              (window as unknown as { webkitAudioContext: typeof AudioContext })
                .webkitAudioContext;
            const inputCtx = new AudioCtx({ sampleRate: 16000 });
            inputAudioCtxRef.current = inputCtx;

            const micSource = inputCtx.createMediaStreamSource(stream);
            const processor = inputCtx.createScriptProcessor(4096, 1, 1);
            processorRef.current = processor;

            processor.onaudioprocess = (e) => {
              if (
                isMicMutedRef.current ||
                !wsRef.current ||
                wsRef.current.readyState !== WebSocket.OPEN
              ) {
                return;
              }

              const inputChannel = e.inputBuffer.getChannelData(0);
              const pcm16 = new Int16Array(inputChannel.length);
              for (let i = 0; i < inputChannel.length; i++) {
                const s = Math.max(-1, Math.min(1, inputChannel[i]));
                pcm16[i] = s < 0 ? s * 0x8000 : s * 0x7fff;
              }

              const base64Audio = arrayBufferToBase64(pcm16.buffer);
              wsRef.current.send(JSON.stringify({ audio: base64Audio }));
            };

            micSource.connect(processor);
            processor.connect(inputCtx.destination);
          } else if (data.type === "audio" && data.audio) {
            playPcm24kChunk(data.audio);
          } else if (data.type === "inputTranscript" && data.text) {
            currentInputAccRef.current += data.text;
            setLiveInputTranscript(currentInputAccRef.current.trim());
          } else if (data.type === "outputTranscript" && data.text) {
            currentOutputAccRef.current += data.text;
            setLiveOutputTranscript(currentOutputAccRef.current.trim());
          } else if (data.type === "modelText" && data.text) {
            // If outputTranscript is not emitted, capture modelText
            if (!currentOutputAccRef.current) {
              currentOutputAccRef.current += data.text;
              setLiveOutputTranscript(currentOutputAccRef.current.trim());
            }
          } else if (data.type === "interrupted") {
            stopQueuedPlayback();
          } else if (data.type === "turnComplete") {
            const userSpoken = currentInputAccRef.current.trim();
            const modelSpoken = currentOutputAccRef.current.trim();
            const timeLabel = new Date().toLocaleTimeString([], {
              hour: "2-digit",
              minute: "2-digit",
            });

            if (userSpoken || modelSpoken) {
              setMessages((prev) => {
                const next = [...prev];
                if (userSpoken) {
                  next.push({
                    id: `voice-user-${Date.now()}-${Math.random()}`,
                    role: "user",
                    text: userSpoken,
                    source: "voice",
                    timestamp: timeLabel,
                  });
                }
                if (modelSpoken) {
                  next.push({
                    id: `voice-model-${Date.now()}-${Math.random()}`,
                    role: "model",
                    text: modelSpoken,
                    source: "voice",
                    timestamp: timeLabel,
                  });
                }
                return next;
              });
            }

            currentInputAccRef.current = "";
            currentOutputAccRef.current = "";
            setLiveInputTranscript("");
            setLiveOutputTranscript("");
          } else if (data.type === "error") {
            setVoiceError(data.error || "Live voice error occurred.");
            stopLiveVoiceSession();
          } else if (data.type === "closed") {
            stopLiveVoiceSession();
          }
        } catch (err) {
          console.error("Error parsing Live WS message:", err);
        }
      };

      ws.onerror = () => {
        setVoiceError(
          lang === "ta"
            ? "குரல் இணைப்பில் சிக்கல் ஏற்பட்டது. மீண்டும் முயற்சிக்கவும்."
            : "Voice connection encountered an error. Please try again."
        );
        stopLiveVoiceSession();
      };

      ws.onclose = () => {
        stopLiveVoiceSession();
      };
    } catch (err: unknown) {
      const msg =
        err instanceof Error
          ? err.message
          : "Microphone access is required for Live Voice Conversation.";
      const isDenied =
        (err instanceof Error &&
          (err.name === "NotAllowedError" ||
            err.name === "PermissionDeniedError" ||
            err.message.toLowerCase().includes("permission") ||
            err.message.toLowerCase().includes("denied"))) ||
        String(err).toLowerCase().includes("permission") ||
        String(err).toLowerCase().includes("denied");

      if (isDenied) {
        setMicPermissionDenied(true);
      }
      setVoiceError(
        lang === "ta"
          ? isDenied
            ? "மைக்ரோஃபோன் அனுமதி தடுக்கப்பட்டுள்ளது. பிரவுசரில் அனுமதி வழங்கி மீண்டும் முயற்சிக்கவும்."
            : `மைக்ரோஃபோன் பிழை: ${msg}`
          : isDenied
          ? "Microphone access was denied. Please allow microphone in browser settings and click Try Again."
          : `Microphone error: ${msg}`
      );
      stopLiveVoiceSession();
    }
  };

  // Speak any chat message out loud using /api/tourist-tts (gemini-3.8-flash-lite-tts) with browser fallback
  const handleSpeakMessage = useCallback(
    async (msgId: string, textToSpeak: string) => {
      if (playingMessageId === msgId) {
        if (ttsAudioRef.current) {
          ttsAudioRef.current.pause();
          ttsAudioRef.current = null;
        }
        if ("speechSynthesis" in window) {
          window.speechSynthesis.cancel();
        }
        setPlayingMessageId(null);
        return;
      }

      if (ttsAudioRef.current) {
        ttsAudioRef.current.pause();
        ttsAudioRef.current = null;
      }
      if ("speechSynthesis" in window) {
        window.speechSynthesis.cancel();
      }

      setPlayingMessageId(msgId);

      // Detect language from text characters for accurate voice synthesis
      const isTamil = /[\u0B80-\u0BFF]/.test(textToSpeak);
      const isHindi = /[\u0900-\u097F]/.test(textToSpeak);
      const speechLang = isTamil ? "ta-IN" : isHindi ? "hi-IN" : "en-IN";

      try {
        const res = await fetch("/api/tourist-tts", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ text: textToSpeak }),
        });

        if (!res.ok) throw new Error("TTS API error");
        const data = await res.json();
        if (!data.audioWavBase64) throw new Error("No audio data");

        // The Gemini TTS model returns a complete WAV file (starts with 'UklGR')
        const isAlreadyWav = data.audioWavBase64.startsWith("UklGR");
        const wavUrl = isAlreadyWav
          ? `data:audio/wav;base64,${data.audioWavBase64}`
          : buildWavDataUrl(data.audioWavBase64, 24000);
        const audio = new Audio(wavUrl);
        ttsAudioRef.current = audio;

        audio.onended = () => {
          setPlayingMessageId(null);
          ttsAudioRef.current = null;
        };
        audio.onerror = () => {
          setPlayingMessageId(null);
          ttsAudioRef.current = null;
        };

        await audio.play();
      } catch {
        // Fallback to browser SpeechSynthesis in Tamil, English, or Hindi
        if ("speechSynthesis" in window) {
          const cleanText = textToSpeak
            .replace(/[*#_`~]/g, "")
            .replace(/[\uD800-\uDBFF][\uDC00-\uDFFF]/g, "");
          const utterance = new SpeechSynthesisUtterance(cleanText);
          utterance.lang = speechLang;

          const speakWithBestVoice = () => {
            const voices = window.speechSynthesis.getVoices();
            const matchedVoice = voices.find(
              (v) =>
                v.lang === speechLang ||
                v.lang.toLowerCase().replace(/_/g, "-").startsWith(speechLang.split("-")[0])
            );
            if (matchedVoice) {
              utterance.voice = matchedVoice;
            }
            utterance.onend = () => setPlayingMessageId(null);
            utterance.onerror = () => setPlayingMessageId(null);
            window.speechSynthesis.speak(utterance);
          };

          const curVoices = window.speechSynthesis.getVoices();
          if (curVoices && curVoices.length > 0) {
            speakWithBestVoice();
          } else {
            window.speechSynthesis.onvoiceschanged = () => {
              speakWithBestVoice();
            };
            setTimeout(speakWithBestVoice, 50);
          }
        } else {
          setPlayingMessageId(null);
        }
      }
    },
    [playingMessageId]
  );

  // Re-request microphone permissions with direct user action
  const handleRetryMic = async () => {
    setVoiceError(null);
    try {
      if (navigator.mediaDevices && navigator.mediaDevices.getUserMedia) {
        const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
        stream.getTracks().forEach((track) => track.stop());
        setMicPermissionDenied(false);
        setVoiceError(null);
        startLiveVoiceSession();
      }
    } catch (err: unknown) {
      setMicPermissionDenied(true);
      setVoiceError(
        lang === "ta"
          ? "பிரவுசரில் மைக் அனுமதி இன்னும் வழங்கப்படவில்லை. முகவரிப் பட்டியில் உள்ள 🔒 ஐகானை அழுத்தி 'Allow' செய்துவிட்டு மீண்டும் முயற்சிக்கவும்."
          : lang === "hi"
          ? "माइक अनुमति अभी भी ब्लॉक है। कृपया ब्राउज़र एड्रेस बार में 🔒 आइकन से 'Allow' करें।"
          : "Microphone permission is still blocked. Please allow microphone in browser address bar (🔒 icon) and click Try Again."
      );
    }
  };

  // Immediate voice output speaker test in chosen language
  const handleTestAudioGreeting = () => {
    const greetingText =
      spokenVoiceLang === "ta"
        ? "வணக்கம்! நான் உங்கள் தமிழ்நாடு ஸ்மார்ட் சுற்றுலா வழிகாட்டி. நீங்கள் எந்த சுற்றுலாத் தலம், கோவில் நேரம், செலவு குறித்தும் என்னிடம் கேட்கலாம்!"
        : spokenVoiceLang === "hi"
        ? "नमस्ते! मैं आपका पर्यटन गाइड हूँ। मुझसे किसी भी पर्यटन स्थल, मंदिर के समय या बजट के बारे में पूछिए!"
        : "Hello! I am your AI Tourist Guide. Ask me anything about any tourist destination, timings, routes, or budgets!";
    handleSpeakMessage(`test-${Date.now()}`, greetingText);
  };

  // Ask any question about tourists / tourist places
  const handleAskQuestion = async (
    questionText: string,
    isFromVoice = false
  ) => {
    const trimmed = questionText.trim();
    if (!trimmed || isAskingText) return;

    const timeLabel = new Date().toLocaleTimeString([], {
      hour: "2-digit",
      minute: "2-digit",
    });

    // If Live Voice session is active, send directly into the Live session so it answers with live voice!
    if (
      liveStatus === "connected" &&
      wsRef.current &&
      wsRef.current.readyState === WebSocket.OPEN
    ) {
      setMessages((prev) => [
        ...prev,
        {
          id: `user-live-prompt-${Date.now()}`,
          role: "user",
          text: trimmed,
          source: "voice",
          timestamp: timeLabel,
        },
      ]);
      wsRef.current.send(JSON.stringify({ text: trimmed }));
      setInputText("");
      return;
    }

    const userMsg: ChatTurn = {
      id: `user-${Date.now()}`,
      role: "user",
      text: trimmed,
      source: isFromVoice ? "voice" : "text",
      timestamp: timeLabel,
    };

    const historyPayload = messages.slice(-8).map((m) => ({
      role: m.role,
      text: m.text,
    }));

    setMessages((prev) => [...prev, userMsg]);
    setInputText("");
    setIsAskingText(true);

    try {
      const response = await fetch("/api/tourist-chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          message: trimmed,
          history: historyPayload,
          lang,
        }),
      });

      const data = await response.json();
      const replyText =
        data.reply ||
        (lang === "ta"
          ? "மன்னிக்கவும், தற்போது பதில் பெற முடியவில்லை."
          : "Sorry, could not fetch a response right now.");

      const modelMsgId = `model-${Date.now()}`;
      const modelMsg: ChatTurn = {
        id: modelMsgId,
        role: "model",
        text: replyText,
        source: isFromVoice ? "voice" : "text",
        timestamp: new Date().toLocaleTimeString([], {
          hour: "2-digit",
          minute: "2-digit",
        }),
      };

      setMessages((prev) => [...prev, modelMsg]);

      // If user asked with voice or auto-speak is enabled, speak out loud!
      if (isFromVoice || autoSpeakReplies) {
        handleSpeakMessage(modelMsgId, replyText);
      }
    } catch {
      setMessages((prev) => [
        ...prev,
        {
          id: `err-${Date.now()}`,
          role: "model",
          text:
            lang === "ta"
              ? "இணைய இணைப்பில் சிறு சிக்கல் உள்ளது. தயவுசெய்து மீண்டும் முயற்சிக்கவும்."
              : "Network error while contacting Tourist AI Guide. Please try again.",
          source: "text",
          timestamp: timeLabel,
        },
      ]);
    } finally {
      setIsAskingText(false);
    }
  };

  // Voice-to-text dictation button for quick input
  const handleDictateInput = () => {
    const SpeechRec =
      (window as unknown as { SpeechRecognition?: unknown })
        .SpeechRecognition ||
      (window as unknown as { webkitSpeechRecognition?: unknown })
        .webkitSpeechRecognition;

    if (!SpeechRec) {
      // If browser doesn't support SpeechRecognition, start the full Live Voice session instead
      startLiveVoiceSession();
      return;
    }

    if (isDictating) {
      if (recognitionRef.current) {
        try {
          recognitionRef.current.stop();
        } catch {
          // ignore
        }
      }
      setIsDictating(false);
      return;
    }

    try {
      setVoiceError(null);
      // eslint-disable-next-line @typescript-eslint/no-explicit-any
      const recognition = new (SpeechRec as any)();
      recognitionRef.current = recognition;
      recognition.lang =
        spokenVoiceLang === "ta"
          ? "ta-IN"
          : spokenVoiceLang === "hi"
          ? "hi-IN"
          : "en-IN";
      recognition.interimResults = true;
      recognition.maxAlternatives = 1;

      setIsDictating(true);
      setDictationTranscript("");

      recognition.onresult = (event: {
        results: { transcript: string; isFinal?: boolean }[][];
      }) => {
        let interimText = "";
        let finalText = "";
        // eslint-disable-next-line @typescript-eslint/no-explicit-any
        for (let i = 0; i < (event.results as any).length; ++i) {
          // eslint-disable-next-line @typescript-eslint/no-explicit-any
          const item = (event.results as any)[i];
          if (item.isFinal || item[0]?.isFinal) {
            finalText += item[0].transcript;
          } else {
            interimText += item[0].transcript;
          }
        }
        const combined = (finalText || interimText || "").trim();
        if (combined) {
          setInputText(combined);
          setDictationTranscript(combined);
        }
        if (finalText.trim()) {
          setIsDictating(false);
          setDictationTranscript("");
          handleAskQuestion(finalText.trim(), true);
        }
      };

      recognition.onerror = (event: { error?: string }) => {
        setIsDictating(false);
        if (
          event.error === "not-allowed" ||
          event.error === "service-not-allowed"
        ) {
          setMicPermissionDenied(true);
          setVoiceError(
            lang === "ta"
              ? "மைக்ரோஃபோன் அனுமதி மறுக்கப்பட்டுள்ளது. முகவரிப் பட்டியில் அனுமதி வழங்கவும்."
              : lang === "hi"
              ? "माइक्रोफ़ोन अनुमति ब्लॉक है। कृपया ब्राउज़र में अनुमति दें।"
              : "Microphone permission is blocked. Please allow microphone in browser address bar."
          );
        }
      };

      recognition.onend = () => {
        setIsDictating(false);
      };

      recognition.start();
    } catch {
      setIsDictating(false);
    }
  };

  return (
    <section
      id="voice-assistant"
      className="voice-assistant-section"
      aria-labelledby="voice-assistant-heading"
    >
      <div className="voice-assistant-container">
        <header className="voice-assistant-header">
          <span className="voice-kicker-badge">{ui.kicker}</span>
          <h2 id="voice-assistant-heading">{ui.title}</h2>
          <p className="voice-assistant-subtitle">{ui.subtitle}</p>

          <div className="voice-lang-bar">
            <span className="voice-lang-bar-label">
              🗣️{" "}
              {lang === "ta"
                ? "பேசும் மொழி (Voice Language):"
                : lang === "hi"
                ? "बातचीत की भाषा (Voice Language):"
                : "Voice Language:"}
            </span>
            <div className="voice-lang-pills">
              <button
                type="button"
                className={`voice-lang-pill ${
                  spokenVoiceLang === "ta" ? "active" : ""
                }`}
                onClick={() => setSpokenVoiceLang("ta")}
              >
                🇮🇳 தமிழ் (Tamil)
              </button>
              <button
                type="button"
                className={`voice-lang-pill ${
                  spokenVoiceLang === "en" ? "active" : ""
                }`}
                onClick={() => setSpokenVoiceLang("en")}
              >
                🇬🇧 English
              </button>
              <button
                type="button"
                className={`voice-lang-pill ${
                  spokenVoiceLang === "hi" ? "active" : ""
                }`}
                onClick={() => setSpokenVoiceLang("hi")}
              >
                🇮🇳 हिन्दी (Hindi)
              </button>
            </div>
            <button
              type="button"
              className="voice-test-sound-btn"
              onClick={handleTestAudioGreeting}
              title="Test audio guide voice"
            >
              🔊{" "}
              {lang === "ta"
                ? "குரல் ஒலி கேட்க (Test Sound)"
                : lang === "hi"
                ? "आवाज़ सुनें (Test Sound)"
                : "Test Guide Voice"}
            </button>
          </div>
        </header>

        <div className="voice-assistant-grid">
          {/* LEFT PANEL: Real-Time 2-Way Voice Conversation (Gemini 2.5 Live API) */}
          <div
            className={`voice-live-card ${
              liveStatus === "connected" ? "live-active" : ""
            }`}
          >
            <div className="voice-live-top">
              <div className="voice-orb-wrapper">
                <div
                  className={`voice-orb ${
                    liveStatus === "connected"
                      ? isModelSpeaking
                        ? "orb-speaking"
                        : isMicMuted
                        ? "orb-muted"
                        : "orb-listening"
                      : liveStatus === "connecting"
                      ? "orb-connecting"
                      : ""
                  }`}
                >
                  <span className="voice-orb-icon" aria-hidden="true">
                    {liveStatus === "connected"
                      ? isModelSpeaking
                        ? "🔊"
                        : isMicMuted
                        ? "🔇"
                        : "🎙️"
                      : "🎙️"}
                  </span>
                </div>
                {liveStatus === "connected" && !isMicMuted && (
                  <div className="voice-wave-bars" aria-hidden="true">
                    <span className="wave-bar bar-1" />
                    <span className="wave-bar bar-2" />
                    <span className="wave-bar bar-3" />
                    <span className="wave-bar bar-4" />
                    <span className="wave-bar bar-5" />
                  </div>
                )}
              </div>

              <div className="voice-live-info">
                <h3>{ui.liveCardTitle}</h3>
                <p>{ui.liveCardDesc}</p>
              </div>
            </div>

            <div className="voice-status-banner">
              <span
                className={`status-dot ${
                  liveStatus === "connected"
                    ? isModelSpeaking
                      ? "dot-speaking"
                      : isMicMuted
                      ? "dot-muted"
                      : "dot-listening"
                    : liveStatus === "connecting"
                    ? "dot-connecting"
                    : "dot-idle"
                }`}
              />
              <span className="status-text">
                {liveStatus === "idle" && ui.statusIdle}
                {liveStatus === "connecting" && ui.statusConnecting}
                {liveStatus === "connected" &&
                  (isModelSpeaking
                    ? ui.statusSpeaking
                    : isMicMuted
                    ? ui.statusMuted
                    : ui.statusListening)}
              </span>
            </div>

            {voiceError && !micPermissionDenied && (
              <div className="voice-error-alert" role="alert">
                ⚠️ {voiceError}
              </div>
            )}

            {micPermissionDenied && (
              <div className="mic-permission-help-card" role="alert">
                <div className="mic-help-header">
                  <span className="mic-help-icon" aria-hidden="true">
                    🎙️⚠️
                  </span>
                  <div>
                    <strong>
                      {lang === "ta"
                        ? "மைக்ரோஃபோன் அனுமதி தேவை (Microphone Access Blocked)"
                        : lang === "hi"
                        ? "माइक्रोफ़ोन अनुमति आवश्यक है (Microphone Access Blocked)"
                        : "Microphone Access is Blocked"}
                    </strong>
                    <p className="mic-help-subtitle">
                      {lang === "ta"
                        ? "குரலில் தமிழ், English அல்லது இந்தியில் பேச உங்கள் பிரவுசரில் அனுமதி வழங்கி 'Allow & Try Again' அழுத்தவும்:"
                        : lang === "hi"
                        ? "हिंदी, तमिल या अंग्रेजी में बोलने के लिए ब्राउज़र में अनुमति देकर 'Allow & Try Again' दबाएं:"
                        : "To speak in Tamil, English, or Hindi, enable microphone access and click 'Allow & Try Again':"}
                    </p>
                  </div>
                </div>

                <div className="mic-browser-tabs">
                  <button
                    type="button"
                    className={`browser-tab-btn ${
                      micHelpTab === "chrome" ? "active" : ""
                    }`}
                    onClick={() => setMicHelpTab("chrome")}
                  >
                    🌐 Google Chrome / Brave
                  </button>
                  <button
                    type="button"
                    className={`browser-tab-btn ${
                      micHelpTab === "edge" ? "active" : ""
                    }`}
                    onClick={() => setMicHelpTab("edge")}
                  >
                    🌀 Microsoft Edge
                  </button>
                  <button
                    type="button"
                    className={`browser-tab-btn ${
                      micHelpTab === "safari" ? "active" : ""
                    }`}
                    onClick={() => setMicHelpTab("safari")}
                  >
                    🍏 Safari (Apple)
                  </button>
                  <button
                    type="button"
                    className={`browser-tab-btn ${
                      micHelpTab === "mobile" ? "active" : ""
                    }`}
                    onClick={() => setMicHelpTab("mobile")}
                  >
                    📱 Mobile Phone
                  </button>
                </div>

                <div className="mic-tab-content">
                  {micHelpTab === "chrome" && (
                    <ol className="mic-help-steps">
                      <li>
                        {lang === "ta"
                          ? "பிரவுசரின் மேல் முகவரிப் பட்டியில் (URL bar) உள்ள 🔒 அல்லது ⚙️ ஐகானை அழுத்தவும்."
                          : "Click the 🔒 lock or site settings icon on the left side of the address bar at the top."}
                      </li>
                      <li>
                        {lang === "ta"
                          ? "Microphone என்பதற்கு எதிரே உள்ள சுவிட்சை 'Block' லிருந்து 'Allow' (அனுமதி) என மாற்றவும்."
                          : "Change 'Microphone' from 'Block' to 'Allow'."}
                      </li>
                      <li>
                        {lang === "ta"
                          ? "கீழே உள்ள 'அனுமதி வழங்கி மீண்டும் முயற்சிக்க' பட்டனை அழுத்தவும்."
                          : "Click the green 'Allow & Try Again' button below."}
                      </li>
                    </ol>
                  )}
                  {micHelpTab === "edge" && (
                    <ol className="mic-help-steps">
                      <li>
                        {lang === "ta"
                          ? "மேல் முகவரிப் பட்டியில் உள்ள 🔒 பூட்டு ஐகானைக் கிளிக் செய்யவும்."
                          : "Click the 🔒 lock icon in the Edge address bar."}
                      </li>
                      <li>
                        {lang === "ta"
                          ? "'Permissions for this site' -> Microphone என்பதை 'Allow' என மாற்றவும்."
                          : "Set 'Permissions for this site' -> Microphone to 'Allow'."}
                      </li>
                      <li>
                        {lang === "ta"
                          ? "கீழே உள்ள 'மீண்டும் முயற்சிக்க' பட்டனை அழுத்தவும்."
                          : "Click 'Allow & Try Again' below."}
                      </li>
                    </ol>
                  )}
                  {micHelpTab === "safari" && (
                    <ol className="mic-help-steps">
                      <li>
                        {lang === "ta"
                          ? "Safari மெனுவில் 'Settings for This Website' திறக்கவும்."
                          : "Open Safari -> 'Settings for This Website'."}
                      </li>
                      <li>
                        {lang === "ta"
                          ? "Microphone என்பதை 'Allow' என மாற்றவும்."
                          : "Set 'Microphone' to 'Allow'."}
                      </li>
                      <li>
                        {lang === "ta"
                          ? "பக்கத்தை ரீஃப்ரெஷ் செய்துவிட்டு மீண்டும் பேசவும்."
                          : "Click 'Allow & Try Again' below."}
                      </li>
                    </ol>
                  )}
                  {micHelpTab === "mobile" && (
                    <ol className="mic-help-steps">
                      <li>
                        {lang === "ta"
                          ? "மொபைல் பிரவுசரில் URL-க்கு அருகில் உள்ள 🔒 அல்லது 'Site Settings' அழுத்தவும்."
                          : "Tap the 🔒 lock or site settings icon next to the URL."}
                      </li>
                      <li>
                        {lang === "ta"
                          ? "Permissions -> Microphone என்பதைத் தட்டி 'Allow' செய்யவும்."
                          : "Tap Permissions -> Microphone -> Choose 'Allow'."}
                      </li>
                      <li>
                        {lang === "ta"
                          ? "கீழே உள்ள 'மீண்டும் முயற்சிக்க' பட்டனை அழுத்தவும்."
                          : "Tap 'Allow & Try Again' below."}
                      </li>
                    </ol>
                  )}
                </div>

                <div className="mic-help-actions">
                  <button
                    type="button"
                    className="mic-retry-btn"
                    onClick={handleRetryMic}
                  >
                    🔄{" "}
                    {lang === "ta"
                      ? "அனுமதி வழங்கி மீண்டும் முயற்சிக்க (Allow & Try Again)"
                      : lang === "hi"
                      ? "अनुमति दें और पुनः प्रयास करें (Allow & Try Again)"
                      : "Allow & Try Again"}
                  </button>
                  <button
                    type="button"
                    className="mic-dictate-btn"
                    onClick={handleDictateInput}
                  >
                    🎤{" "}
                    {lang === "ta"
                      ? "பேசி டைப் செய்க (Voice Dictation)"
                      : lang === "hi"
                      ? "बोलकर टाइप करें (Voice Dictation)"
                      : "Use Voice Dictation"}
                  </button>
                  <button
                    type="button"
                    className="mic-text-btn"
                    onClick={() => {
                      const inputEl = document.querySelector(
                        ".voice-chat-input-bar input"
                      ) as HTMLInputElement | null;
                      inputEl?.focus();
                    }}
                  >
                    💬{" "}
                    {lang === "ta"
                      ? "கீழே டைப் செய்து கேட்கவும் (Chat Input)"
                      : lang === "hi"
                      ? "चैट में पूछें (Chat Input)"
                      : "Ask via Chat"}
                  </button>
                </div>
              </div>
            )}

            <div className="voice-controls-row">
              {liveStatus === "idle" ? (
                <button
                  type="button"
                  className="voice-start-btn"
                  onClick={startLiveVoiceSession}
                >
                  {ui.startVoiceBtn}
                </button>
              ) : liveStatus === "connecting" ? (
                <button type="button" className="voice-start-btn" disabled>
                  {ui.connectingBtn}
                </button>
              ) : (
                <>
                  <button
                    type="button"
                    className={`voice-mute-btn ${isMicMuted ? "muted" : ""}`}
                    onClick={() => setIsMicMuted((m) => !m)}
                  >
                    {isMicMuted ? ui.unmuteMicBtn : ui.muteMicBtn}
                  </button>
                  <button
                    type="button"
                    className="voice-end-btn"
                    onClick={stopLiveVoiceSession}
                  >
                    {ui.endVoiceBtn}
                  </button>
                </>
              )}
            </div>

            {/* Live real-time streaming transcript preview while speaking */}
            {(liveInputTranscript || liveOutputTranscript) && (
              <div className="live-realtime-transcript">
                {liveInputTranscript && (
                  <div className="live-transcript-line user-line">
                    <strong>🎙️ {ui.liveTranscriptYou}:</strong>{" "}
                    <span>{liveInputTranscript}</span>
                  </div>
                )}
                {liveOutputTranscript && (
                  <div className="live-transcript-line model-line">
                    <strong>🔊 {ui.liveTranscriptGuide}:</strong>{" "}
                    <span>{liveOutputTranscript}</span>
                  </div>
                )}
              </div>
            )}

            {/* Quick-ask chips */}
            <div className="voice-quick-chips-box">
              <p className="quick-chips-label">{ui.quickQuestionsLabel}</p>
              <div className="quick-chips-list">
                {ui.quickQuestions.map((q, idx) => (
                  <button
                    key={idx}
                    type="button"
                    className="quick-question-chip"
                    onClick={() => handleAskQuestion(q)}
                    disabled={isAskingText}
                  >
                    {q}
                  </button>
                ))}
              </div>
            </div>
          </div>

          {/* RIGHT PANEL: Interactive Tourist Q&A Chat & Voice Transcript Feed */}
          <div className="voice-chat-card">
            <div className="voice-chat-header">
              <h4>{ui.askBoxTitle}</h4>
              <div className="voice-chat-header-tools">
                <label className="auto-speak-toggle">
                  <input
                    type="checkbox"
                    checked={autoSpeakReplies}
                    onChange={(e) => setAutoSpeakReplies(e.target.checked)}
                  />
                  <span>🔊 {ui.autoSpeakLabel}</span>
                </label>
                {messages.length > 1 && (
                  <button
                    type="button"
                    className="clear-chat-btn"
                    onClick={() =>
                      setMessages([
                        {
                          id: "welcome-0",
                          role: "model",
                          text: ui.welcomeMessage,
                          source: "text",
                          timestamp: new Date().toLocaleTimeString([], {
                            hour: "2-digit",
                            minute: "2-digit",
                          }),
                        },
                      ])
                    }
                  >
                    {ui.clearChatBtn}
                  </button>
                )}
              </div>
            </div>

            <div className="voice-chat-messages" ref={chatScrollRef}>
              {messages.map((msg) => (
                <div
                  key={msg.id}
                  className={`tourist-chat-bubble ${
                    msg.role === "user" ? "bubble-user" : "bubble-model"
                  }`}
                >
                  <div className="bubble-meta">
                    <span className="bubble-sender">
                      {msg.role === "user"
                        ? msg.source === "voice"
                          ? "🎙️ You (Voice)"
                          : "👤 You"
                        : msg.source === "voice"
                        ? "🔊 AI Tourist Guide (Live Voice)"
                        : "🧭 TN Smart Tourist Guide"}
                    </span>
                    <span className="bubble-time">{msg.timestamp}</span>
                  </div>
                  <div className="bubble-text">{msg.text}</div>
                  {msg.role === "model" && (
                    <div className="bubble-actions">
                      <button
                        type="button"
                        className={`bubble-listen-btn ${
                          playingMessageId === msg.id ? "playing" : ""
                        }`}
                        onClick={() => handleSpeakMessage(msg.id, msg.text)}
                      >
                        {playingMessageId === msg.id
                          ? ui.stopAudioBtn
                          : ui.listenBtn}
                      </button>
                    </div>
                  )}
                </div>
              ))}

              {isAskingText && (
                <div className="tourist-chat-bubble bubble-model bubble-loading">
                  <div className="bubble-meta">
                    <span className="bubble-sender">
                      🧭 TN Smart Tourist Guide
                    </span>
                  </div>
                  <div className="bubble-text">{ui.askingBtn}</div>
                </div>
              )}
            </div>

            {/* Active voice dictation bar */}
            {isDictating && (
              <div className="dictate-active-indicator" role="status">
                <span className="pulsing-mic-icon">🔴 🎙️</span>
                <span className="dictate-text">
                  {spokenVoiceLang === "ta"
                    ? "கேட்டுக்கொண்டிருக்கிறது... தமிழில் உங்கள் கேள்வியைப் பேசுங்கள் (Listening in Tamil)..."
                    : spokenVoiceLang === "hi"
                    ? "सुन रहा है... हिंदी में अपना प्रश्न बोलें (Listening in Hindi)..."
                    : "Listening... Speak your tourist question now!"}
                </span>
                {dictationTranscript && (
                  <span className="dictate-live-text">
                    "{dictationTranscript}"
                  </span>
                )}
                <button
                  type="button"
                  className="dictate-stop-btn"
                  onClick={handleDictateInput}
                >
                  ⏹️ {lang === "ta" ? "நிறுத்து" : "Stop"}
                </button>
              </div>
            )}

            <form
              className="voice-chat-input-bar"
              onSubmit={(e) => {
                e.preventDefault();
                handleAskQuestion(inputText);
              }}
            >
              <button
                type="button"
                className={`dictate-mic-btn ${isDictating ? "dictating" : ""}`}
                onClick={handleDictateInput}
                title={`${ui.dictateBtnTitle} (${
                  spokenVoiceLang === "ta"
                    ? "தமிழ்"
                    : spokenVoiceLang === "hi"
                    ? "हिन्दी"
                    : "English"
                })`}
                aria-label={ui.dictateBtnTitle}
              >
                🎤
              </button>
              <input
                type="text"
                value={inputText}
                onChange={(e) => setInputText(e.target.value)}
                placeholder={ui.inputPlaceholder}
                disabled={isAskingText}
              />
              <button
                type="submit"
                className="ask-submit-btn"
                disabled={isAskingText || !inputText.trim()}
              >
                {isAskingText ? ui.askingBtn : ui.askBtn}
              </button>
            </form>
          </div>
        </div>
      </div>
    </section>
  );
};

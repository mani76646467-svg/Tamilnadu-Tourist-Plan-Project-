/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useRef } from "react";
import {
  destinations,
  Destination,
  CATEGORY_IMAGES,
  fetchAllDestinationImages,
  getUniqueSpotsForTrip,
} from "./data/destinations";
import {
  CATEGORY_TAMIL,
  DESTINATION_TAMIL_NAMES,
  getTamilCityName,
  getSpotTamilDetails,
} from "./data/tamilTranslations";
import {
  AppLanguage,
  LANGUAGE_OPTIONS,
  UI_TRANSLATIONS,
  CATEGORY_HINDI,
  DESTINATION_HINDI_NAMES,
  getHindiCityName,
  getSpotHindiDetails,
} from "./data/i18n";
import {
  generateBilingualTripPdf,
  UniqueSpotSummary,
  SlotCategoryType,
} from "./utils/pdfGenerator";
import {
  fetchDestinationWeather,
  DestinationWeatherData,
} from "./utils/weatherService";
import { TouristVoiceAssistant } from "./components/TouristVoiceAssistant";
import { ItineraryRouteMap } from "./components/ItineraryRouteMap";

interface ScheduleSlot {
  order: number;
  slotType: SlotCategoryType;
  time: string;
  timeTa: string;
  timeHi: string;
  place: string;
  placeTa: string;
  placeHi: string;
  activity: string;
  activityTa: string;
  activityHi: string;
  costBreakdownNote: string;
  costPerPerson: number;
  totalSlotCost: number;
}

interface DayPlan {
  day: number;
  dayTitle: string;
  dayTitleTa: string;
  dayTitleHi: string;
  dayTotalCost: number;
  dayPerPersonCost: number;
  slots: ScheduleSlot[];
}

interface GeneratedPlan {
  startCity: string;
  startCityTa: string;
  startCityHi: string;
  destination: Destination;
  destNameTa: string;
  destNameHi: string;
  districtTa: string;
  districtHi: string;
  summaryTa: string;
  summaryHi: string;
  categoryTa: string;
  categoryHi: string;
  days: number;
  people: number;
  userBudgetPerPerson: number;
  userTotalBudget: number;
  travelPerPerson: number;
  stayPerPerson: number;
  foodPerPerson: number;
  sightseeingPerPerson: number;
  estimatedPerPersonCost: number;
  travelTotal: number;
  stayTotal: number;
  foodTotal: number;
  sightseeingTotal: number;
  estimatedTotalCost: number;
  uniqueSpotsVisited: UniqueSpotSummary[];
  itinerary: DayPlan[];
}

interface ColorTheme {
  id: string;
  name: string;
  nameTa: string;
  primary: string;
  primaryDark: string;
  accent: string;
  bg: string;
  sectionAlt: string;
  plannerGrad: string;
  tagBg: string;
  heroRgb: string;
  ctaBg: string;
  footerBg: string;
}

const COLOR_THEMES: ColorTheme[] = [
  {
    id: "chola-crimson",
    name: "1. Chola Temple Crimson & Gold",
    nameTa: "சோழர் கோவில் சிவப்பு & தங்கம்",
    primary: "#b91c1c",
    primaryDark: "#991b1b",
    accent: "#fbbf24",
    bg: "#fdfbf7",
    sectionAlt: "#fff5f5",
    plannerGrad: "#fee2e2",
    tagBg: "#fef2f2",
    heroRgb: "55, 12, 12",
    ctaBg: "#3b0a0a",
    footerBg: "#240505",
  },
  {
    id: "nilgiri-emerald",
    name: "2. Nilgiri Tea Emerald Green",
    nameTa: "நீலகிரி பசுமைப் பச்சை",
    primary: "#047857",
    primaryDark: "#065f46",
    accent: "#fbbf24",
    bg: "#f4fbf7",
    sectionAlt: "#ecfdf5",
    plannerGrad: "#d1fae5",
    tagBg: "#d1fae5",
    heroRgb: "6, 46, 34",
    ctaBg: "#063729",
    footerBg: "#032219",
  },
  {
    id: "coromandel-blue",
    name: "3. Marina Ocean Blue & Coral",
    nameTa: "மெரினா கடல் நீலம்",
    primary: "#0369a1",
    primaryDark: "#075985",
    accent: "#facc15",
    bg: "#f5f9fc",
    sectionAlt: "#e0f2fe",
    plannerGrad: "#dbeafe",
    tagBg: "#e0f2fe",
    heroRgb: "12, 38, 66",
    ctaBg: "#0c2d48",
    footerBg: "#071c2e",
  },
  {
    id: "madurai-saffron",
    name: "4. Madurai Saffron & Terracotta",
    nameTa: "மதுரை செம்மண் & குங்குமம்",
    primary: "#c2410c",
    primaryDark: "#9a3412",
    accent: "#fde047",
    bg: "#fffaf5",
    sectionAlt: "#fff7ed",
    plannerGrad: "#ffedd5",
    tagBg: "#ffedd5",
    heroRgb: "58, 22, 8",
    ctaBg: "#431407",
    footerBg: "#290b03",
  },
  {
    id: "kanchi-teal",
    name: "5. Kanchi Peacock Teal & Silk",
    nameTa: "காஞ்சி மயில் நீலம்",
    primary: "#0f766e",
    primaryDark: "#115e59",
    accent: "#fbbf24",
    bg: "#f4faf9",
    sectionAlt: "#f0fdfa",
    plannerGrad: "#ccfbf1",
    tagBg: "#ccfbf1",
    heroRgb: "11, 46, 44",
    ctaBg: "#134e4a",
    footerBg: "#082f2c",
  },
  {
    id: "royal-purple",
    name: "6. Classic Royal Purple",
    nameTa: "ராயல் ஊதா (Default)",
    primary: "#7c3aed",
    primaryDark: "#5b21b6",
    accent: "#fbbf24",
    bg: "#f7f6f1",
    sectionAlt: "#f5f0ff",
    plannerGrad: "#f1eaff",
    tagBg: "#ede9fe",
    heroRgb: "35, 15, 60",
    ctaBg: "#24113f",
    footerBg: "#160b26",
  },
];

export default function App() {
  const [activeLang, setActiveLang] = useState<AppLanguage>(() => {
    const saved = localStorage.getItem("tn_planner_lang");
    if (saved === "ta" || saved === "en" || saved === "hi") return saved;
    return "en";
  });
  const [activeThemeId, setActiveThemeId] = useState<string>(() => {
    return localStorage.getItem("tn_planner_theme") || "royal-purple";
  });
  const [searchText, setSearchText] = useState("");
  const [selectedCategory, setSelectedCategory] = useState("all");
  const [resolvedImages, setResolvedImages] = useState<Record<string, string>>(
    {}
  );

  const [startCity, setStartCity] = useState("Chennai");
  const [selectedDestination, setSelectedDestination] = useState(
    destinations[0].name
  );
  const [days, setDays] = useState<number>(3);
  const [people, setPeople] = useState<number>(2);
  const [budget, setBudget] = useState<number>(6000);
  const [generatedPlan, setGeneratedPlan] = useState<GeneratedPlan | null>(
    null
  );
  const [isGeneratingPdf, setIsGeneratingPdf] = useState(false);
  const [weatherData, setWeatherData] =
    useState<DestinationWeatherData | null>(null);
  const [isLoadingWeather, setIsLoadingWeather] = useState(false);
  const [weatherError, setWeatherError] = useState<string | null>(null);
  const [gmpQuotaExceeded, setGmpQuotaExceeded] = useState(false);

  const planResultRef = useRef<HTMLOutputElement | null>(null);
  const t = UI_TRANSLATIONS[activeLang];

  useEffect(() => {
    const handleQuota = () => setGmpQuotaExceeded(true);
    window.addEventListener("gmp-quota-exceeded", handleQuota);
    return () => window.removeEventListener("gmp-quota-exceeded", handleQuota);
  }, []);

  useEffect(() => {
    localStorage.setItem("tn_planner_lang", activeLang);
  }, [activeLang]);

  useEffect(() => {
    const theme =
      COLOR_THEMES.find((th) => th.id === activeThemeId) || COLOR_THEMES[5];
    const root = document.documentElement;
    root.style.setProperty("--color-primary", theme.primary);
    root.style.setProperty("--color-primary-dark", theme.primaryDark);
    root.style.setProperty("--color-accent", theme.accent);
    root.style.setProperty("--color-bg", theme.bg);
    root.style.setProperty("--color-section-alt", theme.sectionAlt);
    root.style.setProperty("--color-planner-grad", theme.plannerGrad);
    root.style.setProperty("--color-tag-bg", theme.tagBg);
    root.style.setProperty("--color-hero-rgb", theme.heroRgb);
    root.style.setProperty("--color-cta-bg", theme.ctaBg);
    root.style.setProperty("--color-footer-bg", theme.footerBg);
    localStorage.setItem("tn_planner_theme", theme.id);
  }, [activeThemeId]);

  useEffect(() => {
    let isMounted = true;
    fetchAllDestinationImages(destinations, (batchMap) => {
      if (isMounted) {
        setResolvedImages((prev) => ({ ...prev, ...batchMap }));
      }
    });
    return () => {
      isMounted = false;
    };
  }, []);

  const scrollToSection = (id: string) => {
    const section = document.getElementById(id);
    if (section) {
      section.scrollIntoView({
        behavior: "smooth",
      });
    }
  };

  const handleSelectDestinationCard = (destName: string) => {
    setSelectedDestination(destName);
    scrollToSection("planner");
  };

  const filteredDestinations = destinations.filter((destination) => {
    const query = searchText.toLowerCase().trim();
    const taMeta = DESTINATION_TAMIL_NAMES[destination.name];
    const hiMeta = DESTINATION_HINDI_NAMES[destination.name];
    const matchesSearch =
      destination.name.toLowerCase().includes(query) ||
      destination.district.toLowerCase().includes(query) ||
      (taMeta && taMeta.nameTa.includes(query)) ||
      (hiMeta && hiMeta.nameHi.includes(query)) ||
      destination.spots.some((s) => s.spotName.toLowerCase().includes(query));
    const matchesCategory =
      selectedCategory === "all" || destination.category === selectedCategory;

    return matchesSearch && matchesCategory;
  });

  const buildSequentialPlan = (
    city: string,
    destName: string,
    numDays: number,
    numPeople: number,
    userBudgetPerPerson: number
  ): GeneratedPlan => {
    const destObj =
      destinations.find((d) => d.name === destName) || destinations[0];

    const originCity = city.trim() || "Chennai";
    const originCityTa = getTamilCityName(originCity);
    const originCityHi = getHindiCityName(originCity);

    const tamilMeta = DESTINATION_TAMIL_NAMES[destObj.name] || {
      nameTa: destObj.name,
      districtTa: `${destObj.district} மாவட்டம்`,
      summaryTa: destObj.description,
    };
    const hindiMeta = DESTINATION_HINDI_NAMES[destObj.name] || {
      nameHi: destObj.name,
      districtHi: `${destObj.district} ज़िला`,
      summaryHi: destObj.description,
    };

    const categoryTa = CATEGORY_TAMIL[destObj.category];
    const categoryHi = CATEGORY_HINDI[destObj.category];

    const userTotalBudget = numPeople * userBudgetPerPerson;

    // Exact Daily Food Split so breakfastPP + lunchPP + dinnerPP === destObj.avgFoodPerDay
    const breakfastPP = Math.round(destObj.avgFoodPerDay * 0.25);
    const lunchPP = Math.round(destObj.avgFoodPerDay * 0.4);
    const dinnerPP = destObj.avgFoodPerDay - breakfastPP - lunchPP;

    let travelPerPerson = 0;
    let stayPerPerson = 0;
    let foodPerPerson = 0;
    let sightseeingPerPerson = 0;

    const itinerary: DayPlan[] = [];
    const uniqueSpotsVisited: UniqueSpotSummary[] = [];
    const spotsPool = getUniqueSpotsForTrip(destObj, numDays * 3);

    for (let d = 1; d <= numDays; d++) {
      const slots: ScheduleSlot[] = [];
      let orderCounter = 1;

      const spot1 = spotsPool[(d - 1) * 3];
      const spot2 = spotsPool[(d - 1) * 3 + 1];
      const spot3 = spotsPool[(d - 1) * 3 + 2];

      const spot1Ta = getSpotTamilDetails(
        spot1.spotName,
        spot1.activity,
        tamilMeta.nameTa,
        destObj.category
      );
      const spot2Ta = getSpotTamilDetails(
        spot2.spotName,
        spot2.activity,
        tamilMeta.nameTa,
        destObj.category
      );
      const spot3Ta = getSpotTamilDetails(
        spot3.spotName,
        spot3.activity,
        tamilMeta.nameTa,
        destObj.category
      );

      const spot1Hi = getSpotHindiDetails(
        spot1.spotName,
        spot1.activity,
        hindiMeta.nameHi,
        destObj.category
      );
      const spot2Hi = getSpotHindiDetails(
        spot2.spotName,
        spot2.activity,
        hindiMeta.nameHi,
        destObj.category
      );
      const spot3Hi = getSpotHindiDetails(
        spot3.spotName,
        spot3.activity,
        hindiMeta.nameHi,
        destObj.category
      );

      // 1. Morning Travel + Breakfast (Day 1) OR Morning Breakfast (Day 2+)
      if (d === 1) {
        const onwardTravelPP = destObj.avgTravelCostPerPerson;
        const slot1PP = onwardTravelPP + breakfastPP;
        const slot1Total = slot1PP * numPeople;
        travelPerPerson += onwardTravelPP;
        foodPerPerson += breakfastPP;

        slots.push({
          order: orderCounter++,
          slotType: "travel",
          time: "06:00 AM – 08:30 AM",
          timeTa: "காலை 06:00 – 08:30",
          timeHi: "सुबह 06:00 – 08:30",
          place: `${originCity} → ${destObj.name} (${destObj.district})`,
          placeTa: `${originCityTa} → ${tamilMeta.nameTa} (${tamilMeta.districtTa})`,
          placeHi: `${originCityHi} → ${hindiMeta.nameHi} (${hindiMeta.districtHi})`,
          activity: `Onward journey from ${originCity} to ${destObj.name}, arrival & South Indian morning breakfast`,
          activityTa: `${originCityTa} நகரிலிருந்து ${tamilMeta.nameTa} வருகை மற்றும் காலை சிற்றுண்டி`,
          activityHi: `${originCityHi} से ${hindiMeta.nameHi} आगमन और सुबह का दक्षिण भारतीय नाश्ता`,
          costBreakdownNote: `போக்குவரத்து (Travel) ₹${onwardTravelPP} + காலை உணவு (Breakfast) ₹${breakfastPP} = ₹${slot1PP}/நபர்`,
          costPerPerson: slot1PP,
          totalSlotCost: slot1Total,
        });
      } else {
        const breakfastTotal = breakfastPP * numPeople;
        foodPerPerson += breakfastPP;

        slots.push({
          order: orderCounter++,
          slotType: "food",
          time: "07:00 AM – 08:15 AM",
          timeTa: "காலை 07:00 – 08:15",
          timeHi: "सुबह 07:00 – 08:15",
          place: `${destObj.name} Traditional Tiffin Center`,
          placeTa: `${tamilMeta.nameTa} பாரம்பரிய காலை உணவகம்`,
          placeHi: `${hindiMeta.nameHi} पारंपरिक टिफिन सेंटर`,
          activity:
            "Morning South Indian breakfast (Idli, Pongal, Medhu Vadai & Filter Coffee)",
          activityTa:
            "காலை தென்னிந்திய சிற்றுண்டி (இட்லி, பொங்கல், வடை மற்றும் பில்டர் காபி)",
          activityHi:
            "दक्षिण भारतीय नाश्ता (इडली, पोंगल, वड़ा और फ़िल्टर कॉफ़ी)",
          costBreakdownNote: `காலை உணவு (Morning Breakfast): ₹${breakfastPP}/நபர் × ${numPeople} நபர் = ₹${breakfastTotal}`,
          costPerPerson: breakfastPP,
          totalSlotCost: breakfastTotal,
        });
      }

      // 2. Morning Tourist Spot 1
      const s1CostTotal = spot1.entryAndLocalCost * numPeople;
      sightseeingPerPerson += spot1.entryAndLocalCost;
      slots.push({
        order: orderCounter++,
        slotType: "spot",
        time: spot1.timeSlot,
        timeTa: `காலை (${spot1.timeSlot})`,
        timeHi: `सुबह (${spot1.timeSlot})`,
        place: spot1.spotName,
        placeTa: spot1Ta.placeTa,
        placeHi: spot1Hi.placeHi,
        activity: spot1.activity,
        activityTa: spot1Ta.activityTa,
        activityHi: spot1Hi.activityHi,
        costBreakdownNote: `நுழைவு & உள்ளூர் ஆட்டோ (Entry + Local Transport): ₹${spot1.entryAndLocalCost}/நபர் × ${numPeople} = ₹${s1CostTotal}`,
        costPerPerson: spot1.entryAndLocalCost,
        totalSlotCost: s1CostTotal,
      });
      uniqueSpotsVisited.push({
        spotIndex: uniqueSpotsVisited.length + 1,
        dayNumber: d,
        spotName: spot1.spotName,
        spotNameTa: spot1Ta.placeTa,
        spotNameHi: spot1Hi.placeHi,
        timeSlot: spot1.timeSlot,
        timeSlotTa: `காலை (${spot1.timeSlot})`,
        timeSlotHi: `सुबह (${spot1.timeSlot})`,
        activity: spot1.activity,
        activityTa: spot1Ta.activityTa,
        activityHi: spot1Hi.activityHi,
        perPersonCost: spot1.entryAndLocalCost,
        totalCost: s1CostTotal,
      });

      // 3. Mid-day Tourist Spot 2
      const s2CostTotal = spot2.entryAndLocalCost * numPeople;
      sightseeingPerPerson += spot2.entryAndLocalCost;
      slots.push({
        order: orderCounter++,
        slotType: "spot",
        time: "11:15 AM – 01:15 PM",
        timeTa: "முற்பகல் 11:15 – மதியம் 01:15",
        timeHi: "दोपहर 11:15 – 01:15",
        place: spot2.spotName,
        placeTa: spot2Ta.placeTa,
        placeHi: spot2Hi.placeHi,
        activity: spot2.activity,
        activityTa: spot2Ta.activityTa,
        activityHi: spot2Hi.activityHi,
        costBreakdownNote: `நுழைவு & உள்ளூர் ஆட்டோ (Entry + Local Transport): ₹${spot2.entryAndLocalCost}/நபர் × ${numPeople} = ₹${s2CostTotal}`,
        costPerPerson: spot2.entryAndLocalCost,
        totalSlotCost: s2CostTotal,
      });
      uniqueSpotsVisited.push({
        spotIndex: uniqueSpotsVisited.length + 1,
        dayNumber: d,
        spotName: spot2.spotName,
        spotNameTa: spot2Ta.placeTa,
        spotNameHi: spot2Hi.placeHi,
        timeSlot: "11:15 AM – 01:15 PM",
        timeSlotTa: "முற்பகல் 11:15 – மதியம் 01:15",
        timeSlotHi: "दोपहर 11:15 – 01:15",
        activity: spot2.activity,
        activityTa: spot2Ta.activityTa,
        activityHi: spot2Hi.activityHi,
        perPersonCost: spot2.entryAndLocalCost,
        totalCost: s2CostTotal,
      });

      // 4. Afternoon Lunch Break
      const lunchTotal = lunchPP * numPeople;
      foodPerPerson += lunchPP;
      slots.push({
        order: orderCounter++,
        slotType: "food",
        time: "01:15 PM – 02:30 PM",
        timeTa: "மதியம் 01:15 – 02:30",
        timeHi: "दोपहर 01:15 – 02:30",
        place: `${destObj.name} Heritage Dining Restaurant`,
        placeTa: `${tamilMeta.nameTa} பாரம்பரிய மதிய உணவகம்`,
        placeHi: `${hindiMeta.nameHi} पारंपरिक भोजनालय`,
        activity: `Authentic Tamil Nadu banana-leaf meals & ${destObj.district} regional specialties`,
        activityTa: `தமிழ்நாடு வாழை இலை விருந்து மற்றும் ${tamilMeta.nameTa} சிறப்பு உணவுகள்`,
        activityHi: `पारंपरिक तमिलनाडु केले के पत्ते का भोजन और ${hindiMeta.nameHi} के व्यंजन`,
        costBreakdownNote: `மதிய உணவு (Afternoon Lunch): ₹${lunchPP}/நபர் × ${numPeople} நபர் = ₹${lunchTotal}`,
        costPerPerson: lunchPP,
        totalSlotCost: lunchTotal,
      });

      // 5. Afternoon / Evening Tourist Spot 3
      const s3CostTotal = spot3.entryAndLocalCost * numPeople;
      sightseeingPerPerson += spot3.entryAndLocalCost;
      slots.push({
        order: orderCounter++,
        slotType: "spot",
        time: "03:15 PM – 06:15 PM",
        timeTa: "மதியம் 03:15 – மாலை 06:15",
        timeHi: "दोपहर 03:15 – शाम 06:15",
        place: spot3.spotName,
        placeTa: spot3Ta.placeTa,
        placeHi: spot3Hi.placeHi,
        activity: spot3.activity,
        activityTa: spot3Ta.activityTa,
        activityHi: spot3Hi.activityHi,
        costBreakdownNote: `நுழைவு & உள்ளூர் ஆட்டோ (Entry + Local Transport): ₹${spot3.entryAndLocalCost}/நபர் × ${numPeople} = ₹${s3CostTotal}`,
        costPerPerson: spot3.entryAndLocalCost,
        totalSlotCost: s3CostTotal,
      });
      uniqueSpotsVisited.push({
        spotIndex: uniqueSpotsVisited.length + 1,
        dayNumber: d,
        spotName: spot3.spotName,
        spotNameTa: spot3Ta.placeTa,
        spotNameHi: spot3Hi.placeHi,
        timeSlot: "03:15 PM – 06:15 PM",
        timeSlotTa: "மதியம் 03:15 – மாலை 06:15",
        timeSlotHi: "दोपहर 03:15 – शाम 06:15",
        activity: spot3.activity,
        activityTa: spot3Ta.activityTa,
        activityHi: spot3Hi.activityHi,
        perPersonCost: spot3.entryAndLocalCost,
        totalCost: s3CostTotal,
      });

      // 6. Night Dinner + Hotel Stay OR Night Dinner + Return Journey
      if (d === numDays) {
        const returnTravelPP = destObj.avgTravelCostPerPerson;
        const returnSlotPP = returnTravelPP + dinnerPP;
        const returnSlotTotal = returnSlotPP * numPeople;
        travelPerPerson += returnTravelPP;
        foodPerPerson += dinnerPP;

        slots.push({
          order: orderCounter++,
          slotType: "travel",
          time: "06:45 PM – 09:30 PM",
          timeTa: "மாலை 06:45 – இரவு 09:30",
          timeHi: "शाम 06:45 – रात 09:30",
          place: `${destObj.name} → Return to ${originCity}`,
          placeTa: `${tamilMeta.nameTa} → ${originCityTa} திரும்புதல்`,
          placeHi: `${hindiMeta.nameHi} → ${originCityHi} वापसी यात्रा`,
          activity: `Evening shopping, night dinner & return journey to ${originCity}`,
          activityTa: `நினைவுப் பொருட்கள் வாங்குதல், இரவு உணவு முடித்து ${originCityTa} திரும்புதல்`,
          activityHi: `शाम की खरीदारी, रात्रि भोजन और ${originCityHi} वापसी यात्रा`,
          costBreakdownNote: `திரும்பும் பயணம் (Return Travel) ₹${returnTravelPP} + இரவு உணவு (Dinner) ₹${dinnerPP} = ₹${returnSlotPP}/நபர்`,
          costPerPerson: returnSlotPP,
          totalSlotCost: returnSlotTotal,
        });
      } else {
        const hotelNightPP = destObj.avgHotelPerPerson;
        const dinnerAndStayPP = hotelNightPP + dinnerPP;
        const dinnerAndStayTotal = dinnerAndStayPP * numPeople;
        stayPerPerson += hotelNightPP;
        foodPerPerson += dinnerPP;

        slots.push({
          order: orderCounter++,
          slotType: "stay",
          time: "07:30 PM – 09:30 PM",
          timeTa: "இரவு 07:30 – 09:30",
          timeHi: "रात 07:30 – 09:30",
          place: `${destObj.name} Hotel Stay & Night Dinner`,
          placeTa: `${tamilMeta.nameTa} இரவு உணவு & விடுதி தங்குதல்`,
          placeHi: `${hindiMeta.nameHi} रात्रि भोजन और होटल विश्राम`,
          activity:
            "Evening dinner, local bazaar stroll & overnight hotel stay",
          activityTa:
            "இரவு உணவு, உள்ளூர் கடைவீதி உலா மற்றும் விடுதியில் இரவு தங்குதல்",
          activityHi:
            "रात्रि भोजन, स्थानीय बाज़ार भ्रमण और होटल में रात्रि विश्राम",
          costBreakdownNote: `விடுதி (Hotel Stay) ₹${hotelNightPP} + இரவு உணவு (Dinner) ₹${dinnerPP} = ₹${dinnerAndStayPP}/நபர்`,
          costPerPerson: dinnerAndStayPP,
          totalSlotCost: dinnerAndStayTotal,
        });
      }

      const dayPerPersonCost = slots.reduce(
        (sum, s) => sum + s.costPerPerson,
        0
      );
      const dayTotalCost = dayPerPersonCost * numPeople;

      const dayTitle = `${spot1.spotName}, ${spot2.spotName} & ${spot3.spotName}`;
      const dayTitleTa = `${spot1Ta.placeTa}, ${spot2Ta.placeTa}`;
      const dayTitleHi = `${hindiMeta.nameHi} दर्शन (Day ${d})`;

      itinerary.push({
        day: d,
        dayTitle,
        dayTitleTa,
        dayTitleHi,
        dayTotalCost,
        dayPerPersonCost,
        slots,
      });
    }

    const travelTotal = travelPerPerson * numPeople;
    const stayTotal = stayPerPerson * numPeople;
    const foodTotal = foodPerPerson * numPeople;
    const sightseeingTotal = sightseeingPerPerson * numPeople;
    const estimatedPerPersonCost =
      travelPerPerson + stayPerPerson + foodPerPerson + sightseeingPerPerson;
    const estimatedTotalCost = estimatedPerPersonCost * numPeople;

    return {
      startCity: originCity,
      startCityTa: originCityTa,
      startCityHi: originCityHi,
      destination: destObj,
      destNameTa: tamilMeta.nameTa,
      destNameHi: hindiMeta.nameHi,
      districtTa: tamilMeta.districtTa,
      districtHi: hindiMeta.districtHi,
      summaryTa: tamilMeta.summaryTa,
      summaryHi: hindiMeta.summaryHi,
      categoryTa,
      categoryHi,
      days: numDays,
      people: numPeople,
      userBudgetPerPerson,
      userTotalBudget,
      travelPerPerson,
      stayPerPerson,
      foodPerPerson,
      sightseeingPerPerson,
      estimatedPerPersonCost,
      travelTotal,
      stayTotal,
      foodTotal,
      sightseeingTotal,
      estimatedTotalCost,
      uniqueSpotsVisited,
      itinerary,
    };
  };

  const handleTripSubmit = (event: React.FormEvent<HTMLFormElement>) => {
    event.preventDefault();

    const plan = buildSequentialPlan(
      startCity,
      selectedDestination,
      Number(days),
      Number(people),
      Number(budget)
    );

    setGeneratedPlan(plan);
    setWeatherData(null);
    setWeatherError(null);

    setTimeout(() => {
      planResultRef.current?.scrollIntoView({
        behavior: "smooth",
        block: "start",
      });
    }, 50);
  };

  const handleCheckLocalWeather = async () => {
    if (!generatedPlan || isLoadingWeather) return;

    setIsLoadingWeather(true);
    setWeatherError(null);
    try {
      const data = await fetchDestinationWeather(
        generatedPlan.destination.name,
        generatedPlan.destination.category
      );
      setWeatherData(data);
    } catch {
      setWeatherError(
        "Unable to load live weather forecast right now. Please try again."
      );
    } finally {
      setIsLoadingWeather(false);
    }
  };

  const handleExportItinerary = async () => {
    if (!generatedPlan || isGeneratingPdf) return;

    setIsGeneratingPdf(true);
    try {
      const activeTheme =
        COLOR_THEMES.find((th) => th.id === activeThemeId) || COLOR_THEMES[5];
      await generateBilingualTripPdf(
        generatedPlan,
        {
          primary: activeTheme.primary,
          primaryDark: activeTheme.primaryDark,
          tagBg: activeTheme.tagBg,
          footerBg: activeTheme.footerBg,
        },
        activeLang
      );
    } finally {
      setIsGeneratingPdf(false);
    }
  };

  const getLocalizedDestName = (dest: Destination) => {
    if (activeLang === "ta") {
      const ta = DESTINATION_TAMIL_NAMES[dest.name]?.nameTa;
      return ta ? `${ta} (${dest.name})` : dest.name;
    }
    if (activeLang === "hi") {
      const hi = DESTINATION_HINDI_NAMES[dest.name]?.nameHi;
      return hi ? `${hi} (${dest.name})` : dest.name;
    }
    return dest.name;
  };

  const getLocalizedDestDesc = (dest: Destination) => {
    if (activeLang === "ta") {
      return DESTINATION_TAMIL_NAMES[dest.name]?.summaryTa || dest.description;
    }
    if (activeLang === "hi") {
      return DESTINATION_HINDI_NAMES[dest.name]?.summaryHi || dest.description;
    }
    return dest.description;
  };

  const getLocalizedCategory = (cat: Destination["category"]) => {
    if (activeLang === "ta") return CATEGORY_TAMIL[cat];
    if (activeLang === "hi") return CATEGORY_HINDI[cat];
    return cat;
  };

  const currentThemeObj =
    COLOR_THEMES.find((th) => th.id === activeThemeId) || COLOR_THEMES[5];

  return (
    <>
      {gmpQuotaExceeded && (
        <div className="bg-amber-50 border-b border-amber-200 text-amber-900 px-4 py-2.5 text-xs md:text-sm text-center sticky top-0 z-50 shadow-sm">
          <span>
            Google Maps Platform quota reached. If you are the app owner, visit{" "}
            <a
              href="https://developers.google.com/maps/ai/ai-studio?utm_campaign=gmp_mcp_codeassist_v1_aistudio#quota_exceeded_errors"
              target="_blank"
              rel="noopener noreferrer"
              className="underline font-semibold text-amber-950 hover:text-amber-800"
            >
              maps developer site
            </a>{" "}
            for instructions to update your account.
          </span>
        </div>
      )}
      <header className="navbar">
        <div className="logo">
          <span aria-hidden="true">TN</span>
          {t.appName}
        </div>

        <nav aria-label="Primary navigation">
          <a href="#home">{t.navHome}</a>
          <a href="#voice-assistant">
            🎙️{" "}
            {activeLang === "ta"
              ? "குரல் வழிகாட்டி"
              : activeLang === "hi"
              ? "वॉइस गाइड"
              : "Voice Guide"}
          </a>
          <a href="#destinations">
            {t.navDestinations} ({destinations.length})
          </a>
          <a href="#planner">{t.navPlanner}</a>
          <a href="#features">{t.navFeatures}</a>
        </nav>

        <div className="nav-actions">
          <div
            className="lang-switcher"
            role="group"
            aria-label="Select Language (Tamil, English, Hindi)"
          >
            {LANGUAGE_OPTIONS.map((langOpt) => (
              <button
                key={langOpt.code}
                type="button"
                className={`lang-btn ${
                  activeLang === langOpt.code ? "active" : ""
                }`}
                onClick={() => setActiveLang(langOpt.code)}
                title={langOpt.nativeName}
              >
                {langOpt.label}
              </button>
            ))}
          </div>

          <button
            className="nav-button"
            type="button"
            onClick={() => scrollToSection("planner")}
          >
            {t.navPlanTripBtn}
          </button>
        </div>
      </header>

      <div
        className="theme-bar"
        role="region"
        aria-label="Choose Frontend Color Theme"
      >
        <div className="theme-bar-label">
          <span>{t.themeBarLabel}</span>
        </div>
        <div className="theme-options">
          {COLOR_THEMES.map((theme) => (
            <button
              key={theme.id}
              type="button"
              className={`theme-chip ${
                activeThemeId === theme.id ? "active" : ""
              }`}
              onClick={() => setActiveThemeId(theme.id)}
            >
              <span className={`theme-swatch swatch-${theme.id}`} />
              <span>{activeLang === "ta" ? theme.nameTa : theme.name}</span>
            </button>
          ))}
        </div>
      </div>

      <main>
        <section id="home" className="hero" aria-labelledby="hero-title">
          <div className="hero-overlay" aria-hidden="true"></div>
          <div className="hero-content">
            <p className="small-title">{t.heroKicker}</p>
            <h1 id="hero-title">
              {t.heroTitlePrefix}
              <span>{t.heroTitleHighlight}</span>
            </h1>
            <p className="hero-text">{t.heroDesc(destinations.length)}</p>
            <div className="hero-buttons">
              <button
                className="primary-btn"
                type="button"
                onClick={() => scrollToSection("destinations")}
              >
                {t.heroExploreBtn(destinations.length)}
              </button>
              <button
                className="outline-btn"
                type="button"
                onClick={() => scrollToSection("planner")}
              >
                {t.heroBuildBtn}
              </button>
              <button
                className="hero-voice-btn"
                type="button"
                onClick={() => scrollToSection("voice-assistant")}
              >
                🎙️{" "}
                {activeLang === "ta"
                  ? "குரல் உரையாடல் & சுற்றுலா AI கேள்வி-பதில்"
                  : activeLang === "hi"
                  ? "लाइव वॉइस बातचीत और पर्यटन प्रश्नोत्तर"
                  : "Live Voice Conversation & Tourist Q&A"}
              </button>
            </div>
          </div>
        </section>

        <TouristVoiceAssistant lang={activeLang} />

        <section
          id="features"
          className="section"
          aria-labelledby="features-title"
        >
          <header className="section-title">
            <p className="small-title">{t.featuresKicker}</p>
            <h2 id="features-title">{t.featuresTitle}</h2>
          </header>
          <div className="feature-container">
            <article className="feature-card">
              <div className="feature-icon">🗺️</div>
              <h3>{t.feat1Title}</h3>
              <p>{t.feat1Desc}</p>
            </article>
            <article className="feature-card">
              <div className="feature-icon">💰</div>
              <h3>{t.feat2Title}</h3>
              <p>{t.feat2Desc}</p>
            </article>
            <article className="feature-card">
              <div className="feature-icon">📍</div>
              <h3>{t.feat3Title(destinations.length)}</h3>
              <p>{t.feat3Desc}</p>
            </article>
            <article className="feature-card">
              <div className="feature-icon">🌐</div>
              <h3>{t.feat4Title}</h3>
              <p>{t.feat4Desc}</p>
            </article>
          </div>
        </section>

        <section
          id="destinations"
          className="section destinations-section"
          aria-labelledby="destinations-title"
        >
          <header className="section-heading-row">
            <div>
              <p className="small-title">
                {t.destKicker(filteredDestinations.length)}
              </p>
              <h2 id="destinations-title">{t.destTitle}</h2>
            </div>

            <form
              className="filters"
              role="search"
              aria-label="Filter destinations"
              onSubmit={(e) => e.preventDefault()}
            >
              <div className="form-field">
                <label htmlFor="searchInput">{t.searchLabel}</label>
                <input
                  type="search"
                  id="searchInput"
                  name="destination-search"
                  placeholder={t.searchPlaceholder}
                  autoComplete="off"
                  value={searchText}
                  onChange={(e) => setSearchText(e.target.value)}
                />
              </div>

              <div className="form-field">
                <label htmlFor="categoryFilter">{t.categoryLabel}</label>
                <select
                  id="categoryFilter"
                  name="destination-category"
                  value={selectedCategory}
                  onChange={(e) => setSelectedCategory(e.target.value)}
                >
                  <option value="all">
                    {t.allCategories(destinations.length)}
                  </option>
                  <option value="Temple">
                    {getLocalizedCategory("Temple")}
                  </option>
                  <option value="Hill Station">
                    {getLocalizedCategory("Hill Station")}
                  </option>
                  <option value="Beach">{getLocalizedCategory("Beach")}</option>
                  <option value="Heritage">
                    {getLocalizedCategory("Heritage")}
                  </option>
                  <option value="Nature & Waterfalls">
                    {getLocalizedCategory("Nature & Waterfalls")}
                  </option>
                </select>
              </div>
            </form>
          </header>

          <div
            id="destinationContainer"
            className="destination-container"
            aria-live="polite"
          >
            {filteredDestinations.length === 0 ? (
              <p>No destinations found matching "{searchText}".</p>
            ) : (
              filteredDestinations.map((destination) => {
                const imgSrc =
                  resolvedImages[destination.name] ||
                  CATEGORY_IMAGES[destination.category];
                const day1SpotsCost = destination.spots
                  .slice(0, 3)
                  .reduce((acc, s) => acc + s.entryAndLocalCost, 0);
                const estDailyPerPerson =
                  destination.avgHotelPerPerson +
                  destination.avgFoodPerDay +
                  day1SpotsCost;

                return (
                  <div key={destination.name} className="destination-card">
                    <div className="destination-image-wrap">
                      <img
                        src={imgSrc}
                        alt={`${destination.name}, ${destination.category} destination in ${destination.district}`}
                        referrerPolicy="no-referrer"
                        loading="lazy"
                        onError={(e) => {
                          const target = e.currentTarget;
                          const fallback =
                            CATEGORY_IMAGES[destination.category];
                          if (target.src !== window.location.origin + fallback) {
                            target.src = fallback;
                          }
                        }}
                      />
                      <span className="district-tag">
                        📍 {destination.district} {t.districtSuffix}
                      </span>
                    </div>
                    <div className="destination-content">
                      <div className="destination-meta-top">
                        <span className="category">
                          {getLocalizedCategory(destination.category)}
                        </span>
                        <span className="est-cost-tag">
                          ₹{estDailyPerPerson.toLocaleString("en-IN")}
                          {t.perDaySuffix}
                        </span>
                      </div>
                      <h3>{getLocalizedDestName(destination)}</h3>
                      <p>{getLocalizedDestDesc(destination)}</p>
                      <div className="spot-preview-list">
                        <div className="spot-badge-row">
                          <strong>{t.mustVisitLabel}</strong>
                          <span className="spots-count-tag">
                            {t.spotsCountBadge(destination.spots.length)}
                          </span>
                        </div>
                        <div className="spot-chip-list">
                          {destination.spots.slice(0, 5).map((s) => (
                            <span key={s.spotName} className="spot-chip">
                              📍 {s.spotName} (₹{s.entryAndLocalCost})
                            </span>
                          ))}
                          {destination.spots.length > 5 && (
                            <span className="spot-chip">
                              +{destination.spots.length - 5} more places
                            </span>
                          )}
                        </div>
                      </div>
                      <button
                        type="button"
                        className="card-plan-btn"
                        onClick={() =>
                          handleSelectDestinationCard(destination.name)
                        }
                      >
                        {t.planTripToBtn(getLocalizedDestName(destination))}
                      </button>
                    </div>
                  </div>
                );
              })
            )}
          </div>
        </section>

        <section
          id="planner"
          className="planner-section"
          aria-labelledby="planner-title"
        >
          <div className="planner">
            <div className="planner-info">
              <p className="small-title">{t.plannerKicker}</p>
              <h2 id="planner-title">{t.plannerTitle}</h2>
              <p>{t.plannerDesc(destinations.length)}</p>
              <ul>
                <li>{t.plannerBullet1}</li>
                <li>{t.plannerBullet2}</li>
                <li>{t.plannerBullet3}</li>
                <li>{t.plannerBullet4}</li>
              </ul>
            </div>

            <form
              id="tripForm"
              className="planner-form"
              onSubmit={handleTripSubmit}
            >
              <fieldset>
                <legend>{t.formLegend}</legend>

                <div className="form-field">
                  <label htmlFor="startCity">{t.labelStartCity}</label>
                  <input
                    type="text"
                    id="startCity"
                    name="start-city"
                    placeholder="Example: Chennai"
                    value={startCity}
                    onChange={(e) => setStartCity(e.target.value)}
                    required
                  />
                </div>

                <div className="form-field">
                  <label htmlFor="destinationSelect">
                    {t.labelDestination(destinations.length)}
                  </label>
                  <select
                    id="destinationSelect"
                    name="destination"
                    value={selectedDestination}
                    onChange={(e) => setSelectedDestination(e.target.value)}
                    required
                  >
                    {destinations.map((destination) => (
                      <option key={destination.name} value={destination.name}>
                        {getLocalizedDestName(destination)} (
                        {destination.district} • {destination.spots.length}{" "}
                        Spots)
                      </option>
                    ))}
                  </select>
                </div>

                <div className="two-inputs">
                  <div className="form-field">
                    <label htmlFor="days">{t.labelDays}</label>
                    <input
                      type="number"
                      id="days"
                      name="days"
                      min={1}
                      max={15}
                      value={days}
                      onChange={(e) => setDays(Number(e.target.value))}
                      required
                    />
                  </div>

                  <div className="form-field">
                    <label htmlFor="people">{t.labelPeople}</label>
                    <input
                      type="number"
                      id="people"
                      name="people"
                      min={1}
                      value={people}
                      onChange={(e) => setPeople(Number(e.target.value))}
                      required
                    />
                  </div>
                </div>

                <div className="form-field">
                  <label htmlFor="budget">{t.labelBudgetPP}</label>
                  <input
                    type="number"
                    id="budget"
                    name="budget"
                    min={500}
                    value={budget}
                    onChange={(e) => setBudget(Number(e.target.value))}
                    required
                  />
                </div>
              </fieldset>

              <button type="submit" className="primary-btn full-btn">
                {t.generateBtn}
              </button>
            </form>
          </div>

          <output
            ref={planResultRef}
            id="planResult"
            className={`plan-result ${generatedPlan ? "" : "hidden"}`}
            aria-live="polite"
            tabIndex={-1}
          >
            {generatedPlan && (
              <>
                <div className="plan-result-header">
                  <div>
                    <p className="small-title">{t.planResultKicker}</p>
                    <h3>
                      {generatedPlan.startCity} ({generatedPlan.startCityTa} /{" "}
                      {generatedPlan.startCityHi}) →{" "}
                      {generatedPlan.destination.name} (
                      {generatedPlan.destNameTa} / {generatedPlan.destNameHi})
                    </h3>
                    <p>
                      <strong>
                        {generatedPlan.days} {t.daysLabel}
                      </strong>{" "}
                      |{" "}
                      <strong>
                        {generatedPlan.people} {t.peopleLabel}
                      </strong>{" "}
                      |{" "}
                      <strong>
                        👤 {t.perPersonLabel}: ₹
                        {generatedPlan.estimatedPerPersonCost.toLocaleString(
                          "en-IN"
                        )}
                      </strong>{" "}
                      |{" "}
                      <strong>
                        👥 {t.estTripCostLabel}: ₹
                        {generatedPlan.estimatedTotalCost.toLocaleString(
                          "en-IN"
                        )}
                      </strong>{" "}
                      ({t.yourBudgetLabel}: ₹
                      {generatedPlan.userTotalBudget.toLocaleString("en-IN")})
                    </p>
                  </div>
                  <div className="plan-action-buttons">
                    <button
                      type="button"
                      className="weather-btn"
                      onClick={handleCheckLocalWeather}
                      disabled={isLoadingWeather}
                    >
                      {isLoadingWeather
                        ? t.checkingWeatherBtn
                        : t.checkWeatherBtn}
                    </button>
                    <button
                      type="button"
                      className="primary-btn export-btn"
                      onClick={handleExportItinerary}
                      disabled={isGeneratingPdf}
                    >
                      {isGeneratingPdf ? t.generatingPdfBtn : t.downloadPdfBtn}
                    </button>
                  </div>
                </div>

                {weatherError && (
                  <div className="weather-error-banner">{weatherError}</div>
                )}

                {weatherData && (
                  <div className="weather-panel" aria-live="polite">
                    <div className="weather-panel-header">
                      <div className="weather-panel-title">
                        {t.weatherSectionTitle(
                          getLocalizedDestName(generatedPlan.destination)
                        )}
                      </div>
                      <span className="weather-updated-tag">
                        Live API • Updated {weatherData.fetchedAt}
                      </span>
                    </div>

                    <div className="weather-top-grid">
                      <div className="weather-current-card">
                        <div className="weather-main-row">
                          <span
                            className="weather-big-icon"
                            aria-hidden="true"
                          >
                            {weatherData.icon}
                          </span>
                          <div>
                            <div className="weather-big-temp">
                              {weatherData.currentTemp}°C
                            </div>
                            <div className="weather-cond-text">
                              {activeLang === "ta"
                                ? `${weatherData.conditionTa} (${weatherData.conditionEn})`
                                : activeLang === "hi"
                                ? `${weatherData.conditionHi} (${weatherData.conditionEn})`
                                : `${weatherData.conditionEn} • ${weatherData.conditionTa}`}
                            </div>
                          </div>
                        </div>

                        <div className="weather-metrics-row">
                          <div className="weather-metric-box">
                            <small>{t.feelsLikeLabel}</small>
                            <strong>{weatherData.feelsLike}°C</strong>
                          </div>
                          <div className="weather-metric-box">
                            <small>{t.humidityLabel}</small>
                            <strong>{weatherData.humidity}%</strong>
                          </div>
                          <div className="weather-metric-box">
                            <small>{t.windSpeedLabel}</small>
                            <strong>{weatherData.windSpeed} km/h</strong>
                          </div>
                        </div>
                      </div>

                      <div className="weather-forecast-box">
                        <div className="weather-sub-heading">
                          {t.forecast5DayTitle}
                        </div>
                        <div className="weather-days-grid">
                          {weatherData.daily.map((dayWeather) => (
                            <div
                              key={dayWeather.date}
                              className="weather-day-chip"
                            >
                              <strong>{dayWeather.dayLabel}</strong>
                              <div
                                className="weather-day-icon"
                                aria-hidden="true"
                              >
                                {dayWeather.icon}
                              </div>
                              <div className="weather-day-temps">
                                {dayWeather.maxTemp}° / {dayWeather.minTemp}°C
                              </div>
                              <span className="weather-day-rain">
                                ☔ {dayWeather.rainChance}%
                              </span>
                            </div>
                          ))}
                        </div>
                      </div>
                    </div>

                    <div className="packing-box">
                      <div className="weather-sub-heading">
                        {t.packingTipsTitle}
                      </div>
                      <div className="packing-grid">
                        {weatherData.packingTips.map((tip, idx) => (
                          <div key={idx} className="packing-tip-card">
                            <strong>
                              {tip.icon}{" "}
                              {activeLang === "ta"
                                ? tip.ta
                                : activeLang === "hi"
                                ? tip.hi
                                : tip.en}
                            </strong>
                            {activeLang !== "ta" && (
                              <span className="bilingual-sub">{tip.ta}</span>
                            )}
                          </div>
                        ))}
                      </div>
                    </div>
                  </div>
                )}

                <div className="budget-breakdown-grid">
                  <div className="budget-item">
                    <span>{t.budgetBox1Title}</span>
                    <strong>
                      ₹{generatedPlan.travelTotal.toLocaleString("en-IN")}
                    </strong>
                    <small>
                      👤 ₹
                      {generatedPlan.travelPerPerson.toLocaleString("en-IN")}
                      /நபர் •{" "}
                      {t.budgetBox1Sub(
                        generatedPlan.startCity,
                        generatedPlan.people
                      )}
                    </small>
                  </div>
                  <div className="budget-item">
                    <span>{t.budgetBox2Title}</span>
                    <strong>
                      ₹{generatedPlan.stayTotal.toLocaleString("en-IN")}
                    </strong>
                    <small>
                      👤 ₹{generatedPlan.stayPerPerson.toLocaleString("en-IN")}
                      /நபர் •{" "}
                      {t.budgetBox2Sub(Math.max(0, generatedPlan.days - 1))}
                    </small>
                  </div>
                  <div className="budget-item">
                    <span>{t.budgetBox3Title}</span>
                    <strong>
                      ₹{generatedPlan.foodTotal.toLocaleString("en-IN")}
                    </strong>
                    <small>
                      👤 ₹{generatedPlan.foodPerPerson.toLocaleString("en-IN")}
                      /நபர் • {t.budgetBox3Sub(generatedPlan.days)}
                    </small>
                  </div>
                  <div className="budget-item">
                    <span>{t.budgetBox4Title}</span>
                    <strong>
                      ₹{generatedPlan.sightseeingTotal.toLocaleString("en-IN")}
                    </strong>
                    <small>
                      👤 ₹
                      {generatedPlan.sightseeingPerPerson.toLocaleString(
                        "en-IN"
                      )}
                      /நபர் •{" "}
                      {t.budgetBox4Sub(generatedPlan.uniqueSpotsVisited.length)}
                    </small>
                  </div>
                </div>

                <div className="exact-formula-banner">
                  ✓ துல்லியமான மொத்த கணக்கு (Exact Cost Calculation): போக்குவரத்து
                  (₹{generatedPlan.travelPerPerson}) + தங்குமிடம் (₹
                  {generatedPlan.stayPerPerson}) + உணவு (₹
                  {generatedPlan.foodPerPerson}) +{" "}
                  {generatedPlan.uniqueSpotsVisited.length} சுற்றுலா இடங்கள் (₹
                  {generatedPlan.sightseeingPerPerson}) ={" "}
                  <u>
                    ₹
                    {generatedPlan.estimatedPerPersonCost.toLocaleString(
                      "en-IN"
                    )}
                    /நபர்
                  </u>{" "}
                  × {generatedPlan.people} நபர்கள் ={" "}
                  <u>
                    ₹{generatedPlan.estimatedTotalCost.toLocaleString("en-IN")}
                  </u>
                </div>

                <div
                  className={`budget-status-banner ${
                    generatedPlan.userTotalBudget >=
                    generatedPlan.estimatedTotalCost
                      ? "budget-status-ok"
                      : "budget-status-tight"
                  }`}
                >
                  <span>
                    {generatedPlan.userTotalBudget >=
                    generatedPlan.estimatedTotalCost
                      ? `✓ Your budget (₹${generatedPlan.userTotalBudget.toLocaleString(
                          "en-IN"
                        )}) comfortably covers the exact trip cost with ₹${(
                          generatedPlan.userTotalBudget -
                          generatedPlan.estimatedTotalCost
                        ).toLocaleString("en-IN")} extra buffer for shopping!`
                      : `ℹ️ Exact trip cost is ₹${generatedPlan.estimatedTotalCost.toLocaleString(
                          "en-IN"
                        )} (₹${generatedPlan.estimatedPerPersonCost.toLocaleString(
                          "en-IN"
                        )}/person). Increase per-person budget by ₹${(
                          generatedPlan.estimatedPerPersonCost -
                          generatedPlan.userBudgetPerPerson
                        ).toLocaleString("en-IN")} to cover all expenses.`}
                  </span>
                  <span>
                    Exact Per Person: ₹
                    {generatedPlan.estimatedPerPersonCost.toLocaleString(
                      "en-IN"
                    )}
                  </span>
                </div>

                <ItineraryRouteMap
                  destinationName={generatedPlan.destination.name}
                  destDisplayName={getLocalizedDestName(
                    generatedPlan.destination
                  )}
                  district={generatedPlan.destination.district}
                  days={generatedPlan.days}
                  uniqueSpots={generatedPlan.uniqueSpotsVisited}
                  lang={activeLang}
                  primaryColor={currentThemeObj.primary}
                />

                <div className="unique-spots-section">
                  <div className="unique-spots-heading">
                    {t.uniqueSpotsHeading(
                      generatedPlan.uniqueSpotsVisited.length,
                      getLocalizedDestName(generatedPlan.destination)
                    )}
                  </div>
                  <div className="unique-spots-grid">
                    {generatedPlan.uniqueSpotsVisited.map((spot) => (
                      <div key={spot.spotIndex} className="unique-spot-card">
                        <div className="spot-badge-row">
                          <span className="spot-num-tag">
                            #{spot.spotIndex} • {t.dayLabel} {spot.dayNumber}
                          </span>
                          <span className="spot-price-pill">
                            👤 ₹{spot.perPersonCost}/நபர்
                          </span>
                        </div>
                        <div>
                          <span className="spot-time-pill">
                            🕒 {spot.timeSlot}
                          </span>
                        </div>
                        <strong className="spot-card-title">
                          {spot.spotName}
                        </strong>
                        <span className="bilingual-sub">
                          {activeLang === "hi"
                            ? `${spot.spotNameTa} • ${spot.spotNameHi}`
                            : spot.spotNameTa}
                        </span>
                        <small className="spot-card-activity">
                          {spot.activity}
                        </small>
                        <div className="spot-card-cost-bar">
                          🎫 ₹{spot.perPersonCost}/நபர் × {generatedPlan.people}{" "}
                          = மொத்தம் ₹{spot.totalCost.toLocaleString("en-IN")}
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

                <div className="plan-days">
                  {generatedPlan.itinerary.map((dayItem) => (
                    <div key={dayItem.day} className="day-card">
                      <div className="day-card-header">
                        <div>
                          <strong>
                            {t.dayLabel} {dayItem.day}: {dayItem.dayTitle}
                          </strong>
                          <span className="bilingual-sub">
                            நாள் {dayItem.day}: {dayItem.dayTitleTa} • दिन{" "}
                            {dayItem.day}: {dayItem.dayTitleHi}
                          </span>
                        </div>
                        <span className="day-total-badge">
                          👤 ₹{dayItem.dayPerPersonCost.toLocaleString("en-IN")}
                          /நபர் | 👥 {t.totalLabel}: ₹
                          {dayItem.dayTotalCost.toLocaleString("en-IN")}
                        </span>
                      </div>

                      <div className="schedule-table-wrap">
                        <table className="schedule-table">
                          <thead>
                            <tr>
                              <th>{t.thOrderTime}</th>
                              <th>{t.thPlace}</th>
                              <th>{t.thActivity}</th>
                              <th>{t.thCost}</th>
                            </tr>
                          </thead>
                          <tbody>
                            {dayItem.slots.map((slot) => (
                              <tr key={slot.order}>
                                <td className="slot-time">
                                  <div className="slot-time-top">
                                    <span className="slot-order-num">
                                      {slot.order}
                                    </span>
                                    <span className="spot-time-pill">
                                      🕒 {slot.time}
                                    </span>
                                  </div>
                                  <span className="bilingual-sub">
                                    {activeLang === "hi"
                                      ? `${slot.timeTa} • ${slot.timeHi}`
                                      : slot.timeTa}
                                  </span>
                                </td>
                                <td className="slot-place">
                                  {slot.place}
                                  <span className="bilingual-sub">
                                    {activeLang === "hi"
                                      ? `${slot.placeTa} (${slot.placeHi})`
                                      : slot.placeTa}
                                  </span>
                                </td>
                                <td>
                                  <div>{slot.activity}</div>
                                  <span className="bilingual-sub">
                                    {activeLang === "hi"
                                      ? slot.activityHi
                                      : slot.activityTa}
                                  </span>
                                  <span className="slot-breakdown-note">
                                    💳 {slot.costBreakdownNote}
                                  </span>
                                </td>
                                <td className="slot-cost">
                                  <div>
                                    <span className="spot-price-pill">
                                      👤 ₹
                                      {slot.costPerPerson.toLocaleString(
                                        "en-IN"
                                      )}{" "}
                                      / நபர்
                                    </span>
                                  </div>
                                  <div>
                                    <span className="spot-total-pill">
                                      👥 {t.totalLabel}: ₹
                                      {slot.totalSlotCost.toLocaleString(
                                        "en-IN"
                                      )}
                                    </span>
                                  </div>
                                </td>
                              </tr>
                            ))}
                          </tbody>
                        </table>
                      </div>
                    </div>
                  ))}
                </div>
              </>
            )}
          </output>
        </section>

        <aside className="cta" aria-labelledby="cta-title">
          <div>
            <p className="small-title">{t.ctaKicker}</p>
            <h2 id="cta-title">{t.ctaTitle}</h2>
          </div>
          <button
            className="primary-btn"
            type="button"
            onClick={() => scrollToSection("planner")}
          >
            {t.ctaBtn}
          </button>
        </aside>
      </main>

      <footer>
        <div>
          <h2>TN {t.appName}</h2>
          <p>{t.footerSub}</p>
        </div>
        <div>
          <p>© 2026 TN Smart Tourist Planner</p>
        </div>
      </footer>
    </>
  );
}

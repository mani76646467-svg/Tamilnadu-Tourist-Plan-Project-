import { Destination, CATEGORY_IMAGES } from "./types";

export const destinationsPart4: Destination[] = [
  {
    name: "Mylapore & San Thome (Chennai)",
    category: "Temple",
    district: "Chennai",
    wikiTitle: "Kapaleeshwarar Temple",
    image: CATEGORY_IMAGES["Temple"],
    description:
      "Chennai's oldest cultural neighborhood featuring the 7th-century Dravidian Kapaleeshwarar Temple, San Thome Cathedral Basilica, and Ramakrishna Math.",
    avgHotelPerPerson: 1300,
    avgFoodPerDay: 500,
    avgTravelCostPerPerson: 350,
    spots: [
      {
        spotName: "Arulmigu Kapaleeshwarar Temple & Mylapore Tank",
        timeSlot: "06:30 AM – 09:00 AM",
        activity:
          "Darshan at the iconic 120-ft sculpted gopuram shrine celebrated in Nayanmar Tevaram hymns",
        entryAndLocalCost: 80,
      },
      {
        spotName: "San Thome Cathedral Basilica & Museum",
        timeSlot: "09:30 AM – 11:30 AM",
        activity:
          "Visit the soaring Neo-Gothic white basilica built over the tomb of St. Thomas the Apostle",
        entryAndLocalCost: 80,
      },
      {
        spotName: "Ramakrishna Math Universal Temple & Luz Church",
        timeSlot: "03:30 PM – 06:00 PM",
        activity:
          "Peaceful meditation hall, heritage library, and Mylapore filter coffee & agraharam walk",
        entryAndLocalCost: 100,
      },
    ],
  },
  {
    name: "Fort St. George & Egmore Museum",
    category: "Heritage",
    district: "Chennai",
    wikiTitle: "Fort St. George, India",
    image: CATEGORY_IMAGES["Heritage"],
    description:
      "Historic 1644 British fortress housing India's oldest Anglican church and the Egmore Government Museum famed for world-class Chola bronze sculptures.",
    avgHotelPerPerson: 1350,
    avgFoodPerDay: 520,
    avgTravelCostPerPerson: 350,
    spots: [
      {
        spotName: "Fort St. George Museum & St. Mary's Church (1680)",
        timeSlot: "09:30 AM – 12:00 PM",
        activity:
          "Explore colonial-era artifacts, coins, portraits, and India's first tricolor flag after independence",
        entryAndLocalCost: 120,
      },
      {
        spotName: "Egmore Government Museum & Chola Bronze Gallery",
        timeSlot: "01:30 PM – 04:00 PM",
        activity:
          "Marvel at the world's finest collection of 10th-century Chola Nataraja bronzes & Indo-Saracenic Art Gallery",
        entryAndLocalCost: 150,
      },
      {
        spotName: "Valluvar Kottam Stone Chariot Monument",
        timeSlot: "04:30 PM – 06:30 PM",
        activity:
          "Monumental Thiruvarur-style stone chariot inscribed with all 1,330 couplets of Thirukkural",
        entryAndLocalCost: 100,
      },
    ],
  },
  {
    name: "Besant Nagar Elliot's Beach & Guindy Park",
    category: "Beach",
    district: "Chennai",
    wikiTitle: "Edward Elliot's Beach",
    image: CATEGORY_IMAGES["Beach"],
    description:
      "Vibrant South Chennai seaside promenade featuring Karl Schmidt Memorial, Ashtalakshmi coastal temple, and Guindy National Park.",
    avgHotelPerPerson: 1300,
    avgFoodPerDay: 500,
    avgTravelCostPerPerson: 350,
    spots: [
      {
        spotName: "Guindy National Park & Children's Nature Park",
        timeSlot: "08:30 AM – 11:30 AM",
        activity:
          "One of India's smallest national parks inside a city, home to blackbucks, spotted deer & snake park",
        entryAndLocalCost: 150,
      },
      {
        spotName: "Ashtalakshmi Coastal Temple & Annai Velankanni Shrine",
        timeSlot: "03:30 PM – 05:00 PM",
        activity:
          "Multi-tiered seaside temple dedicated to the eight forms of Goddess Lakshmi overlooking the waves",
        entryAndLocalCost: 80,
      },
      {
        spotName: "Besant Nagar Elliot's Beach & Karl Schmidt Memorial",
        timeSlot: "05:00 PM – 07:00 PM",
        activity:
          "Evening sea breeze stroll along the clean sandy shore and heritage Dutch sailor memorial",
        entryAndLocalCost: 100,
      },
    ],
  },
  {
    name: "Vandalur Zoo (Arignar Anna Zoological Park)",
    category: "Nature & Waterfalls",
    district: "Chengalpattu",
    wikiTitle: "Arignar Anna Zoological Park",
    image: CATEGORY_IMAGES["Nature & Waterfalls"],
    description:
      "One of South Asia's largest zoological gardens spanning 1,490 acres with lion and deer safaris, nocturnal animal house, and butterfly conservatory.",
    avgHotelPerPerson: 1100,
    avgFoodPerDay: 460,
    avgTravelCostPerPerson: 380,
    spots: [
      {
        spotName: "Vandalur Lion Safari & Battery Vehicle Zoo Tour",
        timeSlot: "09:00 AM – 01:00 PM",
        activity:
          "See white tigers, Asiatic lions, elephants, giraffes & chimpanzees in naturalistic forest enclosures",
        entryAndLocalCost: 250,
      },
      {
        spotName: "Walk-Through Aviary, Butterfly Park & Nocturnal House",
        timeSlot: "01:30 PM – 03:30 PM",
        activity:
          "Explore tropical birds, reptile gardens, and interactive biodiversity interpretation center",
        entryAndLocalCost: 120,
      },
      {
        spotName: "Thiruporur Kandaswamy Murugan Temple",
        timeSlot: "04:30 PM – 06:30 PM",
        activity:
          "Ancient Pallava-era Murugan temple with swayambu palm-stem deity and large Saravana Poigai tank",
        entryAndLocalCost: 100,
      },
    ],
  },
  {
    name: "Thiruparappu Falls & Mathur Aqueduct",
    category: "Nature & Waterfalls",
    district: "Kanyakumari",
    wikiTitle: "Thirparappu",
    image: CATEGORY_IMAGES["Nature & Waterfalls"],
    description:
      "Lush Kanyakumari green belt featuring the 50-foot cascading Thiruparappu Waterfalls, Pechiparai Reservoir, and Asia's tallest Mathur Hanging Trough Bridge.",
    avgHotelPerPerson: 1100,
    avgFoodPerDay: 460,
    avgTravelCostPerPerson: 780,
    spots: [
      {
        spotName: "Thiruparappu Waterfalls & Mahadevar Temple",
        timeSlot: "08:00 AM – 11:00 AM",
        activity:
          "Enjoy a refreshing bath in the Kodayar River waterfall, pedal boating & 9th-century Shiva shrine",
        entryAndLocalCost: 140,
      },
      {
        spotName: "Mathur Aqueduct (Hanging Trough Bridge)",
        timeSlot: "11:30 AM – 01:30 PM",
        activity:
          "Walk across the 115-foot-high, 1-km-long engineering marvel above the Pahrali River & rubber estates",
        entryAndLocalCost: 80,
      },
      {
        spotName: "Pechiparai Dam & Western Ghats Reservoir",
        timeSlot: "03:00 PM – 05:30 PM",
        activity:
          "Scenic reservoir built at the foothills of the Kodayar hills surrounded by dense tropical forest",
        entryAndLocalCost: 100,
      },
    ],
  },
  {
    name: "Padmanabhapuram Palace & Udayagiri Fort",
    category: "Heritage",
    district: "Kanyakumari",
    wikiTitle: "Padmanabhapuram Palace",
    image: CATEGORY_IMAGES["Heritage"],
    description:
      "Asia's largest wooden palace complex built in 1601 with intricate rosewood carvings and Belgian mirrors, paired with historic Udayagiri Fort.",
    avgHotelPerPerson: 1150,
    avgFoodPerDay: 470,
    avgTravelCostPerPerson: 780,
    spots: [
      {
        spotName: "Padmanabhapuram Wooden Royal Palace Complex",
        timeSlot: "09:00 AM – 12:00 PM",
        activity:
          "Marvel at the Mantrasala council chamber, gleaming black polished floors, clock tower & murals",
        entryAndLocalCost: 150,
      },
      {
        spotName: "Udayagiri Fort & Biodiversity Park",
        timeSlot: "01:30 PM – 03:30 PM",
        activity:
          "18th-century granite fort where Eustachius De Lannoy cast cannons, now a shaded deer & bird park",
        entryAndLocalCost: 100,
      },
      {
        spotName: "Thiruvattar Adikesava Perumal Temple",
        timeSlot: "04:00 PM – 06:30 PM",
        activity:
          "Ancient Divya Desam temple surrounded by three rivers with a 22-foot reclining Lord Vishnu idol",
        entryAndLocalCost: 100,
      },
    ],
  },
  {
    name: "Vattakottai Fort & Muttom Beach",
    category: "Beach",
    district: "Kanyakumari",
    wikiTitle: "Vattakottai Fort",
    image: CATEGORY_IMAGES["Beach"],
    description:
      "18th-century coastal granite fortress overlooking both the Bay of Bengal and Western Ghats, alongside the dramatic boulder cliffs of Muttom Beach.",
    avgHotelPerPerson: 1150,
    avgFoodPerDay: 460,
    avgTravelCostPerPerson: 780,
    spots: [
      {
        spotName: "Vattakottai Seaside Granite Fort & Black Sand Beach",
        timeSlot: "08:00 AM – 10:30 AM",
        activity:
          "Walk atop the circular coastal fort ramparts where ocean waves meet the Western Ghats backdrop",
        entryAndLocalCost: 80,
      },
      {
        spotName: "Chothavilai & Sanguthurai Beaches",
        timeSlot: "11:00 AM – 01:00 PM",
        activity:
          "Relax along one of Kanyakumari district's longest white-sand coastal stretches and giant conch monument",
        entryAndLocalCost: 80,
      },
      {
        spotName: "Muttom Rock Cliffs & 100-Year-Old Lighthouse Sunset",
        timeSlot: "03:30 PM – 06:30 PM",
        activity:
          "Spectacular Arabian Sea sunset over wave-sculpted granite boulders and historic colonial lighthouse",
        entryAndLocalCost: 100,
      },
    ],
  },
  {
    name: "Suchindram & Nagercoil Temples",
    category: "Temple",
    district: "Kanyakumari",
    wikiTitle: "Thanumalayan Temple",
    image: CATEGORY_IMAGES["Temple"],
    description:
      "Architectural marvel dedicated to the Trinity (Shiva, Vishnu, Brahma) featuring four musical stone pillars and a 22-foot monolithic Hanuman statue.",
    avgHotelPerPerson: 1100,
    avgFoodPerDay: 450,
    avgTravelCostPerPerson: 760,
    spots: [
      {
        spotName: "Suchindram Thanumalayan Temple & Musical Pillars",
        timeSlot: "06:30 AM – 09:30 AM",
        activity:
          "Experience the 18-foot musical granite pillars, Alankara Mandapam & 22-ft single-stone Anjaneyar",
        entryAndLocalCost: 100,
      },
      {
        spotName: "Nagercoil Nagaraja Temple",
        timeSlot: "10:00 AM – 12:00 PM",
        activity:
          "Historic temple that gave Nagercoil its name, featuring sacred sand prasadam and Jain carvings",
        entryAndLocalCost: 80,
      },
      {
        spotName: "Kanyakumari Eco Park & Tsunami Memorial Shore",
        timeSlot: "03:30 PM – 06:00 PM",
        activity:
          "Botanical garden walk, bamboo groves, and coastal sunset view near Cape Comorin",
        entryAndLocalCost: 120,
      },
    ],
  },
  {
    name: "Papanasam & Agasthiyar Falls",
    category: "Nature & Waterfalls",
    district: "Tirunelveli",
    wikiTitle: "Agasthiyar Falls",
    image: CATEGORY_IMAGES["Nature & Waterfalls"],
    description:
      "Sacred foothills where the perennial Thamirabarani River plunges down Agasthiyar Falls inside the Kalakkad Mundanthurai Tiger Reserve.",
    avgHotelPerPerson: 1000,
    avgFoodPerDay: 440,
    avgTravelCostPerPerson: 700,
    spots: [
      {
        spotName: "Agasthiyar Falls (Papanasam Perennial Waterfall)",
        timeSlot: "07:30 AM – 10:30 AM",
        activity:
          "Year-round herbal waterfall bath where Sage Agasthiyar received the cosmic wedding vision of Shiva",
        entryAndLocalCost: 100,
      },
      {
        spotName: "Papanasanathar & Ulagammai Temple (Kailasa Kshetram)",
        timeSlot: "10:45 AM – 12:30 PM",
        activity:
          "Ancient riverside Shiva temple on the banks of the fish-filled Thamirabarani ghats",
        entryAndLocalCost: 80,
      },
      {
        spotName: "Karaiyar Dam (Papanasam Upper Dam) & Servalar Reservoir",
        timeSlot: "02:30 PM – 05:30 PM",
        activity:
          "Forest drive through Mundanthurai Tiger Reserve to the scenic mountain dam between two hills",
        entryAndLocalCost: 150,
      },
    ],
  },
  {
    name: "Manapad Beach & Nava Tirupati",
    category: "Beach",
    district: "Thoothukudi",
    wikiTitle: "Manapad",
    image: CATEGORY_IMAGES["Beach"],
    description:
      "Dramatic headland peninsula on the Gulf of Mannar where waves crash on three sides, famous for its clifftop Holy Cross Church, surfing lagoon, and Nava Tirupati.",
    avgHotelPerPerson: 1000,
    avgFoodPerDay: 440,
    avgTravelCostPerPerson: 700,
    spots: [
      {
        spotName: "Manapad Cliff Holy Cross Church (1581) & Lighthouse",
        timeSlot: "07:30 AM – 10:00 AM",
        activity:
          "Walk up the golden sand cliff overlooking the turquoise surfing bay and St. Francis Xavier's cave",
        entryAndLocalCost: 80,
      },
      {
        spotName: "Kulasekarapattinam Mutharamman Temple & Beach",
        timeSlot: "10:30 AM – 12:30 PM",
        activity:
          "Coastal town famous for India's grandest coastal Dasara festival and palm-lined beach",
        entryAndLocalCost: 80,
      },
      {
        spotName: "Alwarthirunagari & Srivaikuntam (Nava Tirupati Temples)",
        timeSlot: "03:00 PM – 06:00 PM",
        activity:
          "Visit the birthplace of Nammalvar with its ancient tamarind tree and sculpted Nayak mandapams",
        entryAndLocalCost: 120,
      },
    ],
  },
  {
    name: "Kazhugumalai (Vettuvan Koil)",
    category: "Heritage",
    district: "Thoothukudi",
    wikiTitle: "Kalugumalai Jain Beds",
    image: CATEGORY_IMAGES["Heritage"],
    description:
      "Known as the 'Ellora of South India', featuring the 8th-century Pandya monolithic Vettuvan Koil carved top-down from a single granite hill and Jain rock reliefs.",
    avgHotelPerPerson: 900,
    avgFoodPerDay: 400,
    avgTravelCostPerPerson: 640,
    spots: [
      {
        spotName: "Vettuvan Koil (8th-Century Pandya Monolithic Temple)",
        timeSlot: "08:00 AM – 10:30 AM",
        activity:
          "Marvel at the unfinished Shiva temple carved out of solid granite rock with intricate ganas & sculptures",
        entryAndLocalCost: 80,
      },
      {
        spotName: "Kalugumalai Jain Rock-Cut Reliefs & Inscriptions",
        timeSlot: "10:45 AM – 12:30 PM",
        activity:
          "Over 150 intricately carved Tirthankara bas-reliefs and Vatteluttu inscriptions on the hill face",
        entryAndLocalCost: 60,
      },
      {
        spotName: "Kazhugachalamoorthy Rock-Cut Cave Murugan Temple",
        timeSlot: "03:30 PM – 06:00 PM",
        activity:
          "Foothill cave shrine where Lord Murugan faces southwest alongside peacock and sacred tank",
        entryAndLocalCost: 80,
      },
    ],
  },
  {
    name: "Panchalankurichi & Ettayapuram",
    category: "Heritage",
    district: "Thoothukudi",
    wikiTitle: "Panchalankurichi",
    image: CATEGORY_IMAGES["Heritage"],
    description:
      "Patriotic heritage circuit honoring freedom fighter Veerapandiya Kattabomman's fort, Mahakavi Subramania Bharathiyar's birthplace, and V.O. Chidambaram Pillai.",
    avgHotelPerPerson: 950,
    avgFoodPerDay: 420,
    avgTravelCostPerPerson: 650,
    spots: [
      {
        spotName: "Panchalankurichi Veerapandiya Kattabomman Memorial Fort",
        timeSlot: "09:00 AM – 11:30 AM",
        activity:
          "Tour the reconstructed fort gallery depicting Kattabomman's heroic resistance and Jakkammal Devi shrine",
        entryAndLocalCost: 80,
      },
      {
        spotName: "Ettayapuram Mahakavi Bharathiyar Illam & Palace",
        timeSlot: "12:00 PM – 02:00 PM",
        activity:
          "Visit the ancestral house of Tamil poet Subramania Bharathi, Ettayapuram Zamin Palace & Umaru Pulavar Dargah",
        entryAndLocalCost: 80,
      },
      {
        spotName: "Ottapidaram V.O. Chidambaram Pillai Memorial & Kayathar",
        timeSlot: "03:30 PM – 05:30 PM",
        activity:
          "Explore the birthplace of 'Kappalottiya Tamizhan' V.O.C. and historic freedom struggle exhibits",
        entryAndLocalCost: 80,
      },
    ],
  },
  {
    name: "Sankarankovil (Sankaranayinarkoil)",
    category: "Temple",
    district: "Tenkasi",
    wikiTitle: "Sankaranayinarkoil",
    image: CATEGORY_IMAGES["Temple"],
    description:
      "Famous 11th-century Ukkira Pandya temple enshrining Harihara (Sankaranarayanar — half Shiva, half Vishnu) and Goddess Gomathi Amman.",
    avgHotelPerPerson: 900,
    avgFoodPerDay: 410,
    avgTravelCostPerPerson: 650,
    spots: [
      {
        spotName: "Arulmigu Sankaranarayanar & Gomathi Amman Temple",
        timeSlot: "06:30 AM – 09:30 AM",
        activity:
          "Darshan of the unique Harihara deity uniting Shaivism & Vaishnavism and the sacred Naga Sunai tank",
        entryAndLocalCost: 100,
      },
      {
        spotName: "Karivalamvandanallur Palvannanathar Temple",
        timeSlot: "10:15 AM – 12:15 PM",
        activity:
          "Ancient Pandya-era Pancha Sthalam temple on the route toward Tenkasi",
        entryAndLocalCost: 80,
      },
      {
        spotName: "Gundar Dam & Western Ghats Foothills (Sengottai)",
        timeSlot: "03:30 PM – 06:00 PM",
        activity:
          "Scenic mountain reservoir surrounded by spice hills and seasonal cascades",
        entryAndLocalCost: 100,
      },
    ],
  },
  {
    name: "Tenkasi Kasi Viswanathar & Old Courtallam",
    category: "Temple",
    district: "Tenkasi",
    wikiTitle: "Kasi Viswanathar temple, Tenkasi",
    image: CATEGORY_IMAGES["Temple"],
    description:
      "15th-century Pandya royal temple crowned by a 180-foot Rajagopuram with life-size sculpted stone pillars, right beside Old Courtallam waterfalls.",
    avgHotelPerPerson: 1050,
    avgFoodPerDay: 450,
    avgTravelCostPerPerson: 660,
    spots: [
      {
        spotName: "Tenkasi Kasi Viswanathar Temple & Sculpted Mandapam",
        timeSlot: "07:00 AM – 09:30 AM",
        activity:
          "Admire the wind-channeling entrance gopuram and exquisite Nayak-Pandya monolithic statues",
        entryAndLocalCost: 80,
      },
      {
        spotName: "Old Courtallam (Pazhaya Courtallam) Waterfalls",
        timeSlot: "10:00 AM – 01:00 PM",
        activity:
          "200-foot stepped rock waterfall fed by the Chittar River with safe bathing pools",
        entryAndLocalCost: 100,
      },
      {
        spotName: "Thirumalapuram Rock-Cut Cave Temple & Eco Park",
        timeSlot: "03:30 PM – 06:00 PM",
        activity:
          "Early Pandya rock-cut cave temple with ancient frescoes and landscaped Courtallam Eco Park",
        entryAndLocalCost: 120,
      },
    ],
  },
  {
    name: "Thirumayam Fort & Avudaiyarkoil",
    category: "Heritage",
    district: "Pudukkottai",
    wikiTitle: "Thirumayam Fort",
    image: CATEGORY_IMAGES["Heritage"],
    description:
      "40-acre 17th-century ring fortress built by Sethupathi Raja over 8th-century rock-cut Shiva and Vishnu cave temples, paired with Avudaiyarkoil.",
    avgHotelPerPerson: 950,
    avgFoodPerDay: 430,
    avgTravelCostPerPerson: 560,
    spots: [
      {
        spotName: "Thirumayam Hill Fort & cannons",
        timeSlot: "08:00 AM – 10:30 AM",
        activity:
          "Climb to the concentric granite fort bastions, rock moat, and British-era cannon emplacements",
        entryAndLocalCost: 100,
      },
      {
        spotName: "Sathyagiriswarar & Sathyamoorthy Perumal Rock-Cut Temples",
        timeSlot: "10:45 AM – 12:30 PM",
        activity:
          "Twin 8th-century Pallava-Pandya cave shrines carved into the base of Thirumayam Fort rock",
        entryAndLocalCost: 80,
      },
      {
        spotName: "Avudaiyarkoil Athmanathaswamy Temple (Zephyr Stone Roof)",
        timeSlot: "03:00 PM – 06:00 PM",
        activity:
          "Masterpiece of Tamil stone architecture where Saint Manickavasagar built the paper-thin granite roof eaves",
        entryAndLocalCost: 120,
      },
    ],
  },
  {
    name: "Viralimalai Peacock Sanctuary & Kodumbalur",
    category: "Temple",
    district: "Pudukkottai",
    wikiTitle: "Viralimalai Murugan temple",
    image: CATEGORY_IMAGES["Temple"],
    description:
      "Rocky hillock shrine of Lord Shanmuganathar surrounded by hundreds of wild peacocks, near the 9th-century early Chola temples of Kodumbalur.",
    avgHotelPerPerson: 950,
    avgFoodPerDay: 420,
    avgTravelCostPerPerson: 540,
    spots: [
      {
        spotName: "Viralimalai Shanmuganathar Hill Temple & Peacock Sanctuary",
        timeSlot: "07:00 AM – 10:00 AM",
        activity:
          "Climb 207 stone steps shaded by floral trees as wild peacocks dance around the hillock",
        entryAndLocalCost: 80,
      },
      {
        spotName: "Kodumbalur Moovar Koil (Early Chola Stone Temples)",
        timeSlot: "10:30 AM – 12:30 PM",
        activity:
          "Explore the 9th-century Irukkuvel-Chola structural stone temples and Muchukundeswarar shrine",
        entryAndLocalCost: 80,
      },
      {
        spotName: "Malaiyadipatti Rock-Cut Cave Temples",
        timeSlot: "03:30 PM – 05:30 PM",
        activity:
          "Ancient Mutharaiyar-Pallava rock-cut Shiva and Ranganatha cave temples with painted reliefs",
        entryAndLocalCost: 80,
      },
    ],
  },
  {
    name: "Bhavanisagar Dam & Kodiveri Falls",
    category: "Nature & Waterfalls",
    district: "Erode",
    wikiTitle: "Bhavanisagar Dam",
    image: CATEGORY_IMAGES["Nature & Waterfalls"],
    description:
      "One of the world's largest earthen dams built across the Bhavani River paired with the curtain-like Kodiveri Weir waterfalls and coracle rides.",
    avgHotelPerPerson: 1050,
    avgFoodPerDay: 450,
    avgTravelCostPerPerson: 580,
    spots: [
      {
        spotName: "Kodiveri Dam Waterfalls & Bhavani River Coracle Ride",
        timeSlot: "08:00 AM – 11:00 AM",
        activity:
          "Safe family bathing under the wide stone-check-dam waterfall and traditional round parisal boat ride",
        entryAndLocalCost: 160,
      },
      {
        spotName: "Bhavanisagar Dam & Jubilee Park",
        timeSlot: "11:45 AM – 02:00 PM",
        activity:
          "Walk through the 8-km earthen dam gardens at the confluence of Bhavani and Moyar rivers",
        entryAndLocalCost: 100,
      },
      {
        spotName: "Bannari Mariamman Temple (Sathyamangalam Foothills)",
        timeSlot: "03:30 PM – 06:00 PM",
        activity:
          "Revered forest-edge Amman temple at the base of the Sathyamangalam ghats",
        entryAndLocalCost: 100,
      },
    ],
  },
  {
    name: "Sathyamangalam Tiger Reserve & Dhimbam",
    category: "Nature & Waterfalls",
    district: "Erode",
    wikiTitle: "Sathyamangalam Tiger Reserve",
    image: CATEGORY_IMAGES["Nature & Waterfalls"],
    description:
      "Critical wildlife corridor linking the Western and Eastern Ghats, famous for the thrilling 27-hairpin Dhimbam ghat drive, elephants, and Hasanur forests.",
    avgHotelPerPerson: 1200,
    avgFoodPerDay: 480,
    avgTravelCostPerPerson: 620,
    spots: [
      {
        spotName: "Dhimbam 27 Hairpin Bends & Valley Viewpoint",
        timeSlot: "07:30 AM – 10:00 AM",
        activity:
          "Scenic mountain ghat drive with sweeping views of Bhavanisagar reservoir and Moyar valley",
        entryAndLocalCost: 100,
      },
      {
        spotName: "Hasanur Eco-Tourism Center & Jungle Safari",
        timeSlot: "10:30 AM – 01:30 PM",
        activity:
          "Forest department safari spotting elephants, gaur, sambar deer & Nilgiri birds",
        entryAndLocalCost: 250,
      },
      {
        spotName: "Thalamalai Reserve Forest Plateau View",
        timeSlot: "03:00 PM – 05:30 PM",
        activity:
          "Cool high-altitude forest plateau drive and ancient Thalamalai Perumal temple",
        entryAndLocalCost: 120,
      },
    ],
  },
  {
    name: "Chennimalai & Vellode Bird Sanctuary",
    category: "Temple",
    district: "Erode",
    wikiTitle: "Vellode Bird Sanctuary",
    image: CATEGORY_IMAGES["Temple"],
    description:
      "Kongu Nadu heritage route combining the hilltop Chennimalai Murugan Temple, handloom weaving center, and the Ramsar-listed Vellode Bird Sanctuary.",
    avgHotelPerPerson: 1000,
    avgFoodPerDay: 440,
    avgTravelCostPerPerson: 560,
    spots: [
      {
        spotName: "Chennimalai Subramanya Swamy Hill Temple (1,320 Steps)",
        timeSlot: "07:00 AM – 10:00 AM",
        activity:
          "Ascend by ghat road or steps to the historic hill temple where Kanda Sashti Kavacham was first sung",
        entryAndLocalCost: 100,
      },
      {
        spotName: "Vellode Bird Sanctuary (Perundurai Lake)",
        timeSlot: "10:30 AM – 12:30 PM",
        activity:
          "Ramsar wetland sanctuary hosting painted storks, pelicans, teal & darter birds",
        entryAndLocalCost: 100,
      },
      {
        spotName: "Kodumudi Magudeswarar Temple (Cauvery River Bank)",
        timeSlot: "03:30 PM – 06:00 PM",
        activity:
          "Rare Trimurti temple enshrining Shiva, Vishnu (Veeranarayana Perumal) & Brahma on the Cauvery bank",
        entryAndLocalCost: 100,
      },
    ],
  },
  {
    name: "Mettur Dam & Taramangalam (Salem)",
    category: "Nature & Waterfalls",
    district: "Salem",
    wikiTitle: "Mettur Dam",
    image: CATEGORY_IMAGES["Nature & Waterfalls"],
    description:
      "One of India's largest and oldest stone masonry dams across the Cauvery River (Stanley Reservoir), paired with Taramangalam's intricate stone sculptures.",
    avgHotelPerPerson: 1000,
    avgFoodPerDay: 440,
    avgTravelCostPerPerson: 520,
    spots: [
      {
        spotName: "Mettur Dam (Stanley Reservoir) & Ellis Park",
        timeSlot: "08:30 AM – 11:30 AM",
        activity:
          "View the 1,700-meter-long dam across the Cauvery gorge, Muniappan statue & landscaped Ellis Park",
        entryAndLocalCost: 100,
      },
      {
        spotName: "Taramangalam Kailasanathar Temple (Stone Chain & Yali Marvel)",
        timeSlot: "12:15 PM – 02:15 PM",
        activity:
          "Marvel at rotating stone lotus rings, stone chains & Rati-Manmatha sculptures",
        entryAndLocalCost: 80,
      },
      {
        spotName: "Kurumbapatti Zoological Park (Shevaroy Foothills)",
        timeSlot: "03:30 PM – 05:45 PM",
        activity:
          "Shaded foothills nature park at the base of Yercaud hills with deer, peacocks & bamboo trails",
        entryAndLocalCost: 100,
      },
    ],
  },
  {
    name: "Tiruchengode Ardhanareeswarar Hill",
    category: "Temple",
    district: "Namakkal",
    wikiTitle: "Ardhanareeswarar temple, Tiruchengode",
    image: CATEGORY_IMAGES["Temple"],
    description:
      "Ancient red-rock hill shrine (Nagagiri) with 1,200 carved steps and a 60-foot stone serpent, enshrining the half-male, half-female Ardhanareeswarar form of Shiva.",
    avgHotelPerPerson: 950,
    avgFoodPerDay: 430,
    avgTravelCostPerPerson: 540,
    spots: [
      {
        spotName: "Tiruchengode Ardhanareeswarar & Sengottuvelavar Hill Temple",
        timeSlot: "07:00 AM – 10:30 AM",
        activity:
          "Drive or climb the 650-foot red hill past the giant 60-ft carved five-headed Naga sculpture",
        entryAndLocalCost: 100,
      },
      {
        spotName: "Kailasanathar Town Temple (Tiruchengode Foothills)",
        timeSlot: "11:00 AM – 12:30 PM",
        activity:
          "Historic Chola-Nayak temple in the heart of Tiruchengode with sculpted mandapams",
        entryAndLocalCost: 80,
      },
      {
        spotName: "Jedarpalayam Dam & Cauvery River Park",
        timeSlot: "03:30 PM – 06:00 PM",
        activity:
          "Peaceful barrage across the Cauvery River with children's park and coracle boating",
        entryAndLocalCost: 120,
      },
    ],
  },
  {
    name: "Bhavani Kooduthurai & Uratchikottai",
    category: "Temple",
    district: "Erode",
    wikiTitle: "Sangameswarar Temple, Bhavani",
    image: CATEGORY_IMAGES["Temple"],
    description:
      "Known as the 'Triveni Sangam of the South' where the Cauvery, Bhavani, and mystic Amudha rivers unite around the island shrine of Sangameswarar.",
    avgHotelPerPerson: 950,
    avgFoodPerDay: 430,
    avgTravelCostPerPerson: 550,
    spots: [
      {
        spotName: "Bhavani Sangameswarar Temple & Kooduthurai River Confluence",
        timeSlot: "06:30 AM – 09:30 AM",
        activity:
          "Sacred bath and darshan at the confluence of Cauvery and Bhavani rivers",
        entryAndLocalCost: 80,
      },
      {
        spotName: "Uratchikottai Vedagiri Hill Bala Dhandayuthapani Temple",
        timeSlot: "10:15 AM – 12:30 PM",
        activity:
          "Hilltop Murugan shrine offering 360-degree views of both the Cauvery and Bhavani river valleys",
        entryAndLocalCost: 90,
      },
      {
        spotName: "Bhavani Jamakkalam Handloom Weaving Street",
        timeSlot: "03:30 PM – 05:30 PM",
        activity:
          "Explore GI-tagged colorful Bhavani Jamakkalam carpet weaving workshops",
        entryAndLocalCost: 120,
      },
    ],
  },
  {
    name: "Sathanur Dam & Tirukoilur",
    category: "Nature & Waterfalls",
    district: "Tiruvannamalai",
    wikiTitle: "Sathanur Dam",
    image: CATEGORY_IMAGES["Nature & Waterfalls"],
    description:
      "Major dam across the Thenpennai River nestled in the Chennakesava Hills, famous for its terraced cinema gardens, crocodile farm, and nearby Tirukoilur.",
    avgHotelPerPerson: 950,
    avgFoodPerDay: 420,
    avgTravelCostPerPerson: 480,
    spots: [
      {
        spotName: "Sathanur Dam Ornamental Gardens & Crocodile Park",
        timeSlot: "08:30 AM – 11:30 AM",
        activity:
          "Stroll through manicured gardens, statues, swimming pool park & mugger crocodile enclosure",
        entryAndLocalCost: 120,
      },
      {
        spotName: "Tirukoilur Ulagalantha Perumal Temple (192-ft Gopuram)",
        timeSlot: "12:15 PM – 02:00 PM",
        activity:
          "Ancient Divya Desam where the First Three Alwars met and composed the earliest Prabandham hymns",
        entryAndLocalCost: 100,
      },
      {
        spotName: "Kabilar Kundru Rock Island (Thenpennai River)",
        timeSlot: "03:30 PM – 05:30 PM",
        activity:
          "Historic Sangam-era rock monument in the middle of the Ponnaiyar River honoring poet Kabilar",
        entryAndLocalCost: 80,
      },
    ],
  },
  {
    name: "Amirthi Zoo & Jalagamparai Falls",
    category: "Nature & Waterfalls",
    district: "Vellore",
    wikiTitle: "Amirthi Zoological Park",
    image: CATEGORY_IMAGES["Nature & Waterfalls"],
    description:
      "Lush Javadi Hills foothills nature circuit featuring the Amirthi River waterfall and mini zoo alongside the scenic Jalagamparai Waterfalls near Tirupattur.",
    avgHotelPerPerson: 1000,
    avgFoodPerDay: 430,
    avgTravelCostPerPerson: 480,
    spots: [
      {
        spotName: "Amirthi Zoological Park & Forest Waterfall",
        timeSlot: "08:30 AM – 11:30 AM",
        activity:
          "Trek 1 km along the forest stream to the seasonal waterfall and visit spotted deer & bird enclosures",
        entryAndLocalCost: 120,
      },
      {
        spotName: "Virinchipuram Margabandeeswarar Temple (Simha Theertham)",
        timeSlot: "12:15 PM – 02:00 PM",
        activity:
          "Chola-Vijayanagara architectural gem famous for its Time-Indicating Stone Sundial and Nandi",
        entryAndLocalCost: 80,
      },
      {
        spotName: "Jalagamparai Waterfalls & Eswaran Koil (Yelagiri Foothills)",
        timeSlot: "03:30 PM – 06:00 PM",
        activity:
          "Attaru River cascading down the outer slopes of Yelagiri Hills with a Lingam-shaped temple",
        entryAndLocalCost: 100,
      },
    ],
  },
  {
    name: "Krishnagiri Dam & Rayakottai Fort",
    category: "Heritage",
    district: "Krishnagiri",
    wikiTitle: "Krishnagiri Dam",
    image: CATEGORY_IMAGES["Heritage"],
    description:
      "Land of monolithic hill forts (Baramahal) featuring the scenic KRP Dam gardens across the Thenpennai River, Krishnagiri Fort, and Rayakottai Fort.",
    avgHotelPerPerson: 1000,
    avgFoodPerDay: 440,
    avgTravelCostPerPerson: 520,
    spots: [
      {
        spotName: "Krishnagiri Reservoir Project (KRP Dam) & Rose Park",
        timeSlot: "08:30 AM – 11:00 AM",
        activity:
          "Relax in the illuminated fountains, deer park, and lakeside gardens below the granite hills",
        entryAndLocalCost: 100,
      },
      {
        spotName: "Krishnagiri Hill Fort & Syed Basha Mountains",
        timeSlot: "11:30 AM – 01:30 PM",
        activity:
          "Explore the historic Baramahal fortress built by Vijayanagara rulers and Tipu Sultan",
        entryAndLocalCost: 80,
      },
      {
        spotName: "Rayakottai Monolithic Hill Fort Viewpoint",
        timeSlot: "03:30 PM – 06:00 PM",
        activity:
          "Scenic evening hike up the granite steps of Rayakottai Fort for sunset views across the plateau",
        entryAndLocalCost: 100,
      },
    ],
  },
  {
    name: "Keeladi Heritage Museum & Thirupuvanam",
    category: "Heritage",
    district: "Sivaganga",
    wikiTitle: "Keezhadi",
    image: CATEGORY_IMAGES["Heritage"],
    description:
      "World-renowned Vaigai River civilization site showcasing 2,600-year-old Sangam-era urban artifacts in the Chettinad-style Keeladi Museum.",
    avgHotelPerPerson: 1050,
    avgFoodPerDay: 460,
    avgTravelCostPerPerson: 600,
    spots: [
      {
        spotName: "Keeladi Heritage Museum (Sangam Era Archaeological Gallery)",
        timeSlot: "09:00 AM – 12:00 PM",
        activity:
          "Explore 6th-century BCE Tamil-Brahmi pottery, carnelian beads, ring wells, dice & weaving spindles",
        entryAndLocalCost: 100,
      },
      {
        spotName: "Keeladi Open-Air Excavation Trench & Konthagai Site",
        timeSlot: "12:15 PM – 01:45 PM",
        activity:
          "View the actual brick structures and terracotta water pipelines unearthed along the Vaigai valley",
        entryAndLocalCost: 80,
      },
      {
        spotName: "Thirupuvanam Pushpavananathar Temple & Silk Handlooms",
        timeSlot: "03:30 PM – 06:00 PM",
        activity:
          "Ancient Paadal Petra Sthalam on the Vaigai bank and famous Thirupuvanam pure silk saree weavers",
        entryAndLocalCost: 100,
      },
    ],
  },
  {
    name: "Sikkal, Nagore & Ettukudi",
    category: "Temple",
    district: "Nagapattinam",
    wikiTitle: "Nagore Dargah",
    image: CATEGORY_IMAGES["Temple"],
    description:
      "Harmonious coastal pilgrimage circuit featuring Sikkal Singaravelavar Temple, the 500-year-old Nagore Dargah with five minarets, and Ettukudi Murugan.",
    avgHotelPerPerson: 950,
    avgFoodPerDay: 430,
    avgTravelCostPerPerson: 580,
    spots: [
      {
        spotName: "Sikkal Navaneetheswarar & Singaravelavar Temple",
        timeSlot: "07:00 AM – 09:30 AM",
        activity:
          "Sacred Kanda Sashti shrine where Lord Murugan received the Vel spear from Goddess Parvati",
        entryAndLocalCost: 80,
      },
      {
        spotName: "Historic Nagore Dargah & 131-ft Sahib Minara",
        timeSlot: "10:15 AM – 12:15 PM",
        activity:
          "Visit the 16th-century shrine of Shahul Hamid revered by people of all faiths and its silver doors",
        entryAndLocalCost: 80,
      },
      {
        spotName: "Ettukudi Subramanya Swamy Temple",
        timeSlot: "03:30 PM – 06:00 PM",
        activity:
          "Admire the masterpiece monolithic stone peacock where the entire statue rests solely on the bird's legs",
        entryAndLocalCost: 100,
      },
    ],
  },
  {
    name: "Mannargudi, Tiruvarur & Vaduvur",
    category: "Temple",
    district: "Tiruvarur",
    wikiTitle: "Rajagopalaswamy Temple, Mannargudi",
    image: CATEGORY_IMAGES["Temple"],
    description:
      "Heart of the Chola delta featuring Mannargudi Rajagopalaswamy Temple (Dakshina Dwarka with its 23-acre tank), Tiruvarur Thyagaraja Temple, and Vaduvur Sanctuary.",
    avgHotelPerPerson: 950,
    avgFoodPerDay: 430,
    avgTravelCostPerPerson: 560,
    spots: [
      {
        spotName: "Mannargudi Rajagopalaswamy Temple & Haridra Nadhi Tank",
        timeSlot: "07:00 AM – 09:45 AM",
        activity:
          "Explore 'Dakshina Dwarka' and India's largest 23-acre temple tank (1,158 ft × 837 ft)",
        entryAndLocalCost: 100,
      },
      {
        spotName: "Vaduvur Bird Sanctuary & Kothandaramaswamy Temple",
        timeSlot: "10:30 AM – 12:30 PM",
        activity:
          "Spot migratory waterbirds around the lush Vaduvur tank and visit the famous Rama shrine",
        entryAndLocalCost: 100,
      },
      {
        spotName: "Tiruvarur Thyagaraja Swamy Temple, Kamalalayam & Aziya Ther",
        timeSlot: "03:30 PM – 06:30 PM",
        activity:
          "Birthplace of the Carnatic Music Trinity, 30-acre Kamalalayam tank & Asia's largest temple chariot",
        entryAndLocalCost: 100,
      },
    ],
  },
  {
    name: "Thirunageswaram, Uppiliappan & Alangudi",
    category: "Temple",
    district: "Tiruvarur",
    wikiTitle: "Thirunageswaram",
    image: CATEGORY_IMAGES["Temple"],
    description:
      "Revered Navagraha and Divya Desam temple circuit near Kumbakonam-Tiruvarur featuring Thirunageswaram (Rahu), Uppiliappan Koil, and Alangudi (Guru).",
    avgHotelPerPerson: 1000,
    avgFoodPerDay: 440,
    avgTravelCostPerPerson: 560,
    spots: [
      {
        spotName: "Thirunageswaram Naganathaswamy (Rahu Navagraha) Temple",
        timeSlot: "07:00 AM – 09:30 AM",
        activity:
          "Famous Rahu Sthalam known for the miracle of milk turning blue during Paal Abhishekam",
        entryAndLocalCost: 100,
      },
      {
        spotName: "Oppiliappan (Uppiliappan) Venkatachalapathy Perumal Temple",
        timeSlot: "10:00 AM – 12:15 PM",
        activity:
          "Ancient Divya Desam known as South Tirupati where all temple prasadam is cooked completely without salt",
        entryAndLocalCost: 100,
      },
      {
        spotName: "Alangudi Apatsahayesvarar (Guru / Jupiter) Navagraha Temple",
        timeSlot: "03:30 PM – 06:00 PM",
        activity:
          "Sacred Dakshinamurthy (Guru Bhagavan) shrine surrounded by three rivers in Tiruvarur district",
        entryAndLocalCost: 100,
      },
    ],
  },
  {
    name: "Amaravathi Dam & Thirumoorthy Hills",
    category: "Nature & Waterfalls",
    district: "Tiruppur",
    wikiTitle: "Amaravathi Dam",
    image: CATEGORY_IMAGES["Nature & Waterfalls"],
    description:
      "Scenic Anamalai foothills getaway near Udumalpet combining the steep-stepped Amaravathi Dam viewpoint, crocodile park, and Panchalinga Falls at Thirumoorthy Hills.",
    avgHotelPerPerson: 1050,
    avgFoodPerDay: 450,
    avgTravelCostPerPerson: 580,
    spots: [
      {
        spotName: "Amaravathi Dam Viewpoint & Mugger Crocodile Park",
        timeSlot: "08:30 AM – 11:00 AM",
        activity:
          "Climb the dam steps for sweeping views of the Anamalai & Palani hills and visit South India's largest crocodile park",
        entryAndLocalCost: 120,
      },
      {
        spotName: "Thirumoorthy Hills Amanalingeswarar Temple & Dam Boating",
        timeSlot: "11:30 AM – 02:00 PM",
        activity:
          "Visit the boulder shrine of Brahma-Vishnu-Shiva and enjoy pedal boating on Thirumoorthy Reservoir",
        entryAndLocalCost: 140,
      },
      {
        spotName: "Panchalinga Waterfalls (Thirumoorthy Hills Trek)",
        timeSlot: "02:30 PM – 05:30 PM",
        activity:
          "Scenic 3-km forest trail to the refreshing mountain waterfall cascading over Western Ghats rocks",
        entryAndLocalCost: 100,
      },
    ],
  },
];

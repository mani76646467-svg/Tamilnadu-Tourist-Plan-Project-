import { DestinationCategory } from "./types";

export type AppLanguage = "ta" | "en" | "hi";

export const LANGUAGE_OPTIONS: {
  code: AppLanguage;
  label: string;
  nativeName: string;
}[] = [
  { code: "ta", label: "தமிழ்", nativeName: "Tamil" },
  { code: "en", label: "English", nativeName: "English" },
  { code: "hi", label: "हिन्दी", nativeName: "Hindi" },
];

export interface UIStrings {
  appName: string;
  navHome: string;
  navDestinations: string;
  navPlanner: string;
  navFeatures: string;
  navPlanTripBtn: string;
  themeBarLabel: string;
  heroKicker: string;
  heroTitlePrefix: string;
  heroTitleHighlight: string;
  heroDesc: (count: number) => string;
  heroExploreBtn: (count: number) => string;
  heroBuildBtn: string;
  featuresKicker: string;
  featuresTitle: string;
  feat1Title: string;
  feat1Desc: string;
  feat2Title: string;
  feat2Desc: string;
  feat3Title: (count: number) => string;
  feat3Desc: string;
  feat4Title: string;
  feat4Desc: string;
  destKicker: (count: number) => string;
  destTitle: string;
  searchLabel: string;
  searchPlaceholder: string;
  categoryLabel: string;
  allCategories: (count: number) => string;
  perDaySuffix: string;
  districtSuffix: string;
  mustVisitLabel: string;
  spotsCountBadge: (count: number) => string;
  planTripToBtn: (name: string) => string;
  plannerKicker: string;
  plannerTitle: string;
  plannerDesc: (count: number) => string;
  plannerBullet1: string;
  plannerBullet2: string;
  plannerBullet3: string;
  plannerBullet4: string;
  formLegend: string;
  labelStartCity: string;
  labelDestination: (count: number) => string;
  labelDays: string;
  labelPeople: string;
  labelBudgetPP: string;
  generateBtn: string;
  planResultKicker: string;
  daysLabel: string;
  peopleLabel: string;
  estTripCostLabel: string;
  perPersonLabel: string;
  yourBudgetLabel: string;
  downloadPdfBtn: string;
  generatingPdfBtn: string;
  checkWeatherBtn: string;
  checkingWeatherBtn: string;
  weatherSectionTitle: (destName: string) => string;
  feelsLikeLabel: string;
  humidityLabel: string;
  windSpeedLabel: string;
  forecast5DayTitle: string;
  packingTipsTitle: string;
  budgetBox1Title: string;
  budgetBox1Sub: (city: string, people: number) => string;
  budgetBox2Title: string;
  budgetBox2Sub: (nights: number) => string;
  budgetBox3Title: string;
  budgetBox3Sub: (days: number) => string;
  budgetBox4Title: string;
  budgetBox4Sub: (spots: number) => string;
  uniqueSpotsHeading: (count: number, destName: string) => string;
  dayLabel: string;
  totalLabel: string;
  thOrderTime: string;
  thPlace: string;
  thActivity: string;
  thCost: string;
  ctaKicker: string;
  ctaTitle: string;
  ctaBtn: string;
  footerSub: string;
}

export const UI_TRANSLATIONS: Record<AppLanguage, UIStrings> = {
  ta: {
    appName: "சுற்றுலா வழிகாட்டி",
    navHome: "முகப்பு",
    navDestinations: "சுற்றுலா இடங்கள்",
    navPlanner: "பயணத் திட்டம்",
    navFeatures: "சிறப்பம்சங்கள்",
    navPlanTripBtn: "பயணத் திட்டம்",
    themeBarLabel: "🎨 ஆப் நிறத்தைத் தேர்வு செய்க (Choose Color Theme):",
    heroKicker: "தேடுங்கள் • திட்டமிடுங்கள் • மகிழுங்கள்",
    heroTitlePrefix: "அழகிய ",
    heroTitleHighlight: "தமிழ்நாட்டைச் சுற்றிப் பாருங்கள்",
    heroDesc: (count) =>
      `தமிழ்நாட்டின் ${count} புகழ்பெற்ற கோவில்கள், மலை வாசஸ்தலங்கள், கடற்கரைகள், பாரம்பரியக் கோட்டைகள் மற்றும் அருவிகளை நேர வாரியான அட்டவணை மற்றும் துல்லியமான பட்ஜெட் கணக்குடன் திட்டமிடுங்கள்.`,
    heroExploreBtn: (count) => `${count} சுற்றுலா இடங்களைப் பார்க்க`,
    heroBuildBtn: "பயணத் திட்டம் உருவாக்கு",
    featuresKicker: "எங்கள் சிறப்பம்சங்கள்",
    featuresTitle: "உங்கள் சுற்றுலாவிற்குத் தேவையான அனைத்தும்",
    feat1Title: "நேர வாரியான திட்டம்",
    feat1Desc:
      "காலை முதல் இரவு வரை செல்ல வேண்டிய இடங்கள் மற்றும் நேரங்கள் வரிசையாக.",
    feat2Title: "துல்லியமான பட்ஜெட்",
    feat2Desc:
      "போக்குவரத்து, தங்குமிடம், உணவு மற்றும் நுழைவுக் கட்டணம் என நபர் வாரியான கணக்கு.",
    feat3Title: (count) => `${count}+ தமிழ்நாடு தலங்கள்`,
    feat3Desc: "தமிழ்நாட்டின் ஒவ்வொரு மாவட்டத்திலும் உள்ள உண்மையான சுற்றுலா இடங்கள்.",
    feat4Title: "தமிழ் • ஆங்கிலம் • இந்தி",
    feat4Desc: "தமிழ், ஆங்கிலம் மற்றும் இந்தி ஆகிய 3 மொழிகளில் முழு விவரங்கள்.",
    destKicker: (count) => `தமிழ்நாடு சுற்றுலா (${count} இடங்கள்)`,
    destTitle: "புகழ்பெற்ற சுற்றுலாத் தலங்கள்",
    searchLabel: "இடம் அல்லது சுற்றுலாத் தலம் தேடுக",
    searchPlaceholder: "மதுரை, ஊட்டி, அருவி...",
    categoryLabel: "சுற்றுலா வகை",
    allCategories: (count) => `அனைத்து வகைகளும் (${count})`,
    perDaySuffix: "/நாள் (1 நபர்)",
    districtSuffix: "மாவட்டம்",
    mustVisitLabel: "உள்ளே உள்ள முக்கிய இடங்கள்:",
    spotsCountBadge: (count) => `${count} சுற்றுலா இடங்கள்`,
    planTripToBtn: (name) => `${name} பயணத் திட்டம் →`,
    plannerKicker: "ஸ்மார்ட் பயணத் திட்டமிடல்",
    plannerTitle: "உங்கள் தமிழ்நாடு பயணத்தை உருவாக்குங்கள்",
    plannerDesc: (count) =>
      `${count} சுற்றுலாத் தலங்களிலிருந்து தேர்வு செய்யுங்கள். ஒவ்வொரு ஊரிலும் உள்ள உண்மையான சுற்றுலா இடங்கள், நேரம் மற்றும் துல்லியமான செலவு விவரங்களை வரிசையாகப் பெறுங்கள்.`,
    plannerBullet1: "✓ அந்தந்த ஊரில் உள்ள உண்மையான சுற்றுலா இடங்கள் வரிசையாக",
    plannerBullet2: "✓ காலை முதல் இரவு வரை துல்லியமான நேர அட்டவணை",
    plannerBullet3: "✓ போக்குவரத்து, விடுதி, உணவு & நுழைவுக் கட்டணம் தனித்தனியாக",
    plannerBullet4: "✓ தமிழ், ஆங்கிலம் & இந்தியில் அழகான PDF பதிவிறக்கம்",
    formLegend: "பயண விவரங்கள்",
    labelStartCity: "புறப்படும் ஊர் (Starting City)",
    labelDestination: (count) => `செல்லும் சுற்றுலாத் தலம் (${count} இடங்கள்)`,
    labelDays: "பயண நாட்கள் (1 - 15)",
    labelPeople: "மொத்த நபர்கள் (People)",
    labelBudgetPP: "நபர் 1-க்கு பட்ஜெட் (₹)",
    generateBtn: "பயணத் திட்டம் உருவாக்கு ✨",
    planResultKicker: "உங்கள் முழுமையான பயணத் திட்டம் • தமிழ், ஆங்கிலம் & இந்தி",
    daysLabel: "நாட்கள்",
    peopleLabel: "நபர்கள்",
    estTripCostLabel: "மொத்த திட்டச் செலவு",
    perPersonLabel: "நபர் 1-க்கு",
    yourBudgetLabel: "உங்கள் பட்ஜெட்",
    downloadPdfBtn: "Download Plan (PDF பதிவிறக்கம்)",
    generatingPdfBtn: "PDF தயாராகிறது...",
    checkWeatherBtn: "🌤️ Check Local Weather (வானிலை பார்க்க)",
    checkingWeatherBtn: "வானிலை ஏற்றப்படுகிறது...",
    weatherSectionTitle: (destName) =>
      `🌤️ ${destName} நேரடி வானிலை & எடுத்துச் செல்ல வேண்டியவை (Live Weather & Packing Guide)`,
    feelsLikeLabel: "உணரும் வெப்பம் (Feels Like)",
    humidityLabel: "ஈரப்பதம் (Humidity)",
    windSpeedLabel: "காற்றின் வேகம் (Wind)",
    forecast5DayTitle: "📅 5-நாள் வானிலை முன்னறிவிப்பு (5-Day Forecast)",
    packingTipsTitle: "🎒 பேக்கிங் ஆலோசனைகள் (Smart Packing Checklist)",
    budgetBox1Title: "1. போக்குவரத்து (Travel)",
    budgetBox1Sub: (city, people) =>
      `${city} ↔ போய் வர (${people} நபர்கள்)`,
    budgetBox2Title: "2. தங்குமிடம் (Hotel Stay)",
    budgetBox2Sub: (nights) =>
      nights > 0 ? `${nights} இரவு தங்குமிடச் செலவு` : "1 நாள் பயணம் (இரவு தங்கல் இல்லை)",
    budgetBox3Title: "3. உணவு (Food & Dining)",
    budgetBox3Sub: (days) => `${days} நாட்கள் (காலை, மதியம், இரவு உணவு)`,
    budgetBox4Title: "4. சுற்றுலா இடங்கள் (Sightseeing)",
    budgetBox4Sub: (spots) => `${spots} இடங்கள் நுழைவு & உள்ளூர் ஆட்டோ செலவு`,
    uniqueSpotsHeading: (count, destName) =>
      `📍 ${destName} பயணத்தில் செல்லும் ${count} வெவ்வேறு சுற்றுலாத் தலங்கள் (Accurate Places, Time & Per-Person Cost)`,
    dayLabel: "நாள்",
    totalLabel: "மொத்தம்",
    thOrderTime: "வரிசை & நேரம் (Time)",
    thPlace: "செல்லும் சுற்றுலா இடம் (Place)",
    thActivity: "செயல்பாடு (Activity)",
    thCost: "நபர் 1-க்கு & மொத்த செலவு (Cost)",
    ctaKicker: "உங்கள் அடுத்த பயணம்",
    ctaTitle: "தமிழ்நாடு உங்களை அன்புடன் அழைக்கிறது!",
    ctaBtn: "இப்போதே திட்டமிடுங்கள்",
    footerSub: "தமிழ்நாடு சுற்றுலா வழிகாட்டி & பயணத் திட்டமிடல் செயலி.",
  },
  en: {
    appName: "Smart Tourist Planner",
    navHome: "Home",
    navDestinations: "Destinations",
    navPlanner: "Trip Planner",
    navFeatures: "Features",
    navPlanTripBtn: "Plan Trip",
    themeBarLabel: "🎨 Choose App Color Theme (நிறத்தைத் தேர்வு செய்க):",
    heroKicker: "EXPLORE • PLAN • EXPERIENCE",
    heroTitlePrefix: "Discover the Beauty of ",
    heroTitleHighlight: "Tamil Nadu",
    heroDesc: (count) =>
      `Explore ${count} iconic destinations across temples, beaches, hill stations, heritage forts and waterfalls with time-wise sightseeing schedules and accurate budget breakdowns.`,
    heroExploreBtn: (count) => `Explore ${count} Destinations`,
    heroBuildBtn: "Build My Trip",
    featuresKicker: "WHY CHOOSE US?",
    featuresTitle: "Everything you need for your trip",
    feat1Title: "Time-Wise Itinerary",
    feat1Desc:
      "Sequential morning-to-night schedule showing exact places and timings.",
    feat2Title: "Accurate Budget Math",
    feat2Desc:
      "Exact per-person and group cost split for travel, stay, food, and entry tickets.",
    feat3Title: (count) => `${count}+ TN Destinations`,
    feat3Desc:
      "9–10+ authentic local tourist spots inside every destination of Tamil Nadu.",
    feat4Title: "Tamil • English • Hindi",
    feat4Desc: "Instant language switching and multilingual PDF travel plans.",
    destKicker: (count) => `EXPLORE TAMIL NADU (${count} PLACES)`,
    destTitle: "Popular Destinations",
    searchLabel: "Search place or tourist spot",
    searchPlaceholder: "Madurai, Ooty, Falls...",
    categoryLabel: "Destination category",
    allCategories: (count) => `All Categories (${count})`,
    perDaySuffix: "/day (per person)",
    districtSuffix: "District",
    mustVisitLabel: "Accurate Spots Inside:",
    spotsCountBadge: (count) => `${count} Local Spots`,
    planTripToBtn: (name) => `Plan Trip to ${name} →`,
    plannerKicker: "SMART TRIP PLANNER",
    plannerTitle: "Build Your Tamil Nadu Journey",
    plannerDesc: (count) =>
      `Select from ${count} destinations across Tamil Nadu. Our planner generates a complete sequential schedule with accurate local tourist places, timings, and exact itemized costs.`,
    plannerBullet1: "✓ 100% accurate local tourist places inside each destination",
    plannerBullet2: "✓ Morning-to-Night time slots for every spot in order",
    plannerBullet3: "✓ Exact itemized budget: Travel, Hotel, Food & Spot tickets",
    plannerBullet4: "✓ Attractive Tamil, English & Hindi PDF Download",
    formLegend: "Trip details",
    labelStartCity: "Starting City",
    labelDestination: (count) => `Destination (${count} Tourist Places)`,
    labelDays: "Number of Days (1 - 15)",
    labelPeople: "Number of People",
    labelBudgetPP: "Budget Per Person (₹)",
    generateBtn: "Generate My Trip ✨",
    planResultKicker: "YOUR SMART TRAVEL PLAN • TAMIL, ENGLISH & HINDI",
    daysLabel: "Days",
    peopleLabel: "People",
    estTripCostLabel: "Exact Trip Cost",
    perPersonLabel: "Per Person",
    yourBudgetLabel: "Your Budget",
    downloadPdfBtn: "Download Plan (PDF)",
    generatingPdfBtn: "Generating PDF...",
    checkWeatherBtn: "🌤️ Check Local Weather",
    checkingWeatherBtn: "Checking Weather...",
    weatherSectionTitle: (destName) =>
      `🌤️ Live Local Weather & Smart Packing Guide for ${destName}`,
    feelsLikeLabel: "Feels Like",
    humidityLabel: "Humidity",
    windSpeedLabel: "Wind Speed",
    forecast5DayTitle: "📅 5-Day Weather Forecast (வானிலை முன்னறிவிப்பு)",
    packingTipsTitle: "🎒 What to Pack (எடுத்துச் செல்ல வேண்டியவை)",
    budgetBox1Title: "1. Travel & Transport (போக்குவரத்து)",
    budgetBox1Sub: (city, people) =>
      `Onward & return from ${city} (${people} people)`,
    budgetBox2Title: "2. Hotel & Stay (தங்குமிடம்)",
    budgetBox2Sub: (nights) =>
      nights > 0 ? `${nights} night(s) hotel stay` : "1-Day Trip (No night stay)",
    budgetBox3Title: "3. Food & Dining (உணவு)",
    budgetBox3Sub: (days) =>
      `Breakfast, Lunch & Dinner for ${days} day(s)`,
    budgetBox4Title: "4. Sightseeing & Entry (சுற்றுலா இடங்கள்)",
    budgetBox4Sub: (spots) =>
      `Entry tickets & local transport for ${spots} spots`,
    uniqueSpotsHeading: (count, destName) =>
      `📍 All ${count} Unique Tourist Places in ${destName} (Accurate Spots, Time & Per-Person Cost)`,
    dayLabel: "Day",
    totalLabel: "Total",
    thOrderTime: "Order & Time (நேரம்)",
    thPlace: "Tourist Place / Spot (செல்லும் இடம்)",
    thActivity: "Activity Plan (செயல்பாடு)",
    thCost: "Per-Person & Total (செலவு)",
    ctaKicker: "YOUR NEXT ADVENTURE",
    ctaTitle: "Tamil Nadu is waiting for you!",
    ctaBtn: "Start Planning",
    footerSub: "A Tamil Nadu smart tourism & itinerary planning application.",
  },
  hi: {
    appName: "स्मार्ट टूरिस्ट प्लानर",
    navHome: "होम",
    navDestinations: "पर्यटन स्थल",
    navPlanner: "यात्रा प्लानर",
    navFeatures: "विशेषताएं",
    navPlanTripBtn: "यात्रा योजना",
    themeBarLabel: "🎨 ऐप का रंग चुनें (Choose Color Theme):",
    heroKicker: "खोजें • योजना बनाएं • अनुभव करें",
    heroTitlePrefix: "तमिलनाडु की ",
    heroTitleHighlight: "सुंदरता का अनुभव करें",
    heroDesc: (count) =>
      `समय-वार दर्शनीय स्थलों की सूची और सटीक बजट विवरण के साथ तमिलनाडु के ${count} प्रसिद्ध मंदिरों, हिल स्टेशनों, समुद्र तटों, किलों और झरनों की यात्रा योजना बनाएं।`,
    heroExploreBtn: (count) => `${count} पर्यटन स्थल देखें`,
    heroBuildBtn: "मेरी यात्रा बनाएं",
    featuresKicker: "हमें क्यों चुनें?",
    featuresTitle: "आपकी यात्रा के लिए संपूर्ण गाइड",
    feat1Title: "समय-वार यात्रा कार्यक्रम",
    feat1Desc:
      "सुबह से रात तक क्रमबद्ध समय और सटीक पर्यटन स्थलों की सूची।",
    feat2Title: "सटीक बजट गणना",
    feat2Desc:
      "यात्रा, होटल, भोजन और प्रवेश टिकट के लिए प्रति व्यक्ति और कुल खर्च।",
    feat3Title: (count) => `${count}+ तमिलनाडु स्थल`,
    feat3Desc: "तमिलनाडु के हर प्रमुख जिले के प्रामाणिक और प्रसिद्ध पर्यटन स्थल।",
    feat4Title: "तमिल • अंग्रेज़ी • हिन्दी",
    feat4Desc: "तीनों भाषाओं में यात्रा विवरण और आकर्षक PDF डाउनलोड।",
    destKicker: (count) => `तमिलनाडु पर्यटन (${count} प्रमुख स्थान)`,
    destTitle: "लोकप्रिय पर्यटन स्थल",
    searchLabel: "शहर या पर्यटन स्थल खोजें",
    searchPlaceholder: "मदुरै, ऊटी, झरना...",
    categoryLabel: "श्रेणी चुनें",
    allCategories: (count) => `सभी श्रेणियां (${count})`,
    perDaySuffix: "/दिन (प्रति व्यक्ति)",
    districtSuffix: "ज़िला",
    mustVisitLabel: "प्रमुख दर्शनीय स्थल:",
    spotsCountBadge: (count) => `${count} पर्यटन स्थल`,
    planTripToBtn: (name) => `${name} यात्रा योजना →`,
    plannerKicker: "स्मार्ट ट्रिप प्लानर",
    plannerTitle: "अपनी तमिलनाडु यात्रा योजना बनाएं",
    plannerDesc: (count) =>
      `तमिलनाडु के ${count} पर्यटन स्थलों में से चुनें। हमारा प्लानर सटीक स्थानीय पर्यटन स्थलों, समय और प्रति व्यक्ति बजट के साथ क्रमबद्ध तालिका बनाता है।`,
    plannerBullet1: "✓ हर पर्यटन स्थल के भीतर के सभी असली और सटीक दर्शनीय स्थल",
    plannerBullet2: "✓ सुबह से रात तक हर स्थान के लिए सटीक समय सारणी",
    plannerBullet3: "✓ सटीक बजट: यात्रा, होटल, भोजन और प्रवेश टिकट अलग-अलग",
    plannerBullet4: "✓ तमिल, अंग्रेज़ी और हिन्दी में आकर्षक PDF डाउनलोड",
    formLegend: "यात्रा विवरण",
    labelStartCity: "प्रस्थान शहर (Starting City)",
    labelDestination: (count) => `गंतव्य स्थान (${count} पर्यटन स्थल)`,
    labelDays: "दिनों की संख्या (1 - 15)",
    labelPeople: "यात्रियों की संख्या (People)",
    labelBudgetPP: "प्रति व्यक्ति बजट (₹)",
    generateBtn: "यात्रा योजना बनाएं ✨",
    planResultKicker: "आपकी स्मार्ट यात्रा योजना • तमिल, अंग्रेज़ी और हिन्दी",
    daysLabel: "दिन",
    peopleLabel: "यात्री",
    estTripCostLabel: "कुल अनुमानित खर्च",
    perPersonLabel: "प्रति व्यक्ति",
    yourBudgetLabel: "आपका बजट",
    downloadPdfBtn: "Download Plan (PDF डाउनलोड)",
    generatingPdfBtn: "PDF तैयार हो रहा है...",
    checkWeatherBtn: "🌤️ Check Local Weather (मौसम देखें)",
    checkingWeatherBtn: "मौसम लोड हो रहा है...",
    weatherSectionTitle: (destName) =>
      `🌤️ ${destName} का लाइव मौसम और पैकिंग गाइड (Live Weather & Packing Tips)`,
    feelsLikeLabel: "महसूस तापमान (Feels Like)",
    humidityLabel: "नमी (Humidity)",
    windSpeedLabel: "हवा की गति (Wind)",
    forecast5DayTitle: "📅 5-दिवसीय मौसम पूर्वानुमान (5-Day Forecast)",
    packingTipsTitle: "🎒 पैकिंग सुझाव (What to Pack)",
    budgetBox1Title: "1. यात्रा और परिवहन (Travel)",
    budgetBox1Sub: (city, people) =>
      `${city} से आना-जाना (${people} यात्री)`,
    budgetBox2Title: "2. होटल और ठहराव (Hotel Stay)",
    budgetBox2Sub: (nights) =>
      nights > 0 ? `${nights} रात होटल ठहराव` : "1-दिवसीय यात्रा (रात्रि विश्राम नहीं)",
    budgetBox3Title: "3. भोजन और जलपान (Food)",
    budgetBox3Sub: (days) => `${days} दिन (नाश्ता, दोपहर और रात का भोजन)`,
    budgetBox4Title: "4. दर्शनीय स्थल (Sightseeing)",
    budgetBox4Sub: (spots) => `${spots} स्थलों के टिकट और स्थानीय ऑटो खर्च`,
    uniqueSpotsHeading: (count, destName) =>
      `📍 ${destName} के सभी ${count} अलग-अलग प्रमुख पर्यटन स्थल (समय और प्रति व्यक्ति खर्च)`,
    dayLabel: "दिन",
    totalLabel: "कुल",
    thOrderTime: "क्रम और समय (Time)",
    thPlace: "पर्यटन स्थल (Tourist Place)",
    thActivity: "गतिविधि विवरण (Activity)",
    thCost: "प्रति व्यक्ति और कुल खर्च (Cost)",
    ctaKicker: "आपकी अगली यात्रा",
    ctaTitle: "तमिलनाडु आपका स्वागत करता है!",
    ctaBtn: "योजना शुरू करें",
    footerSub: "तमिलनाडु स्मार्ट पर्यटन और यात्रा योजना एप्लिकेशन।",
  },
};

export const CATEGORY_HINDI: Record<DestinationCategory, string> = {
  Temple: "मंदिर स्थल (Temple)",
  "Hill Station": "हिल स्टेशन (Hill Station)",
  Beach: "समुद्र तट (Beach)",
  Heritage: "ऐतिहासिक धरोहर (Heritage)",
  "Nature & Waterfalls": "प्रकृति और झरने (Nature & Waterfalls)",
};

export const DESTINATION_HINDI_NAMES: Record<
  string,
  { nameHi: string; districtHi: string; summaryHi: string }
> = {
  Madurai: {
    nameHi: "मदुरै",
    districtHi: "मदुरै ज़िला",
    summaryHi: "मीनाक्षी अम्मन मंदिर, ऐतिहासिक महल और पारंपरिक व्यंजनों के लिए प्रसिद्ध प्राचीन मंदिर नगरी।",
  },
  Ooty: {
    nameHi: "ऊटी (उदगमंडलम)",
    districtHi: "नीलगिरी ज़िला",
    summaryHi: "हरे-भरे चाय बागानों, बॉटनिकल गार्डन और ठंडी पहाड़ी हवाओं के लिए प्रसिद्ध 'पहाड़ों की रानी'।",
  },
  Rameswaram: {
    nameHi: "रामेश्वरम",
    districtHi: "रामनाथपुरम ज़िला",
    summaryHi: "रामनाथस्वामी ज्योतिर्लिंग मंदिर, पंबन पुल और धनुषकोडी समुद्र तट वाला पवित्र द्वीप।",
  },
  Kanyakumari: {
    nameHi: "कन्याकुमारी",
    districtHi: "कन्याकुमारी ज़िला",
    summaryHi: "भारत का दक्षिणी छोर जहाँ तीन समुद्र मिलते हैं; विवेकानंद रॉक मेमोरियल और तिरुवल्लुवर प्रतिमा।",
  },
  Mahabalipuram: {
    nameHi: "महाबलीपुरम (मामल्लपुरम)",
    districtHi: "चेंगलपट्टू ज़िला",
    summaryHi: "शोर मंदिर, पंच रथ और पल्लव कालीन चट्टानों को काटकर बनाई गई यूनेस्को विश्व धरोहर नगरी।",
  },
  Kodaikanal: {
    nameHi: "कोडईकनाल",
    districtHi: "डिंडीगुल ज़िला",
    summaryHi: "तारे के आकार की झील, देवदार के जंगल, पिलर रॉक्स और धुंध भरी घाटियों वाली 'पहाड़ों की राजकुमारी'।",
  },
  Thanjavur: {
    nameHi: "तंजावुर",
    districtHi: "तंजावुर ज़िला",
    summaryHi: "राजा राजा चोल द्वारा निर्मित यूनेस्को बृहदीश्वर मंदिर, मराठा महल और तंजौर पेंटिंग का केंद्र।",
  },
  "Chennai Marina": {
    nameHi: "चेन्नई मरीना बीच",
    districtHi: "चेन्नई ज़िला",
    summaryHi: "बंगाल की खाड़ी के किनारे भारत का सबसे लंबा शहरी समुद्र तट और ऐतिहासिक स्मारक।",
  },
  Yercaud: {
    nameHi: "यरकॉड",
    districtHi: "सेलम ज़िला",
    summaryHi: "शेवरॉय पहाड़ियों में कॉफी बागानों, झील और सुंदर व्यूपॉइंट्स के लिए प्रसिद्ध शांत हिल स्टेशन।",
  },
  "Hogenakkal Falls": {
    nameHi: "होगेناك्कल जलप्रपात",
    districtHi: "धर्मपुरी ज़िला",
    summaryHi: "चट्टानी घाटियों में गिरती कावेरी नदी और पारंपरिक गोल नाव (परिसल) की सवारी।",
  },
  Kanchipuram: {
    nameHi: "कांचीपुरम",
    districtHi: "कांचीपुरम ज़िला",
    summaryHi: "हज़ार मंदिरों का शहर और विश्व प्रसिद्ध हाथ से बुनी कांचीपुरम रेशमी साड़ियों की राजधानी।",
  },
  "Chidambaram & Pichavaram": {
    nameHi: "चिदंबरम और पिचावरम",
    districtHi: "कुड्डालोर ज़िला",
    summaryHi: "थिल्लई नटराज मंदिर और दुनिया का दूसरा सबसे बड़ा पिचावरम मैंग्रोव वन।",
  },
  Tiruvannamalai: {
    nameHi: "तिरुवन्नामलाई",
    districtHi: "तिरुवन्नामलाई ज़िला",
    summaryHi: "पवित्र अरुणाचल पर्वत के नीचे स्थित अन्नामलाईयार अग्नि लिंगम मंदिर और गिरिवलम पथ।",
  },
  "Srirangam & Tiruchirappalli": {
    nameHi: "श्रीरंगम और तिरुचिरापल्ली",
    districtHi: "तिरुचिरापल्ली ज़िला",
    summaryHi: "श्रीरंगम रंगनाथस्वामी मंदिर, रॉकफोर्ट उच्ची पिल्लयार मंदिर और प्राचीन कल्लनई बांध।",
  },
  "Kumbakonam & Darasuram": {
    nameHi: "कुंभकोणम और दारासुरम",
    districtHi: "तंजावुर ज़िला",
    summaryHi: "यूनेस्को ऐरावतेश्वर मंदिर, महामहम कुंड, नवग्रह मंदिर और प्रसिद्ध डिग्री कॉफी।",
  },
  "Courtallam (Kutralam)": {
    nameHi: "कुट्रालम (कोर्टालम)",
    districtHi: "तेनकासी ज़िला",
    summaryHi: "पश्चिमी घाट के औषधीय झरनों से भरपूर 'दक्षिण भारत का स्पा'।",
  },
  "Chettinad (Karaikudi)": {
    nameHi: "चेट्टीनाड (कराइकुडी)",
    districtHi: "शिवगंगा ज़िला",
    summaryHi: "भव्य चेट्टियार हवेलियों, अथांगुडी टाइल्स और स्वादिष्ट चेट्टीनाड व्यंजनों की भूमि।",
  },
  Coonoor: {
    nameHi: "कुनूर",
    districtHi: "नीलगिरी ज़िला",
    summaryHi: "सिम्स पार्क, डॉल्फिन नोज़ व्यूपॉइंट और नीलगिरी चाय बागानों से घिरा सुंदर हिल स्टेशन।",
  },
  Valparai: {
    nameHi: "वालपराई",
    districtHi: "कोयंबटूर ज़िला",
    summaryHi: "40 हेयरपिन मोड़ों, चाय बागानों और शोलायार बांध से युक्त अन्नामलाई हिल स्टेशन।",
  },
  "Gingee Fort (Senji)": {
    nameHi: "जिंजी किला (सेंजी)",
    districtHi: "विल्लुपुरम ज़िला",
    summaryHi: "तीन विशाल पहाड़ियों पर फैला अभेद्य ऐतिहासिक किला, जिसे 'पूरब का ट्रॉय' कहा जाता है।",
  },
  "Gangaikonda Cholapuram": {
    nameHi: "गंगईकोंडा चोलपुरम",
    districtHi: "अरियालुर ज़िला",
    summaryHi: "राजेंद्र चोल प्रथम की राजधानी और भव्य यूनेस्को विश्व धरोहर बृहदीश्वर मंदिर।",
  },
  "Yelagiri Hills": {
    nameHi: "येलागिरी हिल्स",
    districtHi: "तिरुपत्तूर ज़िला",
    summaryHi: "पुंगनूर झील, नेचर पार्क और स्वामीमलाई ट्रेकिंग पथ से घिरा शांत हिल स्टेशन।",
  },
  "Kolli Hills (Kolli Malai)": {
    nameHi: "कोल्ली हिल्स (कोल्ली मलाई)",
    districtHi: "नमक्कल ज़िला",
    summaryHi: "70 हेयरपिन मोड़, अगाया गंगई जलप्रपात और दुर्लभ आयुर्वेदिक जड़ी-बूटियों की पहाड़ियां।",
  },
  "Meghamalai (High Wavy Mountains)": {
    nameHi: "मेघमलाई",
    districtHi: "थेनी ज़िला",
    summaryHi: "बादलों से ढके चाय और इलायची बागान, हाईवेवीज़ बांध और सुरुली जलप्रपात।",
  },
  "Mudumalai National Park": {
    nameHi: "मुदुमलाई राष्ट्रीय उद्यान",
    districtHi: "नीलगिरी ज़िला",
    summaryHi: "थेप्पाकाडु हाथी शिविर, जंगल सफारी और वन्यजीवों से समृद्ध टाइगर रिज़र्व।",
  },
  Dhanushkodi: {
    nameHi: "धनुषकोडी",
    districtHi: "रामनाथपुरम ज़िला",
    summaryHi: "बंगाल की खाड़ी और हिंद महासागर के संगम पर स्थित अरिचल मुनई और ऐतिहासिक अवशेष।",
  },
  "Vellore Golden Temple & Fort": {
    nameHi: "वेल्लोर किला और स्वर्ण मंदिर",
    districtHi: "वेल्लोर ज़िला",
    summaryHi: "16वीं सदी का ग्रेनाइट वेल्लोर किला, जलकंडेश्वर मंदिर और श्रीपुरम स्वर्ण मंदिर।",
  },
  "Tharangambadi (Tranquebar)": {
    nameHi: "थरंगमबाड़ी (ट्रैंकेबार)",
    districtHi: "मयिलादुथुराई ज़िला",
    summaryHi: "1620 का डेनिश किला (फोर्ट डैन्सबोर्ग), ऐतिहासिक चर्च और शांत समुद्र तट।",
  },
  "Velankanni & Nagapattinam": {
    nameHi: "वेलांकन्नी और नागपट्टिनम",
    districtHi: "नागपट्टिनम ज़िला",
    summaryHi: "वेलांकन्नी बेसिलिका चर्च, नागोर दरगाह और कोडियाकराई वन्यजीव अभयारण्य।",
  },
  Palani: {
    nameHi: "पलनी",
    districtHi: "डिंडीगुल ज़िला",
    summaryHi: "भगवान मुरुगन का प्रसिद्ध पहाड़ी मंदिर (अरुपाड़ाई वीडु), रोपवे और पंचामृतम।",
  },
  Tiruchendur: {
    nameHi: "तिरुचेंदूर",
    districtHi: "थूथुकुडी ज़िला",
    summaryHi: "मन्नार की खाड़ी के समुद्र तट पर स्थित भव्य सुब्रमण्य स्वामी मंदिर और नाझीकिनारु।",
  },
  Poompuhar: {
    nameHi: "पूम्पुहार",
    districtHi: "मयिलादुथुराई ज़िला",
    summaryHi: "संगम कालीन प्राचीन चोल बंदरगाह, सिलप्पथिकारम आर्ट गैलरी और कावेरी समुद्र संगम।",
  },
  "Kovalam (Covelong) Beach": {
    nameHi: "कोवलम (कोवलॉन्ग) बीच",
    districtHi: "चेंगलपट्टू ज़िला",
    summaryHi: "ब्लू फ्लैग प्रमाणित समुद्र तट, सर्फिंग, मुट्टुकाडु बोट हाउस और दक्षीणचित्र।",
  },
  "Pollachi & Topslip (Anamalai)": {
    nameHi: "पोल्लाची और टॉपस्लिप (अन्नामलाई)",
    districtHi: "कोयंबटूर ज़िला",
    summaryHi: "अलियार बांध, मंकी फॉल्स, नारियल के बागान और अन्नामलाई टाइगर रिज़र्व सफारी।",
  },
  "Coimbatore & Isha Yoga Center": {
    nameHi: "कोयंबटूर और ईशा योग केंद्र",
    districtHi: "कोयंबटूर ज़िला",
    summaryHi: "112 फीट आदियोगी शिव प्रतिमा, मरुधमलाई मंदिर, पेरूर मंदिर और सिरुवानी झरने।",
  },
  Kotagiri: {
    nameHi: "कोटागिरी",
    districtHi: "नीलगिरी ज़िला",
    summaryHi: "कोडनाड व्यूपॉइंट, कैथरीन फॉल्स और शांत चाय बागानों वाला सबसे पुराना नीलगिरी हिल स्टेशन।",
  },
  "Thoothukudi (Tuticorin) & Pearl Coast": {
    nameHi: "थूथुकुडी (तूतीकोरिन) पर्ल कोस्ट",
    districtHi: "थूथुकुडी ज़िला",
    summaryHi: "आवर लेडी ऑफ स्नोज़ बेसिलिका, हेयर आइलैंड बीच और कट्टबोम्मन किला।",
  },
  "Pudukkottai & Sittanavasal": {
    nameHi: "पुदुक्कोट्टई और सित्तनवासल",
    districtHi: "पुदुक्कोट्टई ज़िला",
    summaryHi: "सित्तनवासल जैन गुफा भित्तिचित्र, थिरुमयम किला और नारथामलाई चोल मंदिर।",
  },
  "Kalakkad Mundanthurai & Manjolai": {
    nameHi: "कलक्कड़ मुंडनथुराई और पापनासम",
    districtHi: "तिरुनेलवेली ज़िला",
    summaryHi: "अगस्त्यर जलप्रपात, कारैयार बांध, नेल्लईअप्पर मंदिर और प्रसिद्ध तिरुनेलवेली हलवा।",
  },
  "Namakkal & Fort Rock": {
    nameHi: "नमक्कल किला और आंजनेयर मंदिर",
    districtHi: "नमक्कल ज़िला",
    summaryHi: "एकल चट्टानी पहाड़ी किला, 18 फीट नमक्कल हनुमान मंदिर और तिरुचेंगोडे पहाड़ी मंदिर।",
  },
  Srivilliputhur: {
    nameHi: "श्रीविल्लीपुथुर अंडाल मंदिर",
    districtHi: "विरुधुनगर ज़िला",
    summaryHi: "तमिलनाडु के राजकीय प्रतीक 192 फीट अंडाल राजगोपुरम और गिलहरी वन्यजीव अभयारण्य।",
  },
  Swamimalai: {
    nameHi: "स्वामीमलाई मुरुगन मंदिर",
    districtHi: "तंजावुर ज़िला",
    summaryHi: "भगवान मुरुगन के छह अरुपाड़ाई वीडु में से चौथा धाम और चोल कांस्य मूर्तियों का केंद्र।",
  },
  Thiruthani: {
    nameHi: "तिरुत्तनी मुरुगन मंदिर",
    districtHi: "तिरुवल्लुर ज़िला",
    summaryHi: "365 पवित्र सीढ़ियों वाला भगवान मुरुगन का पांचवां अरुपाड़ाई वीडु पहाड़ी मंदिर।",
  },
  "Pazhamudircholai & Alagar Koyil": {
    nameHi: "पझमुदिरचोलाई और अलगार कोविल",
    districtHi: "मदुरै ज़िला",
    summaryHi: "अलगार पहाड़ियों में स्थित कल्लझगर पेरुमल मंदिर, सोलाईमलाई मुरुगन और नूपुर गंगा झरना।",
  },
  Thiruparankundram: {
    nameHi: "तिरुप्परनकुंद्रम मुरुगन मंदिर",
    districtHi: "मदुरै ज़िला",
    summaryHi: "भगवान मुरुगन का प्रथम अरुपाड़ाई वीडु चट्टान-कट गुफा मंदिर और समनर जैन पहाड़ियां।",
  },
  "Mayiladuthurai & Vaitheeswaran Koil": {
    nameHi: "मयिलादुथुराई और वैथीस्वरन कोविल",
    districtHi: "मयिलादुथुराई ज़िला",
    summaryHi: "नवग्रह मंगल (अंगारक) धाम वैथीस्वरन कोविल, नाड़ी ज्योतिष और तिरुक्कडैयूर मंदिर।",
  },
  "Sirkazhi & Tiruvenkadu": {
    nameHi: "सीरकाझी और तिरुवेनकाडु",
    districtHi: "मयिलादुथुराई ज़िला",
    summaryHi: "संत तिरुज्ञानसंबंदर की जन्मभूमि सट्टईनाथर मंदिर और नवग्रह बुध धाम तिरुवेनकाडु।",
  },
  "Samayapuram & Thiruvanaikaval": {
    nameHi: "समयपुरम और तिरुவானैकवल",
    districtHi: "तिरुचिरापल्ली ज़िला",
    summaryHi: "समयपुरम मारीअम्मन मंदिर, पंचभूत जल लिंगम जंबुकेश्वर मंदिर और तितली उद्यान।",
  },
  "Pillayarpatti & Kundrakudi": {
    nameHi: "पिल्लैयारपट्टी और कुंद्रकुडी",
    districtHi: "शिवगंगा ज़िला",
    summaryHi: "प्राचीन चट्टान-कट कर्पक विनायकर मंदिर और कुंद्रकुडी मुरुगन पहाड़ी मंदिर।",
  },
  "Pamban Island & Sea Bridge": {
    nameHi: "पंबन द्वीप और समुद्री पुल",
    districtHi: "रामनाथपुरम ज़िला",
    summaryHi: "भारत का पहला समुद्री पंबन पुल, कुंथुकल बीच और विल्लुंडी तीर्थम समुद्र तट।",
  },
  "Ramanathapuram Palace & Devipattinam": {
    nameHi: "रामनाथपुरम महल और देवीपट्टिनम",
    districtHi: "रामनाथपुरम ज़िला",
    summaryHi: "सेतुपति राजाओं का रामलिंग विलासम महल, देवीपट्टिनम नवपाषाणम और तिरुप्पुल्लानी।",
  },
  "Dindigul Rock Fort": {
    nameHi: "डिंडीगुल रॉक फोर्ट (पहाड़ी किला)",
    districtHi: "डिंडीगुल ज़िला",
    summaryHi: "280 फीट ऊंची चट्टान पर बना ऐतिहासिक डिंडीगुल किला और आथूर कामराजर बांध।",
  },
  "Sirumalai Hills": {
    nameHi: "सिरुमलाई हिल्स",
    districtHi: "डिंडीगुल ज़िला",
    summaryHi: "18 हेयरपिन मोड़, सिरुमलाई झील, कॉफी बागान और शांत पहाड़ी दृश्य।",
  },
  "Javadi Hills (Jawadhu Malai)": {
    nameHi: "जवादी पहाड़ियां (जवाधु मलाई)",
    districtHi: "तिरुवन्नामलाई ज़िला",
    summaryHi: "भीमनमडवु झरना, कोमुट्टेरी झील और कावलूर खगोलीय वेधशाला।",
  },
  "Pachaimalai Hills": {
    nameHi: "पच्चईमलाई पहाड़ियां",
    districtHi: "तिरुचिरापल्ली ज़िला",
    summaryHi: "कोरैयार और मंगलम झरने, कटहल के बागान और हरे-भरे ट्रैकिंग पथ।",
  },
  "Kalrayan Hills": {
    nameHi: "कलरायन पहाड़ियां",
    districtHi: "कल्लाकुरिची ज़िला",
    summaryHi: "पेरियार और मेघम झरने, वानस्पतिक उद्यान और गोमुखी बांध।",
  },
  "Sathuragiri & Pilavakkal": {
    nameHi: "चतुरगिरि पहाड़ियां और पिलवक्कल बांध",
    districtHi: "विरुधुनगर ज़िला",
    summaryHi: "पश्चिमी घाट की पवित्र चतुरगिरि तलहटी, थानीपराई और पिलवक्कल बांध पार्क।",
  },
  "Bodi Mettu & Kurangani Hills": {
    nameHi: "बोडी मेट्टु और कुरंगनी पहाड़ियां",
    districtHi: "थेनी ज़िला",
    summaryHi: "17 हेयरपिन मोड़ वाला बोडी मेट्टु घाट, इलायची बागान और सोथुपराई बांध।",
  },
  "Cumbum Valley & Suruli Falls": {
    nameHi: "कंबम घाटी और सुरुली जलप्रपात",
    districtHi: "थेनी ज़िला",
    summaryHi: "सुरुली झरना, कंबम अंगूर के बाग (पन्नीर अंगूर) और वैगई बांध उद्यान।",
  },
  "Gudalur & Needle Rock (Nilgiris)": {
    nameHi: "गुडलूर और नीडल रॉक (नीलगिरी)",
    districtHi: "नीलगिरी ज़िला",
    summaryHi: "360-डिग्री नीडल रॉक व्यूपॉइंट, फ्रॉग हिल और जीन पूल इको-फॉरेस्ट गार्डन।",
  },
  "Avalanche & Emerald Lake": {
    nameHi: "एवलांच और एमराल्ड झील",
    districtHi: "नीलगिरी ज़िला",
    summaryHi: "नीलगिरी शोला वनों के बीच स्थित स्वच्छ एवलांच झील, फॉरेस्ट सफारी और एमराल्ड बांध।",
  },
  "Pykara & Mukurthi (Nilgiris)": {
    nameHi: "पाइकारा जलप्रपात और झील (नीलगिरी)",
    districtHi: "नीलगिरी ज़िला",
    summaryHi: "पाइकारा झरना, झील बोट हाउस, पाइन फॉरेस्ट और वेनलॉक डाउन्स घास के मैदान।",
  },
  "Masinagudi & Moyar Canyon": {
    nameHi: "मसीनागुडी और मोयार घाटी",
    districtHi: "नीलगिरी ज़िला",
    summaryHi: "गहरी मोयार नदी घाटी, हाथी गलियारा और कलहट्टी घाट व्यूपॉइंट।",
  },
  "Point Calimere (Kodiyakarai) & Vedaranyam": {
    nameHi: "पॉइंट कैलिमेरे (कोडियाकराई) और वेदारण्यम",
    districtHi: "नागपट्टिनम ज़िला",
    summaryHi: "राजहंस (फ्लेमिंगो) और काला हिरण अभयारण्य, चोल प्रकाशस्तंभ और वेदारण्येश्वर मंदिर।",
  },
  "Pichavaram Mangrove Forest": {
    nameHi: "पिचावरम मैंग्रोव वन",
    districtHi: "कुड्डालोर ज़िला",
    summaryHi: "दुनिया के सबसे बड़े मैंग्रोव वनों में से एक में 44 द्वीपों के बीच नौका विहार।",
  },
  "Silver Beach & Fort St. David (Cuddalore)": {
    nameHi: "सिल्वर बीच और फोर्ट सेंट डेविड (कुड्डालोर)",
    districtHi: "कुड्डालोर ज़िला",
    summaryHi: "विस्तृत सिल्वर बीच बैकवाटर बोटिंग, ऐतिहासिक फोर्ट सेंट डेविड और तिरुवहिंद्रपुरम मंदिर।",
  },
  "Pulicat Lake (Pazhaverkadu)": {
    nameHi: "पुलिकट झील (पझावेरकाडु)",
    districtHi: "तिरुवल्लुर ज़िला",
    summaryHi: "भारत की दूसरी सबसे बड़ी खारे पानी की झील, फ्लेमिंगो बोट राइड और 1656 डच कब्रिस्तान।",
  },
  "Vedanthangal & Karikili Bird Sanctuary": {
    nameHi: "वेदांथंगल और करिकिली पक्षी अभयारण्य",
    districtHi: "चेंगलपट्टू ज़िला",
    summaryHi: "भारत का सबसे पुराना जलपक्षी अभयारण्य और मदुरांतकम एरी कथा रामर मंदिर।",
  },
  "Sadras Dutch Fort & Thirukazhukundram": {
    nameHi: "सद्रास डच किला और तिरुक्कझुकुंद्रम",
    districtHi: "चेंगलपट्टू ज़िला",
    summaryHi: "17वीं सदी का सद्रास तटीय डच किला और तिरुक्कझुकुंद्रम पक्षी तीर्थम पहाड़ी मंदिर।",
  },
  "DakshinaChitra & Muttukadu (ECR)": {
    nameHi: "दक्षीणचित्र और मुट्टुकाडु (ECR)",
    districtHi: "चेंगलपट्टू ज़िला",
    summaryHi: "दक्षिण भारतीय विरासत संग्रहालय दक्षीणचित्र, मुट्टुकाडु बोट हाउस और क्रोकोडाइल बैंक।",
  },
  "Mylapore & San Thome (Chennai)": {
    nameHi: "मायलापुर और सैन थोम (चेन्नई)",
    districtHi: "चेन्नई ज़िला",
    summaryHi: "ऐतिहासिक कपालीश्वर मंदिर, सैन थोम कैथेड्रल बेसिलिका और रामकृष्ण मठ।",
  },
  "Fort St. George & Egmore Museum": {
    nameHi: "फोर्ट सेंट जॉर्ज और एग्मोर संग्रहालय",
    districtHi: "चेन्नई ज़िला",
    summaryHi: "1644 का ब्रिटिश किला, चोल कांस्य गैलरी वाला एग्मोर संग्रहालय और वल्लुवर कोट्टम।",
  },
  "Besant Nagar Elliot's Beach & Guindy Park": {
    nameHi: "बेसेंट नगर एलियट्स बीच और गिंडी पार्क",
    districtHi: "चेन्नई ज़िला",
    summaryHi: "बेसेंट नगर समुद्र तट, अष्टलक्ष्मी मंदिर और गिंडी राष्ट्रीय उद्यान।",
  },
  "Vandalur Zoo (Arignar Anna Zoological Park)": {
    nameHi: "वंडालूर चिड़ियाघर (अरिग्नार अन्ना प्राणी उद्यान)",
    districtHi: "चेंगलपट्टू ज़िला",
    summaryHi: "दक्षिण एशिया के सबसे बड़े चिड़ियाघरों में से एक, लायन सफारी और तिरुप्पोरूर मंदिर।",
  },
  "Thiruparappu Falls & Mathur Aqueduct": {
    nameHi: "थिरुपरप्पु जलप्रपात और माथुर एक्वाडक्ट",
    districtHi: "कन्याकुमारी ज़िला",
    summaryHi: "थिरुपरप्पु झरना, पेचिपराई बांध और एशिया का सबसे ऊंचा माथुर हैंगिंग ब्रिज।",
  },
  "Padmanabhapuram Palace & Udayagiri Fort": {
    nameHi: "पद्मनाभपुरम महल और उदयगिरि किला",
    districtHi: "कन्याकुमारी ज़िला",
    summaryHi: "एशिया का सबसे बड़ा लकड़ी का महल पद्मनाभपुरम, उदयगिरि किला और तिरुवट्टार मंदिर।",
  },
  "Vattakottai Fort & Muttom Beach": {
    nameHi: "वट्टकोट्टई किला और मुट्टम बीच",
    districtHi: "कन्याकुमारी ज़िला",
    summaryHi: "समुद्र तट पर बना ग्रेनाइट वट्टकोट्टई किला, चोथाविलई बीच और मुट्टम चट्टानी सूर्यास्त।",
  },
  "Suchindram & Nagercoil Temples": {
    nameHi: "सुचींद्रम थानुमालयन और नागरकोइल मंदिर",
    districtHi: "कन्याकुमारी ज़िला",
    summaryHi: "संगीतमय पत्थर के स्तंभों और 22 फीट हनुमान प्रतिमा वाला सुचींद्रम मंदिर और नागराजा मंदिर।",
  },
  "Papanasam & Agasthiyar Falls": {
    nameHi: "पापनासम और अगस्त्यर जलप्रपात",
    districtHi: "तिरुनेलवेली ज़िला",
    summaryHi: "ताम्रपर्णी नदी का बारहमासी अगस्त्यर झरना, पापनासनाथर मंदिर और कारैयार बांध।",
  },
  "Manapad Beach & Nava Tirupati": {
    nameHi: "मनापाड बीच और नव तिरुपति",
    districtHi: "थूथुकुडी ज़िला",
    summaryHi: "मनापाड क्लिफ चर्च और सर्फिंग लैगून, कुलसेकरपट्टिनम और नव तिरुपति मंदिर।",
  },
  "Kazhugumalai (Vettuvan Koil)": {
    nameHi: "कझुगुमलाई (वेट्टुवन कोविल)",
    districtHi: "थूथुकुडी ज़िला",
    summaryHi: "दक्षिण भारत का एलोरा कहलाने वाला एकल चट्टानी वेट्टुवन कोविल और जैन शिलालेख।",
  },
  "Panchalankurichi & Ettayapuram": {
    nameHi: "पंचालनकुरिची किला और एट्टयपुरम",
    districtHi: "थूथुकुडी ज़िला",
    summaryHi: "वीरपांडिया कट्टबोम्मन किला, महाकवि भरतियार जन्मस्थान और वी.ओ. चिदंबरम पिल्लई स्मारक।",
  },
  "Sankarankovil (Sankaranayinarkoil)": {
    nameHi: "शंकरनकोविल (शंकरनारायणर मंदिर)",
    districtHi: "तेनकासी ज़िला",
    summaryHi: "हरिहर (शंकरनारायणर) और गोमती अम्मन का ऐतिहासिक मंदिर और गुंडार बांध।",
  },
  "Tenkasi Kasi Viswanathar & Old Courtallam": {
    nameHi: "तेनकासी काशी विश्वनाथर और पुराना कुट्रालम",
    districtHi: "तेनकासी ज़िला",
    summaryHi: "180 फीट राजगोपुरम वाला तेनकासी काशी विश्वनाथर मंदिर और ओल्ड कुट्रालम झरना।",
  },
  "Thirumayam Fort & Avudaiyarkoil": {
    nameHi: "थिरुमयम किला और आवुदैयारकोविल",
    districtHi: "पुदुक्कोट्टई ज़िला",
    summaryHi: "17वीं सदी का थिरुमयम पहाड़ी किला, गुफा मंदिर और अद्भुत पाषाण छत वाला आवुदैयारकोविल।",
  },
  "Viralimalai Peacock Sanctuary & Kodumbalur": {
    nameHi: "विरालीमलाई मयूर अभयारण्य और कोडुंबलूर",
    districtHi: "पुदुक्कोट्टई ज़िला",
    summaryHi: "मोर अभयारण्य से घिरा विरालीमलाई मुरुगन पहाड़ी मंदिर और कोडुंबलूर मूवर कोविल।",
  },
  "Bhavanisagar Dam & Kodiveri Falls": {
    nameHi: "भवानीसागर बांध और कोडिवेरी जलप्रपात",
    districtHi: "इरोड ज़िला",
    summaryHi: "दुनिया के सबसे बड़े मिट्टी के बांधों में से एक भवानीसागर, कोडिवेरी झरना और बन्नारी अम्मन मंदिर।",
  },
  "Sathyamangalam Tiger Reserve & Dhimbam": {
    nameHi: "सत्यमंगलम टाइगर रिज़र्व और धिंबम",
    districtHi: "इरोड ज़िला",
    summaryHi: "27 हेयरपिन मोड़ों वाला धिंबम घाट, हसनूर जंगल सफारी और थलामलाई पठार।",
  },
  "Chennimalai & Vellode Bird Sanctuary": {
    nameHi: "चेन्नीमलाई और वेल्लोड पक्षी अभयारण्य",
    districtHi: "इरोड ज़िला",
    summaryHi: "चेन्नीमलाई मुरुगन पहाड़ी मंदिर, वेल्लोड पक्षी अभयारण्य और कोडुमुडी कावेरी मंदिर।",
  },
  "Mettur Dam & Taramangalam (Salem)": {
    nameHi: "मेट्टूर बांध और तारमंगलम (सेलम)",
    districtHi: "सेलम ज़िला",
    summaryHi: "कावेरी नदी पर बना विशाल स्टेनली जलाशय (मेट्टूर बांध) और तारमंगलम कैलासनाथर पाषाण कला।",
  },
  "Tiruchengode Ardhanareeswarar Hill": {
    nameHi: "तिरुचेंगोडे अर्धनारीश्वर पहाड़ी मंदिर",
    districtHi: "नमक्कल ज़िला",
    summaryHi: "60 फीट विशाल सर्प शिल्प और अर्धनारीश्वर स्वरूप वाला लाल पहाड़ी मंदिर।",
  },
  "Bhavani Kooduthurai & Uratchikottai": {
    nameHi: "भवानी कूडुथुराई और उरात्चिकोट्टई",
    districtHi: "इरोड ज़िला",
    summaryHi: "कावेरी, भवानी और अमृता नदियों का संगम (दक्षिण का त्रिवेणी संगम) संगमेश्वर मंदिर।",
  },
  "Sathanur Dam & Tirukoilur": {
    nameHi: "साथनूर बांध और तिरुकोइलूर",
    districtHi: "तिरुवन्नामलाई ज़िला",
    summaryHi: "थेनपेन्नई नदी पर साथनूर बांध उद्यान, मगरमच्छ पार्क और तिरुकोइलूर पेरुमल मंदिर।",
  },
  "Amirthi Zoo & Jalagamparai Falls": {
    nameHi: "अमिरथी प्राणी उद्यान और जलगमपराई झरना",
    districtHi: "वेल्लोर ज़िला",
    summaryHi: "जवादी पहाड़ियों में अमिरथी वन झरना एवं चिड़ियाघर, विरिंचीपुरम और जलगमपराई झरना।",
  },
  "Krishnagiri Dam & Rayakottai Fort": {
    nameHi: "कृष्णागिरी बांध और रायाकोट्टई किला",
    districtHi: "कृष्णागिरी ज़िला",
    summaryHi: "कृष्णागिरी (KRP) बांध रोज़ गार्डन, कृष्णागिरी पहाड़ी किला और रायाकोट्टई दुर्ग।",
  },
  "Keeladi Heritage Museum & Thirupuvanam": {
    nameHi: "कीझाडी विरासत संग्रहालय और तिरुप्पुवनम",
    districtHi: "शिवगंगा ज़िला",
    summaryHi: "2,600 वर्ष पुरानी संगम कालीन वैगई सभ्यता का कीझाडी संग्रहालय और तिरुप्पुवनम मंदिर।",
  },
  "Sikkal, Nagore & Ettukudi": {
    nameHi: "सिक्कल, नागोर दरगाह और एट्टुकुडी",
    districtHi: "नागपट्टिनम ज़िला",
    summaryHi: "सिक्कल सिंगारवेलवर मंदिर, ऐतिहासिक 5 मीनारों वाली नागोर दरगाह और एट्टुकुडी मुरुगन।",
  },
  "Mannargudi, Tiruvarur & Vaduvur": {
    nameHi: "मन्नारगुडी, तिरुवारूर और वडुवूर",
    districtHi: "तिरुवारूर ज़िला",
    summaryHi: "मन्नारगुडी राजगोपालस्वामी मंदिर (23 एकड़ हरिद्रा नदी कुंड), वडुवूर पक्षी अभयारण्य और तिरुवारूर रथ।",
  },
  "Thirunageswaram, Uppiliappan & Alangudi": {
    nameHi: "तिरुनागेश्वरम, उप्पिलीअप्पन और आलंगुडी",
    districtHi: "तिरुवारूर ज़िला",
    summaryHi: "तिरुनागेश्वरम राहु मंदिर, बिना नमक के प्रसाद वाला उप्पिलीअप्पन मंदिर और आलंगुडी गुरु धाम।",
  },
  "Amaravathi Dam & Thirumoorthy Hills": {
    nameHi: "अमरावती बांध और तिरुमूर्ति पहाड़ियां",
    districtHi: "तिरुपुर ज़िला",
    summaryHi: "अमरावती बांध एवं मगरमच्छ पार्क, तिरुमूर्ति हिल्स मंदिर और पंचलिंग झरना।",
  },
};

export const CITY_HINDI_MAP: Record<string, string> = {
  chennai: "चेन्नई",
  madurai: "मदुरै",
  coimbatore: "कोयंबटूर",
  trichy: "तिरुची",
  tiruchirappalli: "तिरुचिरापल्ली",
  salem: "सेलम",
  tirunelveli: "तिरुनेलवेली",
  erode: "इरोड",
  vellore: "वेल्लोर",
  thoothukudi: "थूथुकुडी",
  tuticorin: "तूतीकोरिन",
  thanjavur: "तंजावुर",
  dindigul: "डिंडीगुल",
  tiruppur: "तिरुपुर",
  kanchipuram: "कांचीपुरम",
  nagercoil: "नागरकोइल",
  kanyakumari: "कन्याकुमारी",
  karur: "करूर",
  namakkal: "नमक्कल",
  cuddalore: "कुड्डालोर",
  villupuram: "विल्लुपुरम",
  puducherry: "पुदुच्चेरी",
  pondicherry: "पुदुच्चेरी",
  bangalore: "बेंगलुरु",
  bengaluru: "बेंगलुरु",
  delhi: "दिल्ली",
  mumbai: "मुंबई",
  hyderabad: "हैदराबाद",
  kolkata: "कोलकाता",
};

export function getHindiCityName(city: string): string {
  const key = city.trim().toLowerCase();
  return CITY_HINDI_MAP[key] || city.trim();
}

export function getSpotHindiDetails(
  spotName: string,
  activity: string,
  destNameHi: string,
  category: DestinationCategory
): { placeHi: string; activityHi: string } {
  let categoryActivityHi =
    "प्रमुख पर्यटन स्थल का भ्रमण, फोटोग्राफी और स्थानीय संस्कृति का अनुभव";
  if (category === "Temple") {
    categoryActivityHi =
      "पवित्र मंदिर दर्शन, प्राचीन वास्तुकला और शिल्पकला का अवलोकन";
  } else if (category === "Hill Station") {
    categoryActivityHi =
      "पहाड़ी व्यूपॉइंट, बागान की सैर और शांत प्राकृतिक वातावरण का आनंद";
  } else if (category === "Beach") {
    categoryActivityHi =
      "समुद्र तट पर भ्रमण, समुद्री हवा और तटीय स्मारकों का दर्शन";
  } else if (category === "Heritage") {
    categoryActivityHi =
      "ऐतिहासिक किला, महल और प्राचीन पत्थर की नक्काशी का भ्रमण";
  } else if (category === "Nature & Waterfalls") {
    categoryActivityHi =
      "झरने का आनंद, वन्यजीव भ्रमण और प्राकृतिक दृश्यों की फोटोग्राफी";
  }

  return {
    placeHi: `${destNameHi} – ${spotName}`,
    activityHi: `${categoryActivityHi} (${activity})`,
  };
}

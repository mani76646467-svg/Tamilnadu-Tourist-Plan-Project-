import { Destination, CATEGORY_IMAGES } from "./types";

export const destinationsPart3: Destination[] = [
  {
    name: "Srivilliputhur",
    category: "Temple",
    district: "Virudhunagar",
    wikiTitle: "Srivilliputhur Andal temple",
    image: CATEGORY_IMAGES["Temple"],
    description:
      "Home to the iconic 192-foot Andal Temple Rajagopuram (the official emblem of Tamil Nadu) and the Grizzled Squirrel Wildlife Sanctuary.",
    avgHotelPerPerson: 950,
    avgFoodPerDay: 420,
    avgTravelCostPerPerson: 650,
    spots: [
      {
        spotName: "Arulmigu Nachiyar (Andal) Temple & 192-ft Rajagopuram",
        timeSlot: "06:30 AM – 09:30 AM",
        activity:
          "Darshan at the birthplace of Sri Andal & Periazhwar and view the towering 11-tiered gopuram",
        entryAndLocalCost: 100,
      },
      {
        spotName: "Madavar Vilagam Vaidyanathar Swamy Temple",
        timeSlot: "10:00 AM – 12:00 PM",
        activity:
          "Ancient Pandya-era Shiva temple famous for the 6-foot stone Nataraja sculpture",
        entryAndLocalCost: 80,
      },
      {
        spotName: "Shenbagathoppu Grizzled Squirrel Wildlife Sanctuary",
        timeSlot: "02:30 PM – 05:00 PM",
        activity:
          "Western Ghats foothills nature trail, forest stream & rare grizzled giant squirrel habitat",
        entryAndLocalCost: 150,
      },
      {
        spotName: "Thiruvannamalai Srinivasa Perumal Hill Temple (Srivilliputhur)",
        timeSlot: "05:15 PM – 07:00 PM",
        activity:
          "Climb the scenic hillock shrine known as South Tirupati and buy famous Srivilliputhur Palkova",
        entryAndLocalCost: 180,
      },
    ],
  },
  {
    name: "Swamimalai",
    category: "Temple",
    district: "Thanjavur",
    wikiTitle: "Swamimalai Murugan Temple",
    image: CATEGORY_IMAGES["Temple"],
    description:
      "Fourth Arupadaiveedu abode of Lord Murugan where He expounded the Pranava Mantra to Lord Shiva, famed for Chola bronze sculpture artisans.",
    avgHotelPerPerson: 1050,
    avgFoodPerDay: 450,
    avgTravelCostPerPerson: 600,
    spots: [
      {
        spotName: "Arulmigu Swaminathaswamy Temple (60 Tamil Year Steps)",
        timeSlot: "06:30 AM – 09:30 AM",
        activity:
          "Ascend the 60 sacred stone steps representing the Hindu cycle of years at this Arupadaiveedu shrine",
        entryAndLocalCost: 100,
      },
      {
        spotName: "Swamimalai Panchaloha Bronze Casting Artisan Workshops",
        timeSlot: "10:00 AM – 12:30 PM",
        activity:
          "Watch traditional Stapathis craft GI-tagged lost-wax Chola bronze idols by hand",
        entryAndLocalCost: 150,
      },
      {
        spotName: "Tiruvalanjuzhi Kabardeeswarar & Vellai Vinayagar Temple",
        timeSlot: "03:00 PM – 05:00 PM",
        activity:
          "Visit the historic shrine with the rare white sea-foam Ganesha idol and Chola stone windows",
        entryAndLocalCost: 90,
      },
      {
        spotName: "Patteswaram Durgai Amman Temple",
        timeSlot: "05:15 PM – 07:00 PM",
        activity:
          "Evening darshan at the revered Chola royal family guardian temple near Swamimalai",
        entryAndLocalCost: 100,
      },
    ],
  },
  {
    name: "Thiruthani",
    category: "Temple",
    district: "Tiruvallur",
    wikiTitle: "Subramaniya Swamy Temple, Tiruttani",
    image: CATEGORY_IMAGES["Temple"],
    description:
      "Fifth Arupadaiveedu hill shrine of Lord Murugan featuring 365 sacred steps representing the days of the year, just 85 km from Chennai.",
    avgHotelPerPerson: 950,
    avgFoodPerDay: 430,
    avgTravelCostPerPerson: 450,
    spots: [
      {
        spotName: "Arulmigu Subramaniya Swamy Hill Temple (365 Steps)",
        timeSlot: "06:30 AM – 10:00 AM",
        activity:
          "Morning darshan at the fifth Arupadaiveedu where Lord Murugan married Valli in peaceful bliss",
        entryAndLocalCost: 120,
      },
      {
        spotName: "Saravana Poigai Sacred Temple Tank",
        timeSlot: "10:30 AM – 12:00 PM",
        activity:
          "Holy spring-fed temple tank at the foothills surrounded by scenic hillocks",
        entryAndLocalCost: 60,
      },
      {
        spotName: "Tiruvalangadu Vadaranyeswarar Temple (Ratna Sabhai)",
        timeSlot: "03:00 PM – 05:15 PM",
        activity:
          "First of the five cosmic dance halls (Pancha Sabhai) of Lord Shiva associated with Karaikkal Ammaiyar",
        entryAndLocalCost: 120,
      },
    ],
  },
  {
    name: "Pazhamudircholai & Alagar Koyil",
    category: "Temple",
    district: "Madurai",
    wikiTitle: "Kallazhagar Temple",
    image: CATEGORY_IMAGES["Temple"],
    description:
      "Lush Alagar Hills reserve forest housing both the Divya Desam Kallazhagar Perumal Temple and the sixth Arupadaiveedu Solaimalai Murugan Temple.",
    avgHotelPerPerson: 1100,
    avgFoodPerDay: 480,
    avgTravelCostPerPerson: 620,
    spots: [
      {
        spotName: "Arulmigu Kallazhagar Sundararaja Perumal Temple",
        timeSlot: "07:00 AM – 09:30 AM",
        activity:
          "Explore the ancient fort-walled Divya Desam temple, sculpted mandapams & famous Dosai prasadam",
        entryAndLocalCost: 120,
      },
      {
        spotName: "Pazhamudircholai Solaimalai Murugan Temple",
        timeSlot: "10:00 AM – 12:30 PM",
        activity:
          "Sixth Arupadaiveedu shrine nestled amidst dense fruit orchards on Alagar Hills",
        entryAndLocalCost: 130,
      },
      {
        spotName: "Noopura Gangai (Silambaru) Natural Mountain Spring",
        timeSlot: "02:30 PM – 05:00 PM",
        activity:
          "Sacred perennial herbal mountain spring & Rakkayi Amman shrine at the top of Alagar Hills",
        entryAndLocalCost: 100,
      },
    ],
  },
  {
    name: "Thiruparankundram",
    category: "Temple",
    district: "Madurai",
    wikiTitle: "Thiruparankundram Murugan Temple",
    image: CATEGORY_IMAGES["Temple"],
    description:
      "First of the six Arupadaiveedu abodes of Lord Murugan, featuring an 8th-century Pandya rock-cut cave sanctum where Murugan wedded Deivanai.",
    avgHotelPerPerson: 1050,
    avgFoodPerDay: 460,
    avgTravelCostPerPerson: 600,
    spots: [
      {
        spotName: "Arulmigu Subramaniya Swamy Rock-Cut Cave Temple",
        timeSlot: "06:30 AM – 09:30 AM",
        activity:
          "Darshan at the first Arupadaiveedu with rock-carved shrines of Shiva, Vishnu, Durga, Vinayakar & Murugan",
        entryAndLocalCost: 100,
      },
      {
        spotName: "Thiruparankundram Hill Top Kasi Viswanathar & Machu Sunni",
        timeSlot: "10:00 AM – 12:30 PM",
        activity:
          "Scenic stone step climb up the monolithic hill for panoramic views of Madurai & Saravana Poigai lake",
        entryAndLocalCost: 80,
      },
      {
        spotName: "Samanar Malai (Keelakuyilkudi 2,000-Year-Old Jain Beds)",
        timeSlot: "03:30 PM – 06:00 PM",
        activity:
          "Explore Tamil-Brahmi inscriptions, rock-cut Jain Tirthankara reliefs & sunset viewpoint",
        entryAndLocalCost: 110,
      },
    ],
  },
  {
    name: "Mayiladuthurai & Vaitheeswaran Koil",
    category: "Temple",
    district: "Mayiladuthurai",
    wikiTitle: "Vaitheeswaran Koil",
    image: CATEGORY_IMAGES["Temple"],
    description:
      "Sacred Cauvery delta circuit featuring Vaitheeswaran Koil (Navagraha Mars shrine & Nadi astrology center), Mayuranathaswami Temple, and Thirukadaiyur.",
    avgHotelPerPerson: 950,
    avgFoodPerDay: 440,
    avgTravelCostPerPerson: 580,
    spots: [
      {
        spotName: "Vaitheeswaran Koil (Vaidyanathaswamy & Angaraka Shrine)",
        timeSlot: "07:00 AM – 09:30 AM",
        activity:
          "Navagraha temple of Mars (Sevvai), Siddhamirtham holy tank & traditional Nadi leaf heritage",
        entryAndLocalCost: 100,
      },
      {
        spotName: "Mayuranathaswami Temple & Thula Kattam Cauvery Ghat",
        timeSlot: "10:15 AM – 12:30 PM",
        activity:
          "Historic Mayiladuthurai temple where Goddess Parvati worshipped Shiva in the form of a peacock",
        entryAndLocalCost: 80,
      },
      {
        spotName: "Thirukadaiyur Amrithaghateswarar & Abirami Amman Temple",
        timeSlot: "03:30 PM – 06:30 PM",
        activity:
          "Famous Mrityunjaya shrine where Lord Shiva protected sage Markandeya",
        entryAndLocalCost: 120,
      },
    ],
  },
  {
    name: "Sirkazhi & Tiruvenkadu",
    category: "Temple",
    district: "Mayiladuthurai",
    wikiTitle: "Sattanathar temple, Sirkazhi",
    image: CATEGORY_IMAGES["Temple"],
    description:
      "Ancient Saivite pilgrimage town housing the three-tiered Sattanathar Temple (birthplace of saint Tirugnanasambandar) and Tiruvenkadu Budhan shrine.",
    avgHotelPerPerson: 900,
    avgFoodPerDay: 420,
    avgTravelCostPerPerson: 560,
    spots: [
      {
        spotName: "Sirkazhi Sattanathar (Brahmapureeswarar) Three-Tier Temple",
        timeSlot: "07:00 AM – 09:30 AM",
        activity:
          "Unique three-level shrine of Brahmapureeswarar, Thoniappar & Sattanathar with Brahma Theertham",
        entryAndLocalCost: 80,
      },
      {
        spotName: "Tiruvenkadu Swetharanyeswarar (Budhan / Mercury) Temple",
        timeSlot: "10:15 AM – 12:30 PM",
        activity:
          "Aghora Murthy shrine, three sacred tanks (Surya, Chandra, Agni) & Navagraha Mercury temple",
        entryAndLocalCost: 100,
      },
      {
        spotName: "Keezhaperumpallam Nagannathaswamy (Kethu) Temple",
        timeSlot: "03:30 PM – 06:00 PM",
        activity:
          "Visit the Navagraha Kethu Sthalam surrounded by lush Cauvery delta paddy fields",
        entryAndLocalCost: 100,
      },
    ],
  },
  {
    name: "Samayapuram & Thiruvanaikaval",
    category: "Temple",
    district: "Tiruchirappalli",
    wikiTitle: "Samayapuram Mariamman Temple",
    image: CATEGORY_IMAGES["Temple"],
    description:
      "One of Tamil Nadu's most visited Shakti shrines paired with Thiruvanaikaval Jambukeswarar (Panchabhoota Water Sthalam) and Srirangam Butterfly Park.",
    avgHotelPerPerson: 1050,
    avgFoodPerDay: 460,
    avgTravelCostPerPerson: 550,
    spots: [
      {
        spotName: "Arulmigu Samayapuram Mariamman Temple",
        timeSlot: "06:30 AM – 09:30 AM",
        activity:
          "Revered herbal-clay swayambu Mariamman shrine famous for healing vows and floral offerings",
        entryAndLocalCost: 100,
      },
      {
        spotName: "Thiruvanaikaval Jambukeswarar Akilandeswari Temple",
        timeSlot: "10:15 AM – 12:30 PM",
        activity:
          "Panchabhoota Sthalam of Water (Appu Lingam) with an underground perennial spring in the sanctum",
        entryAndLocalCost: 100,
      },
      {
        spotName: "Tropical Butterfly Conservatory (Upper Anaicut / Srirangam)",
        timeSlot: "03:00 PM – 05:30 PM",
        activity:
          "Asia's largest butterfly park at the confluence of Cauvery and Kollidam rivers",
        entryAndLocalCost: 150,
      },
    ],
  },
  {
    name: "Pillayarpatti & Kundrakudi",
    category: "Temple",
    district: "Sivaganga",
    wikiTitle: "Karpaka Vinayakar Temple",
    image: CATEGORY_IMAGES["Temple"],
    description:
      "4th-century Pandya rock-cut cave temple of Karpaka Vinayakar in Pillayarpatti alongside the scenic Kundrakudi Murugan hillock temple.",
    avgHotelPerPerson: 1000,
    avgFoodPerDay: 450,
    avgTravelCostPerPerson: 600,
    spots: [
      {
        spotName: "Pillayarpatti Karpaka Vinayakar Rock-Cut Cave Temple",
        timeSlot: "06:30 AM – 09:00 AM",
        activity:
          "6-foot rock-cut Valampuri Vinayakar with ancient Vatteluttu Tamil inscriptions",
        entryAndLocalCost: 90,
      },
      {
        spotName: "Kundrakudi Shanmuganathar Hill Temple",
        timeSlot: "09:45 AM – 12:00 PM",
        activity:
          "Climb the peacock-shaped rock hill temple surrounded by three Pandya cave shrines",
        entryAndLocalCost: 100,
      },
      {
        spotName: "Vairavanpatti Vairavanswamy Temple (Nagarathar Kovil)",
        timeSlot: "03:30 PM – 06:00 PM",
        activity:
          "Marvel at intricate Chettinad stone pillars, metallic artwork & Martanda Bhairavar shrine",
        entryAndLocalCost: 110,
      },
    ],
  },
  {
    name: "Pamban Island & Sea Bridge",
    category: "Beach",
    district: "Ramanathapuram",
    wikiTitle: "Pamban Bridge",
    image: CATEGORY_IMAGES["Beach"],
    description:
      "India's first sea bridge and new vertical-lift railway bridge spanning the turquoise Palk Strait, paired with Kunthukal and Villoondi coastal beaches.",
    avgHotelPerPerson: 1200,
    avgFoodPerDay: 500,
    avgTravelCostPerPerson: 720,
    spots: [
      {
        spotName: "Annai Indira Gandhi Road Bridge & Pamban Vertical Lift Bridge",
        timeSlot: "07:30 AM – 09:30 AM",
        activity:
          "Panoramic views of the emerald Palk Strait & engineering marvel connecting Mandapam to Pamban Island",
        entryAndLocalCost: 80,
      },
      {
        spotName: "Kunthukal Beach & Kurusadai Marine Biosphere View",
        timeSlot: "10:00 AM – 12:30 PM",
        activity:
          "Crystal-clear shallow turquoise lagoon ideal for coastal walks and marine photography",
        entryAndLocalCost: 150,
      },
      {
        spotName: "Villoondi Theertham Beach & Freshwater Sea Well",
        timeSlot: "03:30 PM – 06:00 PM",
        activity:
          "Unique freshwater spring well located right inside the salty sea waves along a serene beach",
        entryAndLocalCost: 100,
      },
    ],
  },
  {
    name: "Ramanathapuram Palace & Devipattinam",
    category: "Heritage",
    district: "Ramanathapuram",
    wikiTitle: "Ramalinga Vilasam Palace",
    image: CATEGORY_IMAGES["Heritage"],
    description:
      "Royal capital of the Setupathi kings featuring the mural-adorned Ramalinga Vilasam Palace, Erwadi, and the coastal Navabashanam shrine at Devipattinam.",
    avgHotelPerPerson: 950,
    avgFoodPerDay: 450,
    avgTravelCostPerPerson: 680,
    spots: [
      {
        spotName: "Ramalinga Vilasam Setupathi Royal Palace & Museum",
        timeSlot: "09:00 AM – 11:30 AM",
        activity:
          "Explore 18th-century Setupathi royal durbar hall, historic murals, weapons & armoury",
        entryAndLocalCost: 100,
      },
      {
        spotName: "Devipattinam Navabashanam Sea Temple",
        timeSlot: "12:00 PM – 02:00 PM",
        activity:
          "Nine planetary stone pillars submerged in the calm waters of the Bay of Bengal",
        entryAndLocalCost: 100,
      },
      {
        spotName: "Thiruppullani Adi Jagannatha Perumal Temple & Sethu Karai",
        timeSlot: "03:30 PM – 06:00 PM",
        activity:
          "Ancient Divya Desam shrine & historic Sethu Karai beach associated with the Ramayana",
        entryAndLocalCost: 120,
      },
    ],
  },
  {
    name: "Dindigul Rock Fort",
    category: "Heritage",
    district: "Dindigul",
    wikiTitle: "Dindigul Fort",
    image: CATEGORY_IMAGES["Heritage"],
    description:
      "Massive 17th-century monolithic rock fortress rising 280 feet above Dindigul town, historically defended by Nayak kings, Hyder Ali, and Tipu Sultan.",
    avgHotelPerPerson: 1000,
    avgFoodPerDay: 460,
    avgTravelCostPerPerson: 580,
    spots: [
      {
        spotName: "Dindigul Malai Kottai (Rock Fort) & Cannon Bastions",
        timeSlot: "08:00 AM – 11:00 AM",
        activity:
          "Climb the historic granite steps to fort ramparts, ammunition chambers & 360° Western Ghats views",
        entryAndLocalCost: 100,
      },
      {
        spotName: "Abirami Amman & Kottai Mariamman Temples",
        timeSlot: "11:30 AM – 01:00 PM",
        activity:
          "Visit Dindigul's historic town temples and savor authentic Dindigul Thalappakatti seeraga samba biryani",
        entryAndLocalCost: 150,
      },
      {
        spotName: "Athoor Kamarajar Dam & Western Ghats Foothills",
        timeSlot: "03:30 PM – 06:00 PM",
        activity:
          "Scenic reservoir surrounded by coconut groves and Western Ghats mountain peaks",
        entryAndLocalCost: 120,
      },
    ],
  },
  {
    name: "Sirumalai Hills",
    category: "Hill Station",
    district: "Dindigul",
    wikiTitle: "Sirumalai",
    image: CATEGORY_IMAGES["Hill Station"],
    description:
      "Serene 1,600-meter Eastern Ghats hill station near Dindigul and Madurai, famous for 18 hairpin bends, hill bananas, silver oak coffee estates, and cool climate.",
    avgHotelPerPerson: 1250,
    avgFoodPerDay: 480,
    avgTravelCostPerPerson: 620,
    spots: [
      {
        spotName: "Sirumalai 18 Hairpin Bends & Dindigul Valley Viewpoint",
        timeSlot: "08:00 AM – 10:00 AM",
        activity:
          "Misty morning drive up 18 hairpin bends with panoramic views of Dindigul Rock Fort below",
        entryAndLocalCost: 80,
      },
      {
        spotName: "Sirumalai Lake & Boating Park",
        timeSlot: "10:30 AM – 01:00 PM",
        activity:
          "Pedal boating in the tranquil artificial hill lake surrounded by pepper and coffee plantations",
        entryAndLocalCost: 180,
      },
      {
        spotName: "Sanjeevani Hills & Vellimalai Murugan Shrine",
        timeSlot: "03:00 PM – 05:30 PM",
        activity:
          "Trek to the hilltop Murugan temple & medicinal herb forest trail",
        entryAndLocalCost: 120,
      },
    ],
  },
  {
    name: "Javadi Hills (Jawadhu Malai)",
    category: "Hill Station",
    district: "Tiruvannamalai",
    wikiTitle: "Javadi Hills",
    image: CATEGORY_IMAGES["Hill Station"],
    description:
      "Unspoiled Eastern Ghats hill range spanning Tiruvannamalai and Vellore districts, home to Beemanmadavu Waterfalls, Kavalur Observatory, and Komutteri Lake.",
    avgHotelPerPerson: 1050,
    avgFoodPerDay: 430,
    avgTravelCostPerPerson: 580,
    spots: [
      {
        spotName: "Beemanmadavu Waterfalls (Jamunamarathur Forest)",
        timeSlot: "08:30 AM – 11:00 AM",
        activity:
          "Refreshing forest walk to the cascading Beeman Falls amidst sandalwood and bamboo groves",
        entryAndLocalCost: 100,
      },
      {
        spotName: "Komutteri Lake & Jamunamarathur Boat House",
        timeSlot: "11:30 AM – 01:30 PM",
        activity:
          "Boating and island park relaxation at the largest high-altitude lake in the Javadi Hills",
        entryAndLocalCost: 150,
      },
      {
        spotName: "Vainu Bappu Astronomical Observatory (Kavalur)",
        timeSlot: "03:00 PM – 05:30 PM",
        activity:
          "Visit one of Asia's premier optical telescope observatories nestled in the Javadi pine forests",
        entryAndLocalCost: 120,
      },
    ],
  },
  {
    name: "Pachaimalai Hills",
    category: "Hill Station",
    district: "Tiruchirappalli",
    wikiTitle: "Pachaimalai Hills",
    image: CATEGORY_IMAGES["Hill Station"],
    description:
      "Emerald-green hills near Thuraiyur in Tiruchirappalli district offering seasonal waterfalls, jackfruit orchards, tribal culture, and cool trekking trails.",
    avgHotelPerPerson: 950,
    avgFoodPerDay: 400,
    avgTravelCostPerPerson: 520,
    spots: [
      {
        spotName: "Koraiyar Waterfalls & Forest Stream",
        timeSlot: "08:30 AM – 11:00 AM",
        activity:
          "Scenic hike through green valleys to the natural rock pools of Koraiyar Falls",
        entryAndLocalCost: 100,
      },
      {
        spotName: "Mangalam Waterfalls & Jackfruit Orchards",
        timeSlot: "11:30 AM – 01:30 PM",
        activity:
          "Cascading mountain waterfall surrounded by spice and jackfruit plantations",
        entryAndLocalCost: 100,
      },
      {
        spotName: "Top Sengattupatti Eco Viewpoint & Tree House Park",
        timeSlot: "03:00 PM – 05:30 PM",
        activity:
          "Panoramic Eastern Ghats valley viewpoints and eco-tourism forest rest zone",
        entryAndLocalCost: 120,
      },
    ],
  },
  {
    name: "Kalrayan Hills",
    category: "Hill Station",
    district: "Kallakurichi",
    wikiTitle: "Kalrayan Hills",
    image: CATEGORY_IMAGES["Hill Station"],
    description:
      "Scenic Eastern Ghats mountain range featuring Periyar Falls, Megam Falls, Gomukhi Dam, and cool botanical gardens at Serapattu.",
    avgHotelPerPerson: 950,
    avgFoodPerDay: 410,
    avgTravelCostPerPerson: 540,
    spots: [
      {
        spotName: "Periyar Waterfalls & Megam Waterfalls",
        timeSlot: "08:30 AM – 11:30 AM",
        activity:
          "Experience two roaring mountain waterfalls plunging into rocky gorges in the Kalrayan range",
        entryAndLocalCost: 120,
      },
      {
        spotName: "Pappanaickenpatti Dam & Serapattu Botanical Park",
        timeSlot: "12:00 PM – 02:00 PM",
        activity:
          "Hilltop children's park, herbal garden, and peaceful reservoir views",
        entryAndLocalCost: 100,
      },
      {
        spotName: "Gomukhi Dam & Foothills Park (Kachirayapalayam)",
        timeSlot: "03:30 PM – 06:00 PM",
        activity:
          "Expansive dam at the foothills of Kalrayan Hills with sunset viewpoint and garden walk",
        entryAndLocalCost: 100,
      },
    ],
  },
  {
    name: "Sathuragiri & Pilavakkal",
    category: "Nature & Waterfalls",
    district: "Virudhunagar",
    wikiTitle: "Sathuragiri Hills",
    image: CATEGORY_IMAGES["Nature & Waterfalls"],
    description:
      "Mystical Siddhar mountain range in the Western Ghats paired with Pilavakkal Dam eco-park and natural forest streams near Watrap.",
    avgHotelPerPerson: 900,
    avgFoodPerDay: 400,
    avgTravelCostPerPerson: 600,
    spots: [
      {
        spotName: "Thaniparai Foothills & Sathuragiri Forest Trailhead",
        timeSlot: "07:00 AM – 10:30 AM",
        activity:
          "Sacred Western Ghats herbal forest base camp & mountain stream bath at Thaniparai",
        entryAndLocalCost: 100,
      },
      {
        spotName: "Pilavakkal Periyar & Kovilar Dams",
        timeSlot: "11:00 AM – 01:30 PM",
        activity:
          "Twin reservoirs framed by coconut palms and Western Ghats peaks with garden picnic areas",
        entryAndLocalCost: 110,
      },
      {
        spotName: "Kalyana Theertham & Ayyanar Koil Forest Stream (Rajapalayam)",
        timeSlot: "03:00 PM – 05:30 PM",
        activity:
          "Crystal-clear mountain river bathing spot and nature trail in the Rajapalayam hills",
        entryAndLocalCost: 100,
      },
    ],
  },
  {
    name: "Bodi Mettu & Kurangani Hills",
    category: "Hill Station",
    district: "Theni",
    wikiTitle: "Kurangani",
    image: CATEGORY_IMAGES["Hill Station"],
    description:
      "Spectacular 17-hairpin ghat road above Bodinayakanur offering sweeping views of the Theni valley, cardamom estates, and Kurangani mountain streams.",
    avgHotelPerPerson: 1200,
    avgFoodPerDay: 480,
    avgTravelCostPerPerson: 680,
    spots: [
      {
        spotName: "Bodi Mettu 17-Hairpin Ghat Viewpoint & Cardamom Estates",
        timeSlot: "08:00 AM – 10:30 AM",
        activity:
          "Breathtaking cloud-kissed viewpoint overlooking Bodinayakanur town & spice plantations",
        entryAndLocalCost: 100,
      },
      {
        spotName: "Kurangani Foothills & Kottakudi Mountain River",
        timeSlot: "11:00 AM – 01:30 PM",
        activity:
          "Scenic Western Ghats valley walk alongside boulder-strewn mountain streams & mango groves",
        entryAndLocalCost: 120,
      },
      {
        spotName: "Sothuparai Dam & Kumbakkarai Falls (Periyakulam)",
        timeSlot: "03:00 PM – 05:30 PM",
        activity:
          "Visit the high-arch masonry dam across Varaha river and Kumbakkarai foothills waterfall",
        entryAndLocalCost: 140,
      },
    ],
  },
  {
    name: "Cumbum Valley & Suruli Falls",
    category: "Nature & Waterfalls",
    district: "Theni",
    wikiTitle: "Suruli Falls",
    image: CATEGORY_IMAGES["Nature & Waterfalls"],
    description:
      "Fertile Cumbum Valley surrounded by the Western Ghats, famous for year-round Suruli Waterfalls, Panneer grape vineyards, and Vaigai Dam.",
    avgHotelPerPerson: 1100,
    avgFoodPerDay: 460,
    avgTravelCostPerPerson: 660,
    spots: [
      {
        spotName: "Suruli Waterfalls & Kailasanathar Cave",
        timeSlot: "08:00 AM – 10:30 AM",
        activity:
          "Two-stage 150-foot herbal waterfall celebrated in ancient Tamil epic Silappathikaram",
        entryAndLocalCost: 120,
      },
      {
        spotName: "Cumbum Panneer Grape Vineyards (Odaipatti)",
        timeSlot: "11:00 AM – 01:30 PM",
        activity:
          "Walk underneath lush overhead grape arbors and taste fresh GI-tagged Cumbum black grapes",
        entryAndLocalCost: 150,
      },
      {
        spotName: "Vaigai Dam & Little Brindavan Gardens",
        timeSlot: "03:30 PM – 06:00 PM",
        activity:
          "Stroll across the illuminated dam bridge, musical fountains & children's park",
        entryAndLocalCost: 120,
      },
    ],
  },
  {
    name: "Gudalur & Needle Rock (Nilgiris)",
    category: "Hill Station",
    district: "Nilgiris",
    wikiTitle: "Gudalur, Nilgiris",
    image: CATEGORY_IMAGES["Hill Station"],
    description:
      "Green gateway where Tamil Nadu, Kerala, and Karnataka meet, featuring the 360-degree Needle Rock Viewpoint, Frog Hill, and Nadugani Gene Pool forest.",
    avgHotelPerPerson: 1350,
    avgFoodPerDay: 520,
    avgTravelCostPerPerson: 750,
    spots: [
      {
        spotName: "Needle Rock Viewpoint (Soochimalai)",
        timeSlot: "08:00 AM – 10:30 AM",
        activity:
          "360-degree cloud viewpoint overlooking Mudumalai forests and Gudalur tea valleys",
        entryAndLocalCost: 100,
      },
      {
        spotName: "Frog Hill (Thavalai Malai) & O'Valley Tea Estates",
        timeSlot: "11:00 AM – 01:00 PM",
        activity:
          "View the natural frog-shaped mountain rock formation amidst sprawling green tea carpets",
        entryAndLocalCost: 80,
      },
      {
        spotName: "Gene Pool Eco-Forest Garden (Nadugani)",
        timeSlot: "02:30 PM – 05:30 PM",
        activity:
          "Guided eco-trail through rare Western Ghats orchids, ferns, bamboo bridges & viewpoints",
        entryAndLocalCost: 150,
      },
    ],
  },
  {
    name: "Avalanche & Emerald Lake",
    category: "Nature & Waterfalls",
    district: "Nilgiris",
    wikiTitle: "Avalanche Lake, Nilgiris",
    image: CATEGORY_IMAGES["Nature & Waterfalls"],
    description:
      "Pristine high-altitude Nilgiri biosphere lakes 25 km from Ooty, surrounded by untouched shola forests, rhododendrons, and trout hatcheries.",
    avgHotelPerPerson: 1500,
    avgFoodPerDay: 550,
    avgTravelCostPerPerson: 780,
    spots: [
      {
        spotName: "Avalanche Lake & Forest Department Eco Safari",
        timeSlot: "08:30 AM – 11:30 AM",
        activity:
          "Crystal-clear mountain lake and forest jeep safari to Cauliflower Shola & Bhavani Amman temple",
        entryAndLocalCost: 250,
      },
      {
        spotName: "Avalanche Trout Hatchery & Magnolia Trail",
        timeSlot: "11:45 AM – 01:00 PM",
        activity:
          "Visit the historic rainbow trout breeding center and high-altitude flower valley",
        entryAndLocalCost: 100,
      },
      {
        spotName: "Emerald Lake & Silent Valley Tea Viewpoint",
        timeSlot: "03:00 PM – 05:30 PM",
        activity:
          "Serene blue waters of Emerald Reservoir framed by rolling green tea slopes at sunset",
        entryAndLocalCost: 100,
      },
    ],
  },
  {
    name: "Pykara & Mukurthi (Nilgiris)",
    category: "Nature & Waterfalls",
    district: "Nilgiris",
    wikiTitle: "Pykara",
    image: CATEGORY_IMAGES["Nature & Waterfalls"],
    description:
      "Scenic Nilgiri plateau route featuring cascading Pykara Waterfalls, speed-boating on Pykara Lake, Wenlock Downs grasslands, and Kamaraj Sagar Dam.",
    avgHotelPerPerson: 1450,
    avgFoodPerDay: 540,
    avgTravelCostPerPerson: 760,
    spots: [
      {
        spotName: "Pykara Lake & TTDC Boat House",
        timeSlot: "08:30 AM – 11:00 AM",
        activity:
          "Speed boat and motorboat cruise across the winding shola-fringed Pykara River reservoir",
        entryAndLocalCost: 220,
      },
      {
        spotName: "Pykara Waterfalls",
        timeSlot: "11:15 AM – 01:00 PM",
        activity:
          "Walk through pine forests to view the sacred Toda river cascading over stepped granite rocks",
        entryAndLocalCost: 100,
      },
      {
        spotName: "Wenlock Downs (9th Mile Shooting Spot) & Pine Forest",
        timeSlot: "02:30 PM – 05:30 PM",
        activity:
          "Rolling emerald meadows and towering pine forest overlooking Kamaraj Sagar Dam",
        entryAndLocalCost: 120,
      },
    ],
  },
  {
    name: "Masinagudi & Moyar Canyon",
    category: "Nature & Waterfalls",
    district: "Nilgiris",
    wikiTitle: "Masinagudi",
    image: CATEGORY_IMAGES["Nature & Waterfalls"],
    description:
      "Wild foothills of the Nilgiris bordering Mudumalai, renowned for the dramatic 260-meter-deep Moyar River Gorge, elephant corridors, and jungle lodges.",
    avgHotelPerPerson: 1400,
    avgFoodPerDay: 520,
    avgTravelCostPerPerson: 740,
    spots: [
      {
        spotName: "Moyar River Gorge & Canyon Viewpoint",
        timeSlot: "07:00 AM – 09:30 AM",
        activity:
          "Morning wildlife drive along the deep canyon separating Mudumalai and Bandipur reserves",
        entryAndLocalCost: 250,
      },
      {
        spotName: "Maravakandy Dam & Bokkapuram Elephant Corridor",
        timeSlot: "10:00 AM – 12:30 PM",
        activity:
          "Spot spotted deer, peacocks, and wild elephants against the backdrop of the Blue Mountains",
        entryAndLocalCost: 150,
      },
      {
        spotName: "Kalhatti Ghat Viewpoint & Vibhuthi Malai Temple",
        timeSlot: "03:30 PM – 06:00 PM",
        activity:
          "Panoramic views of the Sigur plateau from the base of the 36-hairpin Kalhatti ghat road",
        entryAndLocalCost: 100,
      },
    ],
  },
  {
    name: "Point Calimere (Kodiyakarai) & Vedaranyam",
    category: "Nature & Waterfalls",
    district: "Nagapattinam",
    wikiTitle: "Point Calimere Wildlife and Bird Sanctuary",
    image: CATEGORY_IMAGES["Nature & Waterfalls"],
    description:
      "Ramsar coastal wetland cape where the Bay of Bengal turns into the Palk Strait, home to blackbucks, migratory flamingos, Chola lighthouse ruins, and Vedaranyam.",
    avgHotelPerPerson: 950,
    avgFoodPerDay: 430,
    avgTravelCostPerPerson: 600,
    spots: [
      {
        spotName: "Point Calimere (Kodiyakarai) Wildlife & Flamingo Sanctuary",
        timeSlot: "07:00 AM – 10:00 AM",
        activity:
          "Spot blackbuck antelope, feral horses, and thousands of flamingos across coastal mudflats",
        entryAndLocalCost: 150,
      },
      {
        spotName: "Ramar Padam, Chola Lighthouse Ruins & Kodiyakarai Beach",
        timeSlot: "10:30 AM – 12:30 PM",
        activity:
          "Visit the highest point on the cape and the historic 1,000-year-old Chola brick lighthouse",
        entryAndLocalCost: 80,
      },
      {
        spotName: "Vedaranyeswarar Temple & Salt Satyagraha Memorial (Vedaranyam)",
        timeSlot: "03:30 PM – 06:00 PM",
        activity:
          "Ancient Saptha Vidanga Shiva temple and historic 1930 Salt March freedom memorial",
        entryAndLocalCost: 100,
      },
    ],
  },
  {
    name: "Pichavaram Mangrove Forest",
    category: "Nature & Waterfalls",
    district: "Cuddalore",
    wikiTitle: "Pichavaram",
    image: CATEGORY_IMAGES["Nature & Waterfalls"],
    description:
      "One of the world's largest mangrove forests featuring over 1,100 hectares of water lanes, 44 green islands, and narrow canopy rowboat tunnels.",
    avgHotelPerPerson: 1050,
    avgFoodPerDay: 450,
    avgTravelCostPerPerson: 520,
    spots: [
      {
        spotName: "Pichavaram Mangrove Canopy Rowboat & Motorboat Safari",
        timeSlot: "08:00 AM – 11:00 AM",
        activity:
          "Glide through narrow sunlit mangrove root tunnels and estuarine birdwatching channels",
        entryAndLocalCost: 250,
      },
      {
        spotName: "Pichavaram Watchtower & Sandbar Island Beach",
        timeSlot: "11:30 AM – 01:30 PM",
        activity:
          "Climb the watchtower for an aerial view of the 44 mangrove islands meeting the Bay of Bengal",
        entryAndLocalCost: 100,
      },
      {
        spotName: "Porto Novo (Parangipettai) Marine Biology Museum & Estuary",
        timeSlot: "03:30 PM – 05:30 PM",
        activity:
          "Explore coastal marine biodiversity exhibits and the Vellar River sea mouth",
        entryAndLocalCost: 100,
      },
    ],
  },
  {
    name: "Silver Beach & Fort St. David (Cuddalore)",
    category: "Beach",
    district: "Cuddalore",
    wikiTitle: "Silver Beach (India)",
    image: CATEGORY_IMAGES["Beach"],
    description:
      "One of the longest and widest silver-sand beaches on the Coromandel Coast, separated from the town by a scenic backwater boating channel.",
    avgHotelPerPerson: 1000,
    avgFoodPerDay: 440,
    avgTravelCostPerPerson: 480,
    spots: [
      {
        spotName: "Silver Beach Promenade & Backwater Boating",
        timeSlot: "07:30 AM – 10:00 AM",
        activity:
          "Wide silver sand shoreline, lighthouse view, and calm Uppanar backwater boat ride",
        entryAndLocalCost: 140,
      },
      {
        spotName: "Fort St. David Ruins & British Colonial Heritage (Devanampattinam)",
        timeSlot: "10:30 AM – 12:30 PM",
        activity:
          "Explore the 17th-century coastal fort ruins where British and French forces clashed",
        entryAndLocalCost: 80,
      },
      {
        spotName: "Tiruvahindrapuram Devanathaswamy Temple & Oushadagiri Hill",
        timeSlot: "03:30 PM – 06:00 PM",
        activity:
          "Revered Divya Desam temple and Hayagriva hillock shrine overlooking the Gadilam River",
        entryAndLocalCost: 100,
      },
    ],
  },
  {
    name: "Pulicat Lake (Pazhaverkadu)",
    category: "Nature & Waterfalls",
    district: "Tiruvallur",
    wikiTitle: "Pulicat Lake",
    image: CATEGORY_IMAGES["Nature & Waterfalls"],
    description:
      "India's second-largest brackish water lagoon north of Chennai, famous for wintering flamingos, barrier island sandbars, and 17th-century Dutch heritage.",
    avgHotelPerPerson: 1000,
    avgFoodPerDay: 450,
    avgTravelCostPerPerson: 420,
    spots: [
      {
        spotName: "Pulicat Lagoon Flamingo Boat Ride & Barrier Island Sandbar",
        timeSlot: "07:00 AM – 10:00 AM",
        activity:
          "Boat across the serene lagoon where lake waters meet the Bay of Bengal and spot flamingos & pelicans",
        entryAndLocalCost: 220,
      },
      {
        spotName: "Historic Dutch Cemetery (1656) & Fort Geldria Ruins",
        timeSlot: "10:30 AM – 12:30 PM",
        activity:
          "Admire carved 17th-century Dutch VOC tombstones, obelisks & colonial port history",
        entryAndLocalCost: 80,
      },
      {
        spotName: "Pulicat Lighthouse & Kattupalli Coastal View",
        timeSlot: "03:30 PM – 05:30 PM",
        activity:
          "Coastal breeze and panoramic views of the Coromandel coastline and fishing harbor",
        entryAndLocalCost: 100,
      },
    ],
  },
  {
    name: "Vedanthangal & Karikili Bird Sanctuary",
    category: "Nature & Waterfalls",
    district: "Chengalpattu",
    wikiTitle: "Vedanthangal Bird Sanctuary",
    image: CATEGORY_IMAGES["Nature & Waterfalls"],
    description:
      "India's oldest community-protected waterbird sanctuary where over 40,000 migratory painted storks, pelicans, and spoonbills nest in submerged Barringtonia trees.",
    avgHotelPerPerson: 1000,
    avgFoodPerDay: 440,
    avgTravelCostPerPerson: 420,
    spots: [
      {
        spotName: "Vedanthangal Bird Sanctuary Bund Walk & Watchtower",
        timeSlot: "07:00 AM – 10:00 AM",
        activity:
          "Observe thousands of nesting pelicans, painted storks, ibises & herons through binoculars",
        entryAndLocalCost: 120,
      },
      {
        spotName: "Karikili Bird Sanctuary (Wetland Habitat)",
        timeSlot: "10:30 AM – 12:30 PM",
        activity:
          "Ramsar wetland sanctuary just 9 km from Vedanthangal where waterbirds forage",
        entryAndLocalCost: 100,
      },
      {
        spotName: "Madurantakam Eri Katha Ramar Temple & Tank",
        timeSlot: "03:30 PM – 06:00 PM",
        activity:
          "Historic temple beside the massive Madurantakam lake with British-era inscription",
        entryAndLocalCost: 80,
      },
    ],
  },
  {
    name: "Sadras Dutch Fort & Thirukazhukundram",
    category: "Heritage",
    district: "Chengalpattu",
    wikiTitle: "Sadras",
    image: CATEGORY_IMAGES["Heritage"],
    description:
      "17th-century Dutch East India Company red-brick fortress on the Coromandel shore near Kalpakkam, paired with the ancient Eagle Hill temple of Thirukazhukundram.",
    avgHotelPerPerson: 1100,
    avgFoodPerDay: 460,
    avgTravelCostPerPerson: 430,
    spots: [
      {
        spotName: "Sadras 17th-Century Dutch Fort & Carved Cemetery",
        timeSlot: "08:30 AM – 11:00 AM",
        activity:
          "Explore ASI-protected red-brick bastions, granaries & heraldic Dutch tombstones",
        entryAndLocalCost: 80,
      },
      {
        spotName: "Sadras Coastal Beach & Meyyur Fishing Village",
        timeSlot: "11:15 AM – 01:00 PM",
        activity:
          "Peaceful uncrowded East Coast beach walk beside the historic fort ramparts",
        entryAndLocalCost: 60,
      },
      {
        spotName: "Thirukazhukundram Vedagiriswarar Hill Temple (Pakshi Theertham)",
        timeSlot: "03:30 PM – 06:00 PM",
        activity:
          "Climb 500 granite steps to the Pallava rock-cut hill temple and view the 12-year Conch tank",
        entryAndLocalCost: 120,
      },
    ],
  },
  {
    name: "DakshinaChitra & Muttukadu (ECR)",
    category: "Heritage",
    district: "Chengalpattu",
    wikiTitle: "DakshinaChitra",
    image: CATEGORY_IMAGES["Heritage"],
    description:
      "East Coast Road cultural corridor combining DakshinaChitra living South Indian heritage museum, Muttukadu backwater boating, and Madras Crocodile Bank.",
    avgHotelPerPerson: 1350,
    avgFoodPerDay: 520,
    avgTravelCostPerPerson: 400,
    spots: [
      {
        spotName: "DakshinaChitra Living Heritage Museum",
        timeSlot: "09:30 AM – 12:30 PM",
        activity:
          "Tour authentic reconstructed Tamil, Kerala, Andhra & Karnataka heritage homes, pottery & glassblowing",
        entryAndLocalCost: 250,
      },
      {
        spotName: "Muttukadu Boat House (TTDC Backwaters)",
        timeSlot: "01:30 PM – 03:30 PM",
        activity:
          "Speed boat, rowboat, and water scooter rides across the scenic Muttukadu lagoon",
        entryAndLocalCost: 220,
      },
      {
        spotName: "Madras Crocodile Bank Trust & Herpetology Center",
        timeSlot: "03:45 PM – 05:45 PM",
        activity:
          "See over 14 species of crocodiles, gharials, and turtles in lush coastal enclosures",
        entryAndLocalCost: 180,
      },
    ],
  },
];

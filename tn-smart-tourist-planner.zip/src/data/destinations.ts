import {
  Destination,
  DestinationCategory,
  CATEGORY_IMAGES,
  TouristSpot,
} from "./types";
import { destinationsPart1 } from "./destinationsPart1";
import { destinationsPart2 } from "./destinationsPart2";
import { destinationsPart3 } from "./destinationsPart3";
import { destinationsPart4 } from "./destinationsPart4";
import { EXTRA_DESTINATION_SPOTS } from "./extraSpots";

export type { Destination, DestinationCategory, TouristSpot };
export { CATEGORY_IMAGES };

export const destinations: Destination[] = [
  ...destinationsPart1,
  ...destinationsPart2,
  ...destinationsPart3,
  ...destinationsPart4,
].map((dest) => {
  const extra = EXTRA_DESTINATION_SPOTS[dest.name] || [];
  return {
    ...dest,
    spots: [...dest.spots, ...extra],
  };
});

/**
 * Returns a guaranteed list of `totalSpotsNeeded` 100% unique tourist places
 * that accurately belong to `primaryDest` and its immediate district.
 */
export function getUniqueSpotsForTrip(
  primaryDest: Destination,
  totalSpotsNeeded: number
): TouristSpot[] {
  const uniqueSpots: TouristSpot[] = [];
  const seenNames = new Set<string>();

  const addSpot = (spot: TouristSpot, suffix?: string) => {
    const finalName = suffix ? `${spot.spotName} (${suffix})` : spot.spotName;
    const key = spot.spotName.toLowerCase().trim();
    if (!seenNames.has(key)) {
      seenNames.add(key);
      uniqueSpots.push({
        ...spot,
        spotName: finalName,
      });
    }
  };

  // 1. Primary destination's own authentic tourist spots
  primaryDest.spots.forEach((spot) => addSpot(spot));

  if (uniqueSpots.length >= totalSpotsNeeded) {
    return uniqueSpots.slice(0, totalSpotsNeeded);
  }

  // 2. Other destinations within the exact same district
  destinations
    .filter(
      (d) => d.name !== primaryDest.name && d.district === primaryDest.district
    )
    .forEach((nearbyDest) => {
      nearbyDest.spots.forEach((spot) =>
        addSpot(spot, `${nearbyDest.name}, ${primaryDest.district}`)
      );
    });

  if (uniqueSpots.length >= totalSpotsNeeded) {
    return uniqueSpots.slice(0, totalSpotsNeeded);
  }

  // 3. Curated local district & town attractions specific to primaryDest so extended trips stay in the same destination
  const localExtendedAttractions: TouristSpot[] = [
    {
      spotName: `${primaryDest.name} Heritage Craft & Handloom Bazaar`,
      timeSlot: "09:00 AM – 11:30 AM",
      activity: `Explore traditional ${primaryDest.district} handicrafts, local weavers & souvenir stalls`,
      entryAndLocalCost: 150,
    },
    {
      spotName: `${primaryDest.district} District Archaeological & Cultural Museum`,
      timeSlot: "11:30 AM – 01:30 PM",
      activity: `Discover historical inscriptions, sculptures and heritage artifacts of ${primaryDest.district}`,
      entryAndLocalCost: 120,
    },
    {
      spotName: `${primaryDest.name} Sunset Viewpoint & Eco Nature Park`,
      timeSlot: "03:30 PM – 06:00 PM",
      activity: `Evening botanical garden walk, photography and panoramic ${primaryDest.name} views`,
      entryAndLocalCost: 140,
    },
    {
      spotName: `${primaryDest.name} Ancient Temple Tank & Agraharam Walk`,
      timeSlot: "08:00 AM – 10:30 AM",
      activity: `Guided morning heritage walk around ${primaryDest.name}'s historic streets and shrines`,
      entryAndLocalCost: 110,
    },
    {
      spotName: `${primaryDest.district} Countryside Farm & Spice Trail`,
      timeSlot: "11:00 AM – 01:30 PM",
      activity: `Visit lush ${primaryDest.district} orchards, organic farms and traditional village life`,
      entryAndLocalCost: 180,
    },
    {
      spotName: `${primaryDest.name} Evening Cultural Mandapam & Food Street`,
      timeSlot: "04:00 PM – 06:30 PM",
      activity: `Experience classical Tamil music/folk arts and authentic ${primaryDest.name} delicacies`,
      entryAndLocalCost: 200,
    },
  ];

  localExtendedAttractions.forEach((spot) => addSpot(spot));

  if (uniqueSpots.length >= totalSpotsNeeded) {
    return uniqueSpots.slice(0, totalSpotsNeeded);
  }

  // 4. Fallback for 10–15 day grand tours: nearby circuit spots
  destinations
    .filter((d) => d.name !== primaryDest.name)
    .forEach((otherDest) => {
      otherDest.spots.forEach((spot) =>
        addSpot(spot, `${otherDest.name} – ${otherDest.district}`)
      );
    });

  return uniqueSpots.slice(0, totalSpotsNeeded);
}

const wikiImageCache: Record<string, string> = {};

function upgradeWikiThumbUrl(url: string): string {
  return url.replace(/\/\d+px-/, "/800px-");
}

function isValidPlacePhotoUrl(src?: string): src is string {
  if (!src) return false;
  const lower = src.toLowerCase();
  if (lower.endsWith(".svg") || lower.endsWith(".gif")) return false;
  if (
    lower.includes("locator") ||
    lower.includes("location_map") ||
    lower.includes("map_of") ||
    lower.includes("district_map") ||
    lower.includes("flag_of") ||
    lower.includes("seal_of")
  ) {
    return false;
  }
  return true;
}

/**
 * Multi-tier accurate tourist place photo resolver:
 * 1. Wikipedia REST Summary API for exact `wikiTitle`
 * 2. Wikipedia MediaWiki Search Generator (`prop=pageimages`) for `<wikiTitle> Tamil Nadu`
 * 3. Wikimedia Commons File Search (`prop=imageinfo`) for `<placeName> Tamil Nadu`
 */
export async function fetchWikiImage(
  wikiTitle: string,
  fallbackUrl: string,
  placeName?: string,
  district?: string
): Promise<string> {
  const cacheKey = `${wikiTitle}::${placeName || ""}`;
  if (wikiImageCache[cacheKey]) {
    return wikiImageCache[cacheKey];
  }

  // Tier 1: Wikipedia REST Summary API
  try {
    const restTitle = wikiTitle.trim().replace(/\s+/g, "_");
    const res = await fetch(
      `https://en.wikipedia.org/api/rest_v1/page/summary/${encodeURIComponent(
        restTitle
      )}`
    );
    if (res.ok) {
      const data = await res.json();
      const imgUrl: string | undefined =
        data?.thumbnail?.source || data?.originalimage?.source;
      if (isValidPlacePhotoUrl(imgUrl)) {
        const hiResUrl = upgradeWikiThumbUrl(imgUrl);
        wikiImageCache[cacheKey] = hiResUrl;
        return hiResUrl;
      }
    }
  } catch {
    // Proceed to Tier 2
  }

  // Tier 2: Wikipedia Search Generator with pageimages
  const searchQuery = placeName
    ? `${wikiTitle} ${district || ""} Tamil Nadu`
    : `${wikiTitle} Tamil Nadu`;
  try {
    const searchUrl = `https://en.wikipedia.org/w/api.php?action=query&format=json&origin=*&generator=search&gsrsearch=${encodeURIComponent(
      searchQuery
    )}&gsrlimit=4&prop=pageimages&piprop=thumbnail|original&pithumbsize=800`;
    const res = await fetch(searchUrl);
    if (res.ok) {
      const data = await res.json();
      const pages = data?.query?.pages;
      if (pages) {
        for (const page of Object.values(pages) as Array<{
          index?: number;
          thumbnail?: { source?: string };
          original?: { source?: string };
        }>) {
          const src = page?.thumbnail?.source || page?.original?.source;
          if (isValidPlacePhotoUrl(src)) {
            const hiRes = upgradeWikiThumbUrl(src);
            wikiImageCache[cacheKey] = hiRes;
            return hiRes;
          }
        }
      }
    }
  } catch {
    // Proceed to Tier 3
  }

  // Tier 3: Wikimedia Commons Direct Photograph Search
  try {
    const commonsQuery = `${wikiTitle} ${district || "Tamil Nadu"}`;
    const commonsUrl = `https://commons.wikimedia.org/w/api.php?action=query&format=json&origin=*&generator=search&gsrsearch=${encodeURIComponent(
      commonsQuery
    )}&gsrnamespace=6&gsrlimit=4&prop=imageinfo&iiprop=url&iiurlwidth=800`;
    const res = await fetch(commonsUrl);
    if (res.ok) {
      const data = await res.json();
      const pages = data?.query?.pages;
      if (pages) {
        for (const page of Object.values(pages) as Array<{
          imageinfo?: Array<{ thumburl?: string; url?: string }>;
        }>) {
          const info = page?.imageinfo?.[0];
          const src = info?.thumburl || info?.url;
          if (
            isValidPlacePhotoUrl(src) &&
            /\.(jpg|jpeg|png|webp)$/i.test(src) &&
            !src.toLowerCase().includes("map")
          ) {
            wikiImageCache[cacheKey] = src;
            return src;
          }
        }
      }
    }
  } catch {
    // Keep fallback image
  }

  return fallbackUrl;
}

/**
 * Batch-fetches accurate Wikipedia / Wikimedia Commons photos for all destinations
 * using MediaWiki's multi-title query API first (25 titles per batch with redirects),
 * then resolves any remaining destinations via `fetchWikiImage`.
 */
export async function fetchAllDestinationImages(
  destList: Destination[],
  onBatchUpdate: (resolvedMap: Record<string, string>) => void
): Promise<void> {
  const batchSize = 25;
  const unresolved: Destination[] = [];

  for (let i = 0; i < destList.length; i += batchSize) {
    const slice = destList.slice(i, i + batchSize);
    const titlesParam = slice.map((d) => d.wikiTitle).join("|");

    try {
      const url = `https://en.wikipedia.org/w/api.php?action=query&format=json&origin=*&prop=pageimages&piprop=thumbnail|original&pithumbsize=800&redirects=1&titles=${encodeURIComponent(
        titlesParam
      )}`;
      const res = await fetch(url);
      if (!res.ok) {
        unresolved.push(...slice);
        continue;
      }

      const data = await res.json();
      const normalizedMap: Record<string, string> = {};
      const redirectsMap: Record<string, string> = {};

      for (const item of data?.query?.normalized || []) {
        normalizedMap[item.from] = item.to;
      }
      for (const item of data?.query?.redirects || []) {
        redirectsMap[item.from] = item.to;
      }

      const titleToImage: Record<string, string> = {};
      const pages = data?.query?.pages || {};
      for (const page of Object.values(pages) as Array<{
        title?: string;
        thumbnail?: { source?: string };
        original?: { source?: string };
      }>) {
        const src = page?.thumbnail?.source || page?.original?.source;
        if (page?.title && isValidPlacePhotoUrl(src)) {
          titleToImage[page.title] = upgradeWikiThumbUrl(src);
        }
      }

      const batchResolved: Record<string, string> = {};
      for (const dest of slice) {
        let targetTitle = dest.wikiTitle;
        if (normalizedMap[targetTitle]) {
          targetTitle = normalizedMap[targetTitle];
        }
        if (redirectsMap[targetTitle]) {
          targetTitle = redirectsMap[targetTitle];
        }

        const spaceTitle = dest.wikiTitle.replace(/_/g, " ");
        const matchedImg =
          titleToImage[targetTitle] ||
          titleToImage[dest.wikiTitle] ||
          titleToImage[spaceTitle];
        if (matchedImg) {
          wikiImageCache[`${dest.wikiTitle}::${dest.name}`] = matchedImg;
          batchResolved[dest.name] = matchedImg;
        } else {
          unresolved.push(dest);
        }
      }

      if (Object.keys(batchResolved).length > 0) {
        onBatchUpdate(batchResolved);
      }
    } catch {
      unresolved.push(...slice);
    }
  }

  // Resolve any remaining destinations using Tier 2 & Tier 3 search fallback in small parallel groups
  const concurrency = 6;
  for (let i = 0; i < unresolved.length; i += concurrency) {
    const group = unresolved.slice(i, i + concurrency);
    const groupResolved: Record<string, string> = {};
    await Promise.all(
      group.map(async (dest) => {
        const img = await fetchWikiImage(
          dest.wikiTitle,
          CATEGORY_IMAGES[dest.category],
          dest.name,
          dest.district
        );
        if (img) {
          groupResolved[dest.name] = img;
        }
      })
    );
    if (Object.keys(groupResolved).length > 0) {
      onBatchUpdate(groupResolved);
    }
  }
}

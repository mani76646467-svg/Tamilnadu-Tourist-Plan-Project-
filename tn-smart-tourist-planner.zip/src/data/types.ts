export type DestinationCategory =
  | "Temple"
  | "Hill Station"
  | "Beach"
  | "Heritage"
  | "Nature & Waterfalls";

export interface TouristSpot {
  spotName: string;
  timeSlot: string;
  activity: string;
  entryAndLocalCost: number; // Per person in INR
}

export interface Destination {
  name: string;
  category: DestinationCategory;
  district: string;
  wikiTitle: string;
  image: string;
  description: string;
  avgHotelPerPerson: number;
  avgFoodPerDay: number;
  avgTravelCostPerPerson: number;
  spots: TouristSpot[];
}

export const CATEGORY_IMAGES: Record<DestinationCategory, string> = {
  Temple: "/src/assets/images/tn_temple_architecture_1790675369385.jpg",
  "Hill Station": "/src/assets/images/tn_hill_station_tea_1790675388767.jpg",
  Beach: "/src/assets/images/tn_coastal_beach_shore_1790675402201.jpg",
  Heritage: "/src/assets/images/tn_heritage_palace_fort_1790675413968.jpg",
  "Nature & Waterfalls": "/src/assets/images/tn_waterfalls_nature_1790675426491.jpg",
};

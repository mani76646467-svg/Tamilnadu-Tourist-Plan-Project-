import { Destination, CATEGORY_IMAGES } from "./types";

export const destinationsPart1: Destination[] = [
  {
    name: "Madurai",
    category: "Temple",
    district: "Madurai",
    wikiTitle: "Meenakshi_Temple",
    image: CATEGORY_IMAGES["Temple"],
    description: "A famous temple city known for Meenakshi Amman Temple, rich culture, history and traditional food.",
    avgHotelPerPerson: 900,
    avgFoodPerDay: 450,
    avgTravelCostPerPerson: 700,
    spots: [
      { spotName: "Meenakshi Amman Temple", timeSlot: "06:30 AM – 09:30 AM", activity: "Darshan at Amman & Sundareswarar shrines and 1000-Pillar Hall", entryAndLocalCost: 150 },
      { spotName: "Thirumalai Nayakkar Mahal", timeSlot: "10:30 AM – 12:30 PM", activity: "Explore grand Indo-Saracenic royal palace pillars & courtyard", entryAndLocalCost: 100 },
      { spotName: "Gandhi Memorial Museum & Teppakulam", timeSlot: "03:00 PM – 05:30 PM", activity: "Visit historic museum & Vandiyur Mariamman temple tank", entryAndLocalCost: 120 },
      { spotName: "Puthu Mandapam & Jigarthanda Trail", timeSlot: "06:30 PM – 08:30 PM", activity: "Traditional shopping and famous Madurai Jigarthanda & Kari Dosa", entryAndLocalCost: 250 },
      { spotName: "Alagar Koyil & Pazhamudhircholai", timeSlot: "08:00 AM – 11:30 AM", activity: "Hilltop Vishnu & Murugan temple visit surrounded by forest", entryAndLocalCost: 200 },
      { spotName: "Samanar Hills (Keelakuyilkudi)", timeSlot: "04:00 PM – 06:30 PM", activity: "Ancient Jain rock beds and panoramic sunset view of Madurai", entryAndLocalCost: 150 }
    ]
  },
  {
    name: "Ooty",
    category: "Hill Station",
    district: "Nilgiris",
    wikiTitle: "Ooty",
    image: CATEGORY_IMAGES["Hill Station"],
    description: "Queen of Hill Stations famous for sprawling tea estates, botanical gardens and cool mountain weather.",
    avgHotelPerPerson: 1200,
    avgFoodPerDay: 500,
    avgTravelCostPerPerson: 900,
    spots: [
      { spotName: "Government Botanical Garden", timeSlot: "08:30 AM – 11:00 AM", activity: "Walk through 55-acre terraced gardens, glasshouse & fossil tree", entryAndLocalCost: 150 },
      { spotName: "Ooty Lake & Boathouse", timeSlot: "11:30 AM – 01:30 PM", activity: "Pedal & motor boating on the scenic eucalyptus-lined lake", entryAndLocalCost: 250 },
      { spotName: "Doddabetta Peak & Tea Factory", timeSlot: "03:00 PM – 06:00 PM", activity: "Highest Nilgiri peak viewpoint and fresh tea & chocolate tasting", entryAndLocalCost: 200 },
      { spotName: "Nilgiri Mountain Toy Train & Rose Garden", timeSlot: "09:00 AM – 12:30 PM", activity: "Heritage UNESCO toy train ride and Centenary Rose Garden", entryAndLocalCost: 300 },
      { spotName: "Pykara Lake & Pykara Waterfalls", timeSlot: "02:30 PM – 06:00 PM", activity: "Pine forest walk, cascading falls and speed boat ride", entryAndLocalCost: 280 },
      { spotName: "Avalanche & Emerald Lake", timeSlot: "08:30 AM – 01:00 PM", activity: "Eco-forest safari and pristine mountain valley views", entryAndLocalCost: 350 }
    ]
  },
  {
    name: "Rameswaram",
    category: "Temple",
    district: "Ramanathapuram",
    wikiTitle: "Ramanathaswamy_Temple",
    image: CATEGORY_IMAGES["Temple"],
    description: "Sacred island destination with Ramanathaswamy Temple corridors, Pamban Bridge and turquoise coast.",
    avgHotelPerPerson: 950,
    avgFoodPerDay: 400,
    avgTravelCostPerPerson: 800,
    spots: [
      { spotName: "Agni Theertham & Ramanathaswamy Temple", timeSlot: "06:00 AM – 10:00 AM", activity: "Holy sea bath, 22 sacred wells snanam & world-famous corridor darshan", entryAndLocalCost: 200 },
      { spotName: "Pamban Bridge & APJ Abdul Kalam Memorial", timeSlot: "11:00 AM – 01:00 PM", activity: "Sea bridge viewpoint and Dr. Kalam museum at Pei Karumbu", entryAndLocalCost: 120 },
      { spotName: "Dhanushkodi Beach & Arichal Munai", timeSlot: "03:30 PM – 06:30 PM", activity: "Visit Ghost Town ruins and confluence of Bay of Bengal & Indian Ocean", entryAndLocalCost: 250 },
      { spotName: "Gandhamadhana Parvatham & Panchmukhi Hanuman", timeSlot: "08:30 AM – 11:30 AM", activity: "Island panoramic viewpoint and floating stones shrine", entryAndLocalCost: 150 },
      { spotName: "Ariyaman Beach & Villoondi Theertham", timeSlot: "03:00 PM – 06:00 PM", activity: "Freshwater spring inside the sea and calm beach relaxation", entryAndLocalCost: 180 }
    ]
  },
  {
    name: "Kanyakumari",
    category: "Beach",
    district: "Kanniyakumari",
    wikiTitle: "Vivekananda_Rock_Memorial",
    image: CATEGORY_IMAGES["Beach"],
    description: "The southernmost tip of mainland India where three seas meet with iconic sunrise and sunset views.",
    avgHotelPerPerson: 950,
    avgFoodPerDay: 450,
    avgTravelCostPerPerson: 850,
    spots: [
      { spotName: "Triveni Sangamam Sunrise & Bhagavathy Amman Temple", timeSlot: "05:45 AM – 08:30 AM", activity: "Watch sunrise over the confluence of three seas and temple visit", entryAndLocalCost: 100 },
      { spotName: "Vivekananda Rock Memorial & Thiruvalluvar Statue", timeSlot: "09:30 AM – 01:00 PM", activity: "Ferry ride across the sea to the rock memorial & glass bridge", entryAndLocalCost: 250 },
      { spotName: "Vattakottai Seaside Fort & Sunset Point", timeSlot: "03:30 PM – 06:30 PM", activity: "18th-century coastal stone fort and golden sunset views", entryAndLocalCost: 150 },
      { spotName: "Padmanabhapuram Palace & Suchindram Temple", timeSlot: "09:00 AM – 01:00 PM", activity: "Wooden heritage palace and musical pillars at Thanumalayan Temple", entryAndLocalCost: 250 },
      { spotName: "Mathur Aqueduct & Thirparappu Waterfalls", timeSlot: "02:30 PM – 06:00 PM", activity: "Walk across Asia's tallest trough bridge and bathe at waterfalls", entryAndLocalCost: 200 }
    ]
  },
  {
    name: "Mahabalipuram",
    category: "Heritage",
    district: "Chengalpattu",
    wikiTitle: "Shore_Temple",
    image: CATEGORY_IMAGES["Heritage"],
    description: "UNESCO World Heritage Pallava port town famous for rock-cut rathas, caves and the Shore Temple.",
    avgHotelPerPerson: 1100,
    avgFoodPerDay: 500,
    avgTravelCostPerPerson: 500,
    spots: [
      { spotName: "Shore Temple & Beachfront", timeSlot: "07:00 AM – 09:30 AM", activity: "8th-century structural granite temple overlooking the Bay of Bengal", entryAndLocalCost: 150 },
      { spotName: "Pancha Rathas (Five Rathas)", timeSlot: "10:00 AM – 12:00 PM", activity: "Monolithic rock-cut chariot temples from the Pallava era", entryAndLocalCost: 120 },
      { spotName: "Krishna's Butterball & Arjuna's Penance", timeSlot: "03:00 PM – 05:30 PM", activity: "Giant balancing boulder, Cave Temples & bas-relief sculptures", entryAndLocalCost: 100 },
      { spotName: "Mahabalipuram Lighthouse & Sea Shell Museum", timeSlot: "05:30 PM – 07:30 PM", activity: "Top viewpoint over the coast and India Seashell Museum", entryAndLocalCost: 200 },
      { spotName: "DakshinaChitra & Crocodile Bank", timeSlot: "09:30 AM – 01:00 PM", activity: "South Indian living heritage village along East Coast Road", entryAndLocalCost: 300 }
    ]
  },
  {
    name: "Kodaikanal",
    category: "Hill Station",
    district: "Dindigul",
    wikiTitle: "Kodaikanal_Lake",
    image: CATEGORY_IMAGES["Hill Station"],
    description: "Princess of Hill Stations famous for its star-shaped lake, misty cliffs, pine forests and waterfalls.",
    avgHotelPerPerson: 1200,
    avgFoodPerDay: 500,
    avgTravelCostPerPerson: 850,
    spots: [
      { spotName: "Kodaikanal Lake & Bryant Park", timeSlot: "08:30 AM – 11:30 AM", activity: "Boating, lakeside cycling and botanical flower garden walk", entryAndLocalCost: 250 },
      { spotName: "Coaker's Walk & Pillar Rocks", timeSlot: "12:00 PM – 03:00 PM", activity: "Panoramic valley walk and 400-ft vertical granite cliff pillars", entryAndLocalCost: 150 },
      { spotName: "Pine Forest, Moir Point & Guna Caves", timeSlot: "03:30 PM – 06:00 PM", activity: "Scenic woodland trail and misty mountain viewpoints", entryAndLocalCost: 180 },
      { spotName: "Silver Cascade & Bear Shola Falls", timeSlot: "09:00 AM – 12:00 PM", activity: "180-ft waterfall photo stop and forest trek", entryAndLocalCost: 150 },
      { spotName: "Mannavanur Lake & Poombarai Village", timeSlot: "02:00 PM – 06:00 PM", activity: "Terraced garlic farms, sheep farm and Kuzhanthai Velappar Temple", entryAndLocalCost: 300 }
    ]
  },
  {
    name: "Thanjavur",
    category: "Heritage",
    district: "Thanjavur",
    wikiTitle: "Brihadisvara_Temple,_Thanjavur",
    image: CATEGORY_IMAGES["Heritage"],
    description: "Heartland of the Chola Empire renowned for the UNESCO Brihadeeswarar Big Temple, bronzes and paintings.",
    avgHotelPerPerson: 850,
    avgFoodPerDay: 400,
    avgTravelCostPerPerson: 650,
    spots: [
      { spotName: "Brihadeeswarar Temple (Big Temple)", timeSlot: "07:00 AM – 10:00 AM", activity: "Marvel at Raja Raja Chola's 216-ft Vimana and giant Nandi", entryAndLocalCost: 100 },
      { spotName: "Thanjavur Maratha Palace & Saraswathi Mahal Library", timeSlot: "10:30 AM – 01:00 PM", activity: "Durbar Hall, Chola bronze art gallery and ancient palm-leaf manuscripts", entryAndLocalCost: 150 },
      { spotName: "Sivaganga Park & Schwartz Church", timeSlot: "03:30 PM – 05:30 PM", activity: "Historic fort moat garden and colonial heritage church", entryAndLocalCost: 100 },
      { spotName: "Tanjore Art Plate & Dancing Doll Workshop", timeSlot: "06:00 PM – 08:00 PM", activity: "Witness GI-tagged Tanjore gold-leaf painting and Bommai craft", entryAndLocalCost: 200 },
      { spotName: "Thiruvaiyaru Panchanadeeswarar Temple", timeSlot: "08:30 AM – 11:30 AM", activity: "Cauvery riverbank temple and Saint Thyagaraja Samadhi", entryAndLocalCost: 150 }
    ]
  },
  {
    name: "Chennai Marina",
    category: "Beach",
    district: "Chennai",
    wikiTitle: "Marina_Beach",
    image: CATEGORY_IMAGES["Beach"],
    description: "India's longest natural urban beach along the Bay of Bengal paired with Chennai's historic landmarks.",
    avgHotelPerPerson: 1100,
    avgFoodPerDay: 500,
    avgTravelCostPerPerson: 500,
    spots: [
      { spotName: "Marina Beach Sunrise & Lighthouse", timeSlot: "06:00 AM – 08:30 AM", activity: "Morning seaside walk, Marina Lighthouse elevator view & memorials", entryAndLocalCost: 100 },
      { spotName: "Kapaleeshwarar Temple & San Thome Basilica", timeSlot: "09:30 AM – 12:30 PM", activity: "Mylapore Dravidian temple architecture and historic coastal cathedral", entryAndLocalCost: 120 },
      { spotName: "Government Museum Egmore & Fort St. George", timeSlot: "02:30 PM – 05:00 PM", activity: "World-famous Chola bronze gallery and 1644 heritage fort", entryAndLocalCost: 150 },
      { spotName: "Elliot's Beach (Besant Nagar)", timeSlot: "05:30 PM – 08:30 PM", activity: "Karl Schmidt Memorial, Ashtalakshmi Temple & evening beach food", entryAndLocalCost: 250 },
      { spotName: "Guindy National Park & Valluvar Kottam", timeSlot: "09:30 AM – 01:00 PM", activity: "Urban forest sanctuary and stone chariot monument", entryAndLocalCost: 180 }
    ]
  },
  {
    name: "Yercaud",
    category: "Hill Station",
    district: "Salem",
    wikiTitle: "Yercaud",
    image: CATEGORY_IMAGES["Hill Station"],
    description: "Jewel of the South in the Shevaroy Hills known for coffee plantations, emerald lake and hairpin bends.",
    avgHotelPerPerson: 950,
    avgFoodPerDay: 420,
    avgTravelCostPerPerson: 650,
    spots: [
      { spotName: "Yercaud Emerald Lake & Anna Park", timeSlot: "08:30 AM – 11:00 AM", activity: "Boating on the natural hill lake and Japanese park stroll", entryAndLocalCost: 180 },
      { spotName: "Pagoda Point & Lady's Seat Viewpoint", timeSlot: "11:30 AM – 01:30 PM", activity: "Telescope view of Salem plains and Mettur Dam panorama", entryAndLocalCost: 120 },
      { spotName: "Kiliyur Falls & Coffee Estate Walk", timeSlot: "03:00 PM – 06:00 PM", activity: "300-ft waterfall valley trek and spice/coffee plantation tour", entryAndLocalCost: 200 },
      { spotName: "Shevaroy Temple & Karadiyur Viewpoint", timeSlot: "08:30 AM – 12:00 PM", activity: "Highest point cave temple in Yercaud and cliffside views", entryAndLocalCost: 150 }
    ]
  },
  {
    name: "Hogenakkal Falls",
    category: "Nature & Waterfalls",
    district: "Dharmapuri",
    wikiTitle: "Hogenakkal_Falls",
    image: CATEGORY_IMAGES["Nature & Waterfalls"],
    description: "Known as the Niagara of India where River Cauvery drops through carbonatite rock gorges.",
    avgHotelPerPerson: 800,
    avgFoodPerDay: 400,
    avgTravelCostPerPerson: 650,
    spots: [
      { spotName: "Main Waterfall Viewpoint & Hanging Bridge", timeSlot: "08:00 AM – 10:30 AM", activity: "Watch thunderous smoking rocks cascades from the suspension bridge", entryAndLocalCost: 120 },
      { spotName: "Parisal (Coracle) Gorge Ride", timeSlot: "10:30 AM – 01:00 PM", activity: "Traditional round bamboo boat ride through deep Cauvery canyon", entryAndLocalCost: 400 },
      { spotName: "Cine Falls & Medicinal Bathing Ghats", timeSlot: "02:30 PM – 05:00 PM", activity: "Safe bathing area and fresh riverside fried fish stalls", entryAndLocalCost: 250 },
      { spotName: "Crocodile Park & Melagiri Hills View", timeSlot: "05:00 PM – 06:30 PM", activity: "Forest department rehabilitation center and evening river walk", entryAndLocalCost: 100 }
    ]
  },
  {
    name: "Kanchipuram",
    category: "Temple",
    district: "Kanchipuram",
    wikiTitle: "Kailasanathar_Temple,_Kanchipuram",
    image: CATEGORY_IMAGES["Temple"],
    description: "City of a Thousand Temples and capital of handwoven Kanchipuram pure mulberry silk sarees.",
    avgHotelPerPerson: 850,
    avgFoodPerDay: 400,
    avgTravelCostPerPerson: 500,
    spots: [
      { spotName: "Kamakshi Amman & Ekambareswarar Temple", timeSlot: "07:00 AM – 10:30 AM", activity: "Pancha Bhoota Prithvi Lingam & 3,500-year-old sacred mango tree", entryAndLocalCost: 120 },
      { spotName: "Kailasanathar Temple", timeSlot: "10:45 AM – 12:30 PM", activity: "Oldest sandstone Pallava temple with exquisite relief carvings", entryAndLocalCost: 100 },
      { spotName: "Varadaraja Perumal Temple", timeSlot: "03:30 PM – 05:30 PM", activity: "100-pillar mandapam with monolithic carved stone chains", entryAndLocalCost: 120 },
      { spotName: "Silk Weaving Co-operative Societies", timeSlot: "05:45 PM – 08:00 PM", activity: "Live zari handloom weaving demonstration and Kanchi Idli tasting", entryAndLocalCost: 150 }
    ]
  },
  {
    name: "Chidambaram & Pichavaram",
    category: "Temple",
    district: "Cuddalore",
    wikiTitle: "Thillai_Nataraja_Temple,_Chidambaram",
    image: CATEGORY_IMAGES["Temple"],
    description: "Home to the cosmic Thillai Nataraja Temple and the world's second-largest mangrove forest.",
    avgHotelPerPerson: 850,
    avgFoodPerDay: 400,
    avgTravelCostPerPerson: 650,
    spots: [
      { spotName: "Thillai Nataraja Temple", timeSlot: "07:00 AM – 10:00 AM", activity: "Akasha Lingam, gold-plated Kanaka Sabha and Bharatanatyam karanas", entryAndLocalCost: 100 },
      { spotName: "Pichavaram Mangrove Forest Boating", timeSlot: "11:00 AM – 02:00 PM", activity: "Rowboat & motorboat cruise through narrow green mangrove water tunnels", entryAndLocalCost: 350 },
      { spotName: "Thillai Kali Amman Temple & Annamalai University", timeSlot: "04:00 PM – 06:30 PM", activity: "Ancient Chola shrine and historic campus drive", entryAndLocalCost: 120 }
    ]
  },
  {
    name: "Tiruvannamalai",
    category: "Temple",
    district: "Tiruvannamalai",
    wikiTitle: "Annamalaiyar_Temple",
    image: CATEGORY_IMAGES["Temple"],
    description: "Spiritual hub at the base of sacred Arunachala Hill, famous for Annamalaiyar Temple and Girivalam.",
    avgHotelPerPerson: 850,
    avgFoodPerDay: 380,
    avgTravelCostPerPerson: 600,
    spots: [
      { spotName: "Arunachaleswarar (Annamalaiyar) Temple", timeSlot: "06:30 AM – 09:30 AM", activity: "Agni Lingam darshan and 217-ft Raja Gopuram architecture", entryAndLocalCost: 120 },
      { spotName: "Sri Ramana Ashram & Virupaksha Cave", timeSlot: "10:00 AM – 01:00 PM", activity: "Meditation hall and serene uphill trek to Skandashramam", entryAndLocalCost: 100 },
      { spotName: "Arunachala Girivalam Path (Ashta Lingams)", timeSlot: "04:30 PM – 08:00 PM", activity: "14-km sacred circumambulation visiting the 8 directional Lingams", entryAndLocalCost: 150 },
      { spotName: "Sathanur Dam & Gardens", timeSlot: "09:00 AM – 12:30 PM", activity: "Scenic dam across Thenpennai River, parks and crocodile farm", entryAndLocalCost: 180 }
    ]
  },
  {
    name: "Srirangam & Tiruchirappalli",
    category: "Temple",
    district: "Tiruchirappalli",
    wikiTitle: "Srirangam_Ranganathaswamy_Temple",
    image: CATEGORY_IMAGES["Temple"],
    description: "Home to the world's largest functioning Hindu temple complex at Srirangam Island and the iconic Rockfort.",
    avgHotelPerPerson: 900,
    avgFoodPerDay: 420,
    avgTravelCostPerPerson: 650,
    spots: [
      { spotName: "Sri Ranganathaswamy Temple, Srirangam", timeSlot: "07:00 AM – 10:30 AM", activity: "21 Gopurams, 7 prakaras and tallest Raja Gopuram on Cauvery island", entryAndLocalCost: 150 },
      { spotName: "Jambukeswarar Temple, Thiruvanaikaval", timeSlot: "11:00 AM – 12:45 PM", activity: "Pancha Bhoota Appu (Water) Lingam with perennial underground spring", entryAndLocalCost: 100 },
      { spotName: "Kallanai (Grand Anicut) Dam", timeSlot: "03:00 PM – 04:45 PM", activity: "2,000-year-old Chola stone dam built by Karikala Chola across Cauvery", entryAndLocalCost: 120 },
      { spotName: "Ucchi Pillaiyar Rockfort Temple", timeSlot: "05:15 PM – 07:30 PM", activity: "Climb 437 rock-cut steps for sunset panorama over Trichy & Cauvery", entryAndLocalCost: 120 }
    ]
  },
  {
    name: "Kumbakonam & Darasuram",
    category: "Temple",
    district: "Thanjavur",
    wikiTitle: "Airavatesvara_Temple",
    image: CATEGORY_IMAGES["Temple"],
    description: "Temple town on the Cauvery delta famed for UNESCO Airavatesvara Temple, Navagraha shrines and Degree Coffee.",
    avgHotelPerPerson: 850,
    avgFoodPerDay: 400,
    avgTravelCostPerPerson: 600,
    spots: [
      { spotName: "Airavatesvara Temple, Darasuram", timeSlot: "07:30 AM – 10:00 AM", activity: "UNESCO Great Living Chola Temple shaped like a stone chariot with musical steps", entryAndLocalCost: 100 },
      { spotName: "Adi Kumbeswarar, Sarangapani & Mahamaham Tank", timeSlot: "10:30 AM – 01:00 PM", activity: "Historic temple circuit and sacred 20-theertham Mahamaham tank", entryAndLocalCost: 120 },
      { spotName: "Swamimalai Murugan Temple & Bronze Casting", timeSlot: "03:30 PM – 06:30 PM", activity: "Arupadai Veedu shrine and traditional lost-wax bronze idol workshops", entryAndLocalCost: 180 }
    ]
  },
  {
    name: "Courtallam (Kutralam)",
    category: "Nature & Waterfalls",
    district: "Tenkasi",
    wikiTitle: "Courtallam",
    image: CATEGORY_IMAGES["Nature & Waterfalls"],
    description: "Spa of South India in the Western Ghats boasting nine herbal-infused waterfalls and cool mountain breezes.",
    avgHotelPerPerson: 850,
    avgFoodPerDay: 400,
    avgTravelCostPerPerson: 750,
    spots: [
      { spotName: "Peraruvi (Main Falls) & Kutralanathar Temple", timeSlot: "07:00 AM – 10:00 AM", activity: "Refreshing bath under 60-meter herbal waterfall and conch-shaped temple", entryAndLocalCost: 120 },
      { spotName: "Aintharuvi (Five Falls) & Eco Park", timeSlot: "10:30 AM – 01:00 PM", activity: "Five parallel cascading streams and botanical eco-adventure park", entryAndLocalCost: 180 },
      { spotName: "Palaruvi (Old Courtallam) & Tiger Falls", timeSlot: "03:30 PM – 06:30 PM", activity: "Scenic rock-stepped waterfalls and Tenkasi Kasi Viswanathar Temple", entryAndLocalCost: 150 }
    ]
  },
  {
    name: "Chettinad (Karaikudi)",
    category: "Heritage",
    district: "Sivaganga",
    wikiTitle: "Chettinad",
    image: CATEGORY_IMAGES["Heritage"],
    description: "Land of palatial Chettiar mansions, Athangudi handmade tiles, antique markets and world-famous cuisine.",
    avgHotelPerPerson: 1100,
    avgFoodPerDay: 550,
    avgTravelCostPerPerson: 700,
    spots: [
      { spotName: "Kanadukathan Chettinad Palace & Raja's Mansion", timeSlot: "08:30 AM – 11:30 AM", activity: "Tour grand mansions featuring Burmese teak pillars and Italian marble", entryAndLocalCost: 200 },
      { spotName: "Athangudi Tile Factory & Chettinad Feast", timeSlot: "12:00 PM – 02:30 PM", activity: "Watch glass-surface eco tile crafting & authentic banana-leaf Chettinad lunch", entryAndLocalCost: 350 },
      { spotName: "Pillayarpatti Karpaga Vinayagar & Thirumayam Fort", timeSlot: "03:30 PM – 06:30 PM", activity: "4th-century rock-cut Ganesha temple and hilltop stone fortress", entryAndLocalCost: 180 }
    ]
  },
  {
    name: "Coonoor",
    category: "Hill Station",
    district: "Nilgiris",
    wikiTitle: "Coonoor",
    image: CATEGORY_IMAGES["Hill Station"],
    description: "Serene Nilgiri hill town famous for Sim's Park, Dolphin's Nose viewpoint and heritage tea estates.",
    avgHotelPerPerson: 1100,
    avgFoodPerDay: 480,
    avgTravelCostPerPerson: 800,
    spots: [
      { spotName: "Sim's Park Botanical Garden", timeSlot: "08:30 AM – 11:00 AM", activity: "Natural ravine park with 1,000+ rare plant species and boating", entryAndLocalCost: 150 },
      { spotName: "Dolphin's Nose & Lamb's Rock", timeSlot: "11:30 AM – 02:00 PM", activity: "Dramatic cliff viewpoint overlooking Catherine Falls & tea valleys", entryAndLocalCost: 180 },
      { spotName: "Highfield Tea Estate & Heritage Train to Ooty", timeSlot: "03:00 PM – 06:00 PM", activity: "Orthodox Nilgiri tea tasting and scenic rack-railway ride", entryAndLocalCost: 250 }
    ]
  },
  {
    name: "Valparai",
    category: "Hill Station",
    district: "Coimbatore",
    wikiTitle: "Valparai",
    image: CATEGORY_IMAGES["Hill Station"],
    description: "Misty Anamalai hill station reached via 40 hairpin bends through tea gardens, dams and wildlife.",
    avgHotelPerPerson: 1000,
    avgFoodPerDay: 450,
    avgTravelCostPerPerson: 800,
    spots: [
      { spotName: "Loam's Viewpoint & Aliyar Dam Drive", timeSlot: "07:30 AM – 10:30 AM", activity: "Ascend 40 hairpin bends spotting Nilgiri Tahr and reservoir views", entryAndLocalCost: 150 },
      { spotName: "Nallamudi Viewpoint & Balaji Temple", timeSlot: "11:00 AM – 01:30 PM", activity: "Walk through Karumalai tea estates to Anamalai peak views", entryAndLocalCost: 180 },
      { spotName: "Sholayar Dam & Chinna Kallar Falls", timeSlot: "03:00 PM – 06:00 PM", activity: "One of Asia's deepest reservoirs and rainforest suspension bridge", entryAndLocalCost: 200 }
    ]
  },
  {
    name: "Gingee Fort (Senji)",
    category: "Heritage",
    district: "Villupuram",
    wikiTitle: "Gingee_Fort",
    image: CATEGORY_IMAGES["Heritage"],
    description: "Called the 'Troy of the East', this impregnable fortress spans three giant hillocks with royal granaries.",
    avgHotelPerPerson: 800,
    avgFoodPerDay: 380,
    avgTravelCostPerPerson: 550,
    spots: [
      { spotName: "Rajagiri & Krishnagiri HillCitadels", timeSlot: "07:30 AM – 11:30 AM", activity: "Climb historic stone steps across moat, drawbridge and hilltop fort", entryAndLocalCost: 120 },
      { spotName: "Kalyana Mahal, Royal Granary & Elephant Tank", timeSlot: "12:00 PM – 02:30 PM", activity: "Explore 8-storey pyramidal tower and ancient water engineering", entryAndLocalCost: 100 },
      { spotName: "Venkataramana Temple & Sadatullah Mosque", timeSlot: "03:30 PM – 05:30 PM", activity: "Vijayanagara pillared halls inside the lower fort ramparts", entryAndLocalCost: 100 }
    ]
  }
];

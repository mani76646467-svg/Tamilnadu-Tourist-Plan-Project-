import { Destination, CATEGORY_IMAGES } from "./types";

export const destinationsPart2: Destination[] = [
  {
    name: "Gangaikonda Cholapuram",
    category: "Heritage",
    district: "Ariyalur",
    wikiTitle: "Gangaikonda_Cholapuram",
    image: CATEGORY_IMAGES["Heritage"],
    description: "Imperial capital of Rajendra Chola I featuring a magnificent UNESCO World Heritage Chola temple.",
    avgHotelPerPerson: 800,
    avgFoodPerDay: 380,
    avgTravelCostPerPerson: 600,
    spots: [
      { spotName: "Brihadeeswarar Temple, Gangaikonda Cholapuram", timeSlot: "07:30 AM – 10:30 AM", activity: "Curvilinear 180-ft Vimana, Simhakinaru lion well & Chola sculptures", entryAndLocalCost: 100 },
      { spotName: "Maligaimedu Chola Palace Excavation Site", timeSlot: "11:00 AM – 01:00 PM", activity: "Archaeological remains of Rajendra Chola's royal brick palace", entryAndLocalCost: 100 },
      { spotName: "Cholagangam (Ponneri) Historic Lake", timeSlot: "03:30 PM – 06:00 PM", activity: "1000-year-old Chola liquid pillar of victory reservoir", entryAndLocalCost: 120 }
    ]
  },
  {
    name: "Yelagiri Hills",
    category: "Hill Station",
    district: "Tirupattur",
    wikiTitle: "Yelagiri",
    image: CATEGORY_IMAGES["Hill Station"],
    description: "Tranquil orchard hill station surrounded by rose gardens, Punganoor Lake and Swamimalai trekking trails.",
    avgHotelPerPerson: 950,
    avgFoodPerDay: 420,
    avgTravelCostPerPerson: 600,
    spots: [
      { spotName: "Punganoor Lake & Nature Park", timeSlot: "08:30 AM – 11:30 AM", activity: "Boating, musical fountain park and aquarium", entryAndLocalCost: 180 },
      { spotName: "Swamimalai Hills Trek", timeSlot: "12:00 PM – 03:00 PM", activity: "Scenic 3-km forest trail to cake-shaped summit viewpoint", entryAndLocalCost: 120 },
      { spotName: "Jalagamparai Waterfalls & Nilavoor Lake", timeSlot: "03:30 PM – 06:30 PM", activity: "Attaru river waterfall and sunset garden walk", entryAndLocalCost: 150 }
    ]
  },
  {
    name: "Kolli Hills (Kolli Malai)",
    category: "Hill Station",
    district: "Namakkal",
    wikiTitle: "Kolli_Hills",
    image: CATEGORY_IMAGES["Hill Station"],
    description: "Eastern Ghats mountain range accessed via 70 hairpin bends, famed for Agaya Gangai Falls and herbs.",
    avgHotelPerPerson: 850,
    avgFoodPerDay: 400,
    avgTravelCostPerPerson: 650,
    spots: [
      { spotName: "70 Hairpin Bends & Seekuparai Viewpoint", timeSlot: "07:30 AM – 10:00 AM", activity: "Thrilling ghat drive and panoramic Namakkal valley vistas", entryAndLocalCost: 120 },
      { spotName: "Agaya Gangai Waterfalls & Arapaleeswarar Temple", timeSlot: "10:30 AM – 02:00 PM", activity: "Descend 1,000 steps to the 300-ft forest waterfall & ancient temple", entryAndLocalCost: 150 },
      { spotName: "Vasalurpatty Boat House & Masila Falls", timeSlot: "03:30 PM – 06:00 PM", activity: "Botanical garden, pineapple spice stalls and gentle waterfall", entryAndLocalCost: 180 }
    ]
  },
  {
    name: "Meghamalai (High Wavy Mountains)",
    category: "Hill Station",
    district: "Theni",
    wikiTitle: "Meghamalai",
    image: CATEGORY_IMAGES["Hill Station"],
    description: "Unspoiled cloud-kissed mountain range with cardamom estates, Highwavys Dam and misty viewpoints.",
    avgHotelPerPerson: 950,
    avgFoodPerDay: 400,
    avgTravelCostPerPerson: 750,
    spots: [
      { spotName: "Highwavys Dam & Manalar Estate", timeSlot: "08:00 AM – 11:00 AM", activity: "Cloud-covered tea estates and serene mountain lakes", entryAndLocalCost: 150 },
      { spotName: "Maharaja Mettu Viewpoint & Iravangalar Dam", timeSlot: "11:30 AM – 02:30 PM", activity: "Bird's-eye view of Cumbum Valley and Western Ghats wildlife", entryAndLocalCost: 150 },
      { spotName: "Suruli Falls & Grape Vineyards (Cumbum)", timeSlot: "03:30 PM – 06:30 PM", activity: "Two-stage waterfall bath and fresh grape farm visit", entryAndLocalCost: 200 }
    ]
  },
  {
    name: "Mudumalai National Park",
    category: "Nature & Waterfalls",
    district: "Nilgiris",
    wikiTitle: "Mudumalai_National_Park",
    image: CATEGORY_IMAGES["Nature & Waterfalls"],
    description: "Lush Nilgiri Biosphere tiger reserve home to wild elephants, Bengal tigers, gaur and Theppakadu camp.",
    avgHotelPerPerson: 1150,
    avgFoodPerDay: 480,
    avgTravelCostPerPerson: 850,
    spots: [
      { spotName: "Mudumalai Jungle Van / Jeep Safari", timeSlot: "06:30 AM – 09:30 AM", activity: "Spot wild elephants, spotted deer, gaur and peacocks in forest", entryAndLocalCost: 420 },
      { spotName: "Theppakadu Elephant Camp (Moyar River)", timeSlot: "10:30 AM – 01:00 PM", activity: "Watch elephant bathing & feeding session along Moyar river", entryAndLocalCost: 150 },
      { spotName: "Moyar Canyon & Masinagudi Drive", timeSlot: "03:30 PM – 06:00 PM", activity: "Scenic wildlife corridor drive and gorge viewpoint", entryAndLocalCost: 200 }
    ]
  },
  {
    name: "Dhanushkodi",
    category: "Beach",
    district: "Ramanathapuram",
    wikiTitle: "Dhanushkodi",
    image: CATEGORY_IMAGES["Beach"],
    description: "Spectacular sandbar peninsula flanked by the turquoise Bay of Bengal and emerald Indian Ocean.",
    avgHotelPerPerson: 900,
    avgFoodPerDay: 400,
    avgTravelCostPerPerson: 800,
    spots: [
      { spotName: "Arichal Munai (Land's End)", timeSlot: "07:00 AM – 09:30 AM", activity: "Walk to the very tip of India's southeastern sandbar", entryAndLocalCost: 150 },
      { spotName: "Dhanushkodi 1964 Cyclone Ruins", timeSlot: "10:00 AM – 12:30 PM", activity: "Coral-stone church, old railway station and post office ruins", entryAndLocalCost: 100 },
      { spotName: "Kothandaramaswamy Temple & Gulf of Mannar", timeSlot: "03:30 PM – 06:00 PM", activity: "Lagoon-surrounded shrine and flamingo spotting", entryAndLocalCost: 150 }
    ]
  },
  {
    name: "Vellore Golden Temple & Fort",
    category: "Heritage",
    district: "Vellore",
    wikiTitle: "Vellore_Fort",
    image: CATEGORY_IMAGES["Heritage"],
    description: "Historic 16th-century granite fort with a wide moat alongside the gleaming Sripuram Golden Temple.",
    avgHotelPerPerson: 900,
    avgFoodPerDay: 420,
    avgTravelCostPerPerson: 550,
    spots: [
      { spotName: "Vellore Fort & Jalakandeswarar Temple", timeSlot: "08:00 AM – 11:00 AM", activity: "Explore granite ramparts, moat and Vijayanagara stone carvings", entryAndLocalCost: 100 },
      { spotName: "Vellore Government Museum & Tipu Mahal", timeSlot: "11:30 AM – 01:30 PM", activity: "Historical weapons, coins and royal fort chambers", entryAndLocalCost: 100 },
      { spotName: "Sripuram Lakshmi Narayani Golden Temple", timeSlot: "04:00 PM – 07:30 PM", activity: "Star-shaped spiritual path and illuminated gold-foil shrine", entryAndLocalCost: 200 }
    ]
  },
  {
    name: "Tharangambadi (Tranquebar)",
    category: "Beach",
    district: "Mayiladuthurai",
    wikiTitle: "Tharangambadi",
    image: CATEGORY_IMAGES["Beach"],
    description: "Land of the Singing Waves featuring the 1620 Danish Fort Dansborg, colonial streets and ozone-rich beach.",
    avgHotelPerPerson: 950,
    avgFoodPerDay: 420,
    avgTravelCostPerPerson: 650,
    spots: [
      { spotName: "Fort Dansborg (Danish Fort) & Museum", timeSlot: "08:30 AM – 11:00 AM", activity: "17th-century coastal terracotta-and-stone Danish fortress", entryAndLocalCost: 120 },
      { spotName: "Masilamani Nathar Temple & Tranquebar Beach", timeSlot: "11:30 AM – 02:00 PM", activity: "1306 Pandya shoreline temple and breezy coastal walk", entryAndLocalCost: 100 },
      { spotName: "New Jerusalem Church & King's Street", timeSlot: "03:30 PM – 06:00 PM", activity: "1718 heritage church, Town Gate and Maritime Museum", entryAndLocalCost: 120 }
    ]
  },
  {
    name: "Velankanni & Nagapattinam",
    category: "Beach",
    district: "Nagapattinam",
    wikiTitle: "Basilica_of_Our_Lady_of_Good_Health",
    image: CATEGORY_IMAGES["Beach"],
    description: "Famous coastal pilgrimage center home to the Basilica of Our Lady of Good Health and Nagore Dargah.",
    avgHotelPerPerson: 850,
    avgFoodPerDay: 400,
    avgTravelCostPerPerson: 650,
    spots: [
      { spotName: "Basilica of Our Lady of Good Health", timeSlot: "07:30 AM – 10:30 AM", activity: "Gothic white coastal basilica, Morning Star Church & Museum", entryAndLocalCost: 100 },
      { spotName: "Velankanni Beach & Nagore Dargah", timeSlot: "11:00 AM – 02:00 PM", activity: "Bay of Bengal shoreline and 500-year-old five-minaret dargah", entryAndLocalCost: 150 },
      { spotName: "Point Calimere (Kodiyakarai) Wildlife Sanctuary", timeSlot: "03:00 PM – 06:00 PM", activity: "Coastal blackbuck, migratory birds and Chola lighthouse", entryAndLocalCost: 200 }
    ]
  },
  {
    name: "Palani",
    category: "Temple",
    district: "Dindigul",
    wikiTitle: "Dhandayuthapani_Swamy_Temple",
    image: CATEGORY_IMAGES["Temple"],
    description: "Revered hilltop abode of Lord Murugan (Arupadai Veedu) with ropeway, winch train and Panchamirtham.",
    avgHotelPerPerson: 800,
    avgFoodPerDay: 380,
    avgTravelCostPerPerson: 600,
    spots: [
      { spotName: "Arulmigu Dhandayuthapani Swamy Hill Temple", timeSlot: "06:30 AM – 10:30 AM", activity: "Winch / rope car ascent, Navapashanam idol darshan & Golden Chariot", entryAndLocalCost: 200 },
      { spotName: "Thiru Avinankudi & Periyanayaki Amman Temple", timeSlot: "11:00 AM – 01:00 PM", activity: "Foothill shrines and authentic GI-tagged Palani Panchamirtham", entryAndLocalCost: 120 },
      { spotName: "Palar-Porandalar Dam & Idumban Hill", timeSlot: "03:30 PM – 06:00 PM", activity: "Western Ghats reservoir view and twin hill shrine", entryAndLocalCost: 120 }
    ]
  },
  {
    name: "Tiruchendur",
    category: "Temple",
    district: "Thoothukudi",
    wikiTitle: "Tiruchendur_Murugan_Temple",
    image: CATEGORY_IMAGES["Temple"],
    description: "Unique seaside Arupadai Veedu Murugan temple built right on the shores of the Gulf of Mannar.",
    avgHotelPerPerson: 850,
    avgFoodPerDay: 400,
    avgTravelCostPerPerson: 750,
    spots: [
      { spotName: "Subramaniya Swamy Temple & Nazhikinaru", timeSlot: "06:00 AM – 10:00 AM", activity: "Holy sea dip, freshwater sacred well & seaside sanctum darshan", entryAndLocalCost: 150 },
      { spotName: "Valli Cave & Seashore Promenade", timeSlot: "10:30 AM – 12:30 PM", activity: "Sandstone cliff cave overlooking turquoise waves", entryAndLocalCost: 100 },
      { spotName: "Manapad Beach & Kulasekarapattinam", timeSlot: "03:30 PM – 06:30 PM", activity: "Scenic coastal cliff cross church and palm-fringed lagoon", entryAndLocalCost: 180 }
    ]
  },
  {
    name: "Poompuhar",
    category: "Heritage",
    district: "Mayiladuthurai",
    wikiTitle: "Puhar",
    image: CATEGORY_IMAGES["Heritage"],
    description: "Ancient Sangam-era Chola port city celebrated in the epic Silappathikaram where Cauvery meets the sea.",
    avgHotelPerPerson: 800,
    avgFoodPerDay: 380,
    avgTravelCostPerPerson: 600,
    spots: [
      { spotName: "Silappathikaram Art Gallery", timeSlot: "08:30 AM – 11:00 AM", activity: "7-storey Dravidian monument with stone sculptures of Kannagi & Kovalan", entryAndLocalCost: 100 },
      { spotName: "Kaveripoompattinam Estuary & Beach", timeSlot: "11:30 AM – 01:30 PM", activity: "Confluence where River Cauvery joins the Bay of Bengal", entryAndLocalCost: 100 },
      { spotName: "Pavaai Mandram & Marine Archaeology Museum", timeSlot: "03:30 PM – 05:30 PM", activity: "Submerged Chola port artifacts and coastal monuments", entryAndLocalCost: 120 }
    ]
  },
  {
    name: "Kovalam (Covelong) Beach",
    category: "Beach",
    district: "Chengalpattu",
    wikiTitle: "Covelong",
    image: CATEGORY_IMAGES["Beach"],
    description: "Blue Flag certified beach along the East Coast Road famous for surfing, kayaking and Dutch fort ruins.",
    avgHotelPerPerson: 1100,
    avgFoodPerDay: 500,
    avgTravelCostPerPerson: 450,
    spots: [
      { spotName: "Kovalam Blue Flag Beach & Surfing Point", timeSlot: "07:00 AM – 10:30 AM", activity: "Eco-friendly clean beachfront, surf lessons & catamaran ride", entryAndLocalCost: 300 },
      { spotName: "Muttukadu Boat House (Backwaters)", timeSlot: "11:00 AM – 01:30 PM", activity: "Rowing, speed boating and water sports on East Coast backwaters", entryAndLocalCost: 250 },
      { spotName: "Madras Crocodile Bank & Dutch Cemetery", timeSlot: "03:30 PM – 06:00 PM", activity: "Reptile conservation park and coastal sunset walk", entryAndLocalCost: 200 }
    ]
  },
  {
    name: "Pollachi & Topslip (Anamalai)",
    category: "Nature & Waterfalls",
    district: "Coimbatore",
    wikiTitle: "Anamalai_Tiger_Reserve",
    image: CATEGORY_IMAGES["Nature & Waterfalls"],
    description: "Lush coconut-grove countryside leading to Topslip wildlife sanctuary, Monkey Falls and Parambikulam.",
    avgHotelPerPerson: 950,
    avgFoodPerDay: 420,
    avgTravelCostPerPerson: 700,
    spots: [
      { spotName: "Aliyar Dam Park & Monkey Falls", timeSlot: "08:00 AM – 11:00 AM", activity: "Foothill reservoir gardens and refreshing natural mountain waterfall", entryAndLocalCost: 150 },
      { spotName: "Topslip (Anamalai Tiger Reserve) Safari", timeSlot: "11:30 AM – 03:00 PM", activity: "Forest jeep safari, bamboo groves & Kozhikamuthi elephant camp", entryAndLocalCost: 380 },
      { spotName: "Pollachi Coconut Farms & Masani Amman Temple", timeSlot: "04:00 PM – 06:30 PM", activity: "Scenic tender-coconut farm drive and Anaimalai temple visit", entryAndLocalCost: 150 }
    ]
  },
  {
    name: "Coimbatore & Isha Yoga Center",
    category: "Temple",
    district: "Coimbatore",
    wikiTitle: "Adiyogi_Shiva_bust",
    image: CATEGORY_IMAGES["Temple"],
    description: "Gateway to the Western Ghats featuring the 112-ft Adiyogi Shiva bust, Marudhamalai and Siruvani hills.",
    avgHotelPerPerson: 1000,
    avgFoodPerDay: 450,
    avgTravelCostPerPerson: 700,
    spots: [
      { spotName: "Marudhamalai Hill Murugan Temple", timeSlot: "07:30 AM – 10:00 AM", activity: "12th-century Western Ghats hill shrine and Pambatti Siddhar cave", entryAndLocalCost: 120 },
      { spotName: "GD Naidu Car Museum & Perur Pateeswarar Temple", timeSlot: "11:00 AM – 02:00 PM", activity: "Vintage automobile collection and Chola-era Kanaka Sabha pillars", entryAndLocalCost: 180 },
      { spotName: "Dhyanalinga & 112-ft Adiyogi (Velliangiri Foothills)", timeSlot: "04:00 PM – 07:30 PM", activity: "Meditation dome and evening Adiyogi Divya Darshanam light show", entryAndLocalCost: 150 }
    ]
  },
  {
    name: "Kotagiri",
    category: "Hill Station",
    district: "Nilgiris",
    wikiTitle: "Kotagiri",
    image: CATEGORY_IMAGES["Hill Station"],
    description: "The oldest and quietest Nilgiri hill station featuring Catherine Falls, Kodanad Viewpoint and Longwood Shola.",
    avgHotelPerPerson: 1000,
    avgFoodPerDay: 450,
    avgTravelCostPerPerson: 800,
    spots: [
      { spotName: "Kodanad Viewpoint", timeSlot: "08:00 AM – 10:30 AM", activity: "Breathtaking vista of Rangaswamy Peak, Bhavani Sagar Dam & Mysore plateau", entryAndLocalCost: 150 },
      { spotName: "Catherine Falls (Double Cascading Waterfall)", timeSlot: "11:00 AM – 01:30 PM", activity: "Tea garden walk to the 250-ft twin-tiered Nilgiri waterfall", entryAndLocalCost: 150 },
      { spotName: "Longwood Shola Forest & Elk Falls", timeSlot: "03:00 PM – 05:30 PM", activity: "Ancient montane shola rainforest birdwatching trail", entryAndLocalCost: 150 }
    ]
  },
  {
    name: "Thoothukudi (Tuticorin) & Pearl Coast",
    category: "Beach",
    district: "Thoothukudi",
    wikiTitle: "Thoothukudi",
    image: CATEGORY_IMAGES["Beach"],
    description: "Pearl City on the Gulf of Mannar famous for Hare Island beach, Our Lady of Snows Basilica and Macaroons.",
    avgHotelPerPerson: 850,
    avgFoodPerDay: 400,
    avgTravelCostPerPerson: 750,
    spots: [
      { spotName: "Our Lady of Snows Basilica & Roche Park", timeSlot: "08:00 AM – 10:30 AM", activity: "16th-century Portuguese coastal basilica and seaside promenade", entryAndLocalCost: 100 },
      { spotName: "Hare Island (Muyal Theevu) & Harbour Beach", timeSlot: "11:00 AM – 02:00 PM", activity: "Lighthouse view, shallow coral bay & Tuticorin cashew macaroon tasting", entryAndLocalCost: 200 },
      { spotName: "Kattabomman Memorial Fort, Panchalankurichi", timeSlot: "03:30 PM – 06:00 PM", activity: "Freedom fighter Veerapandiya Kattabomman fort and gallery", entryAndLocalCost: 120 }
    ]
  },
  {
    name: "Pudukkottai & Sittanavasal",
    category: "Heritage",
    district: "Pudukkottai",
    wikiTitle: "Sittanavasal_Cave",
    image: CATEGORY_IMAGES["Heritage"],
    description: "Archaeological treasure trove of 2nd-century Jain cave frescoes, Narthamalai rock temples and forts.",
    avgHotelPerPerson: 800,
    avgFoodPerDay: 380,
    avgTravelCostPerPerson: 600,
    spots: [
      { spotName: "Sittanavasal Rock-Cut Jain Cave & Lotus Pond Frescoes", timeSlot: "08:00 AM – 10:30 AM", activity: "Ancient mural paintings and Eladipattam Jain rock beds", entryAndLocalCost: 120 },
      { spotName: "Vijayalaya Choleeswaram (Narthamalai)", timeSlot: "11:00 AM – 01:00 PM", activity: "One of the earliest circular stone Chola hillside temples", entryAndLocalCost: 100 },
      { spotName: "Kudumiyanmalai Musical Inscription Temple", timeSlot: "03:30 PM – 06:00 PM", activity: "7th-century rock-cut musical notes inscription & 1000-pillar hall", entryAndLocalCost: 120 }
    ]
  },
  {
    name: "Kalakkad Mundanthurai & Manjolai",
    category: "Nature & Waterfalls",
    district: "Tirunelveli",
    wikiTitle: "Kalakkad_Mundanthurai_Tiger_Reserve",
    image: CATEGORY_IMAGES["Nature & Waterfalls"],
    description: "River sanctuary of the Thamirabarani featuring Agasthiyar Falls, Papanasam Dam and lush Western Ghats.",
    avgHotelPerPerson: 850,
    avgFoodPerDay: 400,
    avgTravelCostPerPerson: 750,
    spots: [
      { spotName: "Agasthiyar Falls & Papanasam Nathar Temple", timeSlot: "07:30 AM – 10:30 AM", activity: "Perennial Thamirabarani river waterfall and sacred foothill temple", entryAndLocalCost: 120 },
      { spotName: "Karaiyar Dam & Servalar Reservoir", timeSlot: "11:00 AM – 02:00 PM", activity: "Scenic forest dams surrounded by Agasthyamalai biosphere hills", entryAndLocalCost: 180 },
      { spotName: "Nellaiappar Temple & Tirunelveli Halwa Trail", timeSlot: "04:00 PM – 07:30 PM", activity: "Musical stone pillars and iconic Iruttukadai wheat halwa tasting", entryAndLocalCost: 200 }
    ]
  },
  {
    name: "Namakkal & Fort Rock",
    category: "Heritage",
    district: "Namakkal",
    wikiTitle: "Namakkal_Fort",
    image: CATEGORY_IMAGES["Heritage"],
    description: "Dramatic single-rock hillock fort overlooking the 18-ft Anjaneyar Temple and rock-cut Narasimhaswamy cave.",
    avgHotelPerPerson: 800,
    avgFoodPerDay: 380,
    avgTravelCostPerPerson: 600,
    spots: [
      { spotName: "Namakkal Anjaneyar & Narasimhaswamy Cave Temple", timeSlot: "07:00 AM – 10:00 AM", activity: "Open-sky 18-ft monolithic Hanuman shrine & 8th-century Pandya cave", entryAndLocalCost: 100 },
      { spotName: "Namakkal Malaikottai (Rock Fort)", timeSlot: "10:15 AM – 12:30 PM", activity: "Climb the 65-meter monolithic quartz rock citadel for 360° views", entryAndLocalCost: 100 },
      { spotName: "Tiruchengode Ardhanareeswarar Hill Temple", timeSlot: "03:30 PM – 06:30 PM", activity: "Red hill shrine with 60-ft carved Nagamalai serpent & sunset view", entryAndLocalCost: 150 }
    ]
  }
];
